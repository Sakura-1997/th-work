<script setup lang="ts">
import { ref } from 'vue'

import type { CertificatePreviewViewModel } from '@/types/certificate'
import CertificatePreviewBack from '@/components/certificate/CertificatePreviewBack.vue'
import CertificatePreviewFront from '@/components/certificate/CertificatePreviewFront.vue'

defineProps<{
  model: CertificatePreviewViewModel
}>()

const backPageRef = ref<HTMLElement | null>(null)
const frontPageRef = ref<HTMLElement | null>(null)

function getPageElements() {
  return [backPageRef.value, frontPageRef.value].filter(Boolean) as HTMLElement[]
}

defineExpose({
  getPageElements,
})
</script>

<template>
  <div class="space-y-6">
    <section ref="backPageRef" class="rounded-lg bg-white p-4 shadow-soft">
      <CertificatePreviewBack :model="model" />
    </section>

    <section ref="frontPageRef" class="rounded-lg bg-white p-4 shadow-soft">
      <CertificatePreviewFront :model="model" />
    </section>
  </div>
</template>
