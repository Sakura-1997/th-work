import request from '@/utils/request'
import type { ApiResponse, PageData, PageQuery } from '@/types/api'
import type {
  InstitutionDetailRaw,
  InstitutionEvaluationItem,
  InstitutionEvaluationSummary,
  QualificationNode,
  TrainingInstitutionItem,
  TrainingPlanItem,
} from '@/types/training'

export interface InstitutionListQuery extends PageQuery {
  projectType?: string
  qualificationCode?: string
  areaId?: string
}

export function fetchInstitutionList(params: InstitutionListQuery) {
  return request<ApiResponse<PageData<TrainingInstitutionItem>>>({
    url: '/admin/app/institution/page',
    method: 'get',
    params,
  })
}

export function fetchInstitutionDetail(id: string) {
  return request<ApiResponse<InstitutionDetailRaw>>({
    url: '/admin/app/institution/detail',
    method: 'get',
    params: {
      id,
    },
  })
}

export function fetchInstitutionQualifications(id: string) {
  return request<ApiResponse<QualificationNode[]>>({
    url: '/admin/app/institution/qualifications',
    method: 'get',
    params: {
      id,
    },
  })
}

export function fetchInstitutionTrainingPlans(params: {
  institutionId: string
  status?: string
  current: number
  size: number
}) {
  return request<ApiResponse<PageData<TrainingPlanItem>>>({
    url: '/admin/app/institution/training-plan/page',
    method: 'get',
    params,
  })
}

export function fetchInstitutionEvaluationSummary(id: string) {
  return request<ApiResponse<InstitutionEvaluationSummary>>({
    url: '/admin/app/institution/evaluation',
    method: 'get',
    params: {
      id,
    },
  })
}

export function fetchInstitutionEvaluationPage(params: {
  evaluationObjectId: string
  current: number
  size: number
}) {
  return request<ApiResponse<PageData<InstitutionEvaluationItem>>>({
    url: '/admin/app/userEvaluationLaunch/page',
    method: 'get',
    params,
  })
}
