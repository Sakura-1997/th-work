import type { OptionItem } from '@/types/api'
import type {
  AreaNode,
  InstitutionDetailRaw,
  InstitutionDetailViewModel,
  InstitutionEvaluationItem,
  InstitutionEvaluationViewModel,
  InstitutionListViewModel,
  PcUserProfile,
  QualificationNode,
  QualificationOption,
  TrainingInstitutionItem,
  TrainingPlanItem,
  TrainingPlanViewModel,
  UserProfileState,
} from '@/types/training'
import { createInstitutionPlaceholder } from '@/utils/placeholders'

const backendAssetBase = (() => {
  const base = toStringValue(import.meta.env.VITE_ADMIN_PROXY_PATH).replace(/\/$/, '')

  if (base && !base.endsWith('/api')) {
    return `${base}/api`
  }

  return base
})()

function toStringValue(value: unknown) {
  if (value === null || value === undefined) {
    return ''
  }

  return String(value)
}

function toDisplayValue(value: unknown, fallback = '--') {
  const normalizedValue = toStringValue(value).trim()
  return normalizedValue || fallback
}

function ensureArray(value: unknown) {
  if (Array.isArray(value)) {
    return value
  }

  if (typeof value === 'string') {
    const normalizedValue = value.trim()

    if (normalizedValue.startsWith('[') && normalizedValue.endsWith(']')) {
      try {
        const parsed = JSON.parse(normalizedValue)
        if (Array.isArray(parsed)) {
          return parsed
        }
      } catch {
        // Fallback to string split below when the backend returns a non-standard array string.
      }
    }

    return value
      .split(/[;,，|]/)
      .map((item) => item.trim())
      .filter(Boolean)
  }

  return []
}

function resolveAssetUrl(value: unknown) {
  const url = toStringValue(value).trim()

  if (!url) {
    return ''
  }

  if (/^(https?:)?\/\//i.test(url) || url.startsWith('data:') || url.startsWith('blob:')) {
    return url
  }

  if (!backendAssetBase) {
    return url
  }

  if (url.startsWith('/')) {
    return `${backendAssetBase}${url}`
  }

  return `${backendAssetBase}/${url}`
}

function getInstitutionImageSource(payload: Record<string, unknown>) {
  return (
    payload.sitePhotoPaths ||
    payload.sitePhotoPath ||
    payload.sitePhotos ||
    payload.photoPaths ||
    payload.photoPath ||
    payload.photos ||
    payload.images ||
    payload.imageUrls ||
    payload.imageUrl ||
    payload.bannerPaths ||
    payload.bannerPath ||
    payload.coverPath ||
    payload.coverUrl ||
    payload.sealPath
  )
}

function normalizeBoolean(value: unknown) {
  if (typeof value === 'boolean') {
    return value
  }

  if (typeof value === 'number') {
    return value !== 0
  }

  const normalizedValue = toStringValue(value).trim().toLowerCase()
  return ['true', '1', 'yes', 'y'].includes(normalizedValue)
}

function normalizeImageList(value: unknown, institutionName: string, count = 4) {
  const imageList = ensureArray(value)
    .map((item) => resolveAssetUrl(item))
    .filter(Boolean)

  if (imageList.length > 0) {
    return imageList
  }

  return Array.from({ length: count }, (_, index) =>
    createInstitutionPlaceholder(institutionName || '培训机构', `机构图片 ${index + 1}`, index),
  )
}

function formatDateRange(start?: string, end?: string) {
  const normalizedStart = toStringValue(start)
  const normalizedEnd = toStringValue(end)

  if (!normalizedStart && !normalizedEnd) {
    return '开班时间待定'
  }

  if (normalizedStart && normalizedEnd) {
    return `${normalizedStart} 至 ${normalizedEnd}`
  }

  return normalizedStart || normalizedEnd
}

function formatHourText(value: unknown) {
  const normalizedValue = toStringValue(value).trim()
  return normalizedValue ? `${normalizedValue} 学时` : '--'
}

function getNamesSegments(names?: string) {
  return toStringValue(names)
    .split('|')
    .map((item) => item.trim())
    .filter(Boolean)
}

function getQualificationNodeLabel(node?: QualificationNode) {
  if (!node) {
    return '--'
  }

  const namesParts = getNamesSegments(node.names || node.name)
  return namesParts[namesParts.length - 1] || toDisplayValue(node.name || node.names)
}

function getQualificationNodeMap(tree: QualificationNode[]) {
  const nodeMap = new Map<string, QualificationNode>()

  const travel = (nodes: QualificationNode[]) => {
    nodes.forEach((node) => {
      nodeMap.set(node.code, node)
      if (node.children?.length) {
        travel(node.children)
      }
    })
  }

  travel(tree)
  return nodeMap
}

function resolveQualificationLabels(
  qualificationCodes: unknown,
  qualificationCode: unknown,
  qualificationTree: QualificationNode[],
) {
  const nodeMap = getQualificationNodeMap(qualificationTree)
  const codeParts = toStringValue(qualificationCodes)
    .split('|')
    .map((item) => item.trim())
    .filter(Boolean)

  const labels = {
    personTypeLabelText: '--',
    workCategoryLabelText: '--',
    operationItemLabelText: '--',
  }

  if (codeParts.length > 0) {
    labels.personTypeLabelText = getQualificationNodeLabel(nodeMap.get(codeParts[0]))
    labels.workCategoryLabelText = getQualificationNodeLabel(nodeMap.get(codeParts[1]))
    labels.operationItemLabelText = getQualificationNodeLabel(nodeMap.get(codeParts[2]))
    return labels
  }

  const leafNode = nodeMap.get(toStringValue(qualificationCode))
  const nameParts = getNamesSegments(leafNode?.names || leafNode?.name)

  if (nameParts.length > 0) {
    labels.personTypeLabelText = nameParts[0] || '--'
    labels.workCategoryLabelText = nameParts[1] || '--'
    labels.operationItemLabelText = nameParts[2] || '--'
  }

  return labels
}

function resolveProjectTypeLabel(projectType: unknown, projectTypeLabel: unknown, projectTypeOptions: OptionItem[]) {
  const projectTypeValue = toStringValue(projectType).trim()
  const matchedOption = projectTypeOptions.find((item) => item.value === projectTypeValue)

  return matchedOption?.label || toDisplayValue(projectTypeLabel || projectTypeValue)
}

export function normalizeUserProfile(profileLike: unknown): UserProfileState {
  const payload = (profileLike || {}) as Record<string, unknown>
  const profile = ((payload.user as Record<string, unknown> | undefined) || payload) as PcUserProfile &
    Record<string, unknown>

  const userName = toStringValue(
    profile.realName || profile.username || payload.userName || payload.realName || payload.username,
  )

  return {
    userId: toStringValue(profile.id || profile.userId || payload.userId),
    userName,
    phone: toStringValue(profile.phone || profile.phonenumber || payload.phone || payload.phonenumber),
    idNumber: toStringValue(profile.idNumber || payload.idNumber),
    rawProfile: payload,
  }
}

export function buildAreaTree(provinceChildren: AreaNode[]) {
  return [
    {
      id: '0',
      name: '中国',
      children: [
        {
          id: '360000',
          name: '江西省',
          children: provinceChildren,
        },
      ],
    },
  ] satisfies AreaNode[]
}

export function mapAreaOptions(areaTree: AreaNode[]) {
  const province = areaTree[0]?.children?.[0]
  const cityList = province?.children || []

  return cityList.map((item) => ({
    label: item.name,
    value: item.id,
  }))
}

export function toArrayTree<T extends Record<string, unknown>>(list: T[], key: keyof T, parentKey: keyof T) {
  const nodeMap = new Map<string, T & { children?: T[] }>()
  const tree: Array<T & { children?: T[] }> = []

  list.forEach((item) => {
    const currentKey = toStringValue(item[key])
    nodeMap.set(currentKey, { ...(item as T), children: [] })
  })

  nodeMap.forEach((node) => {
    const parentValue = toStringValue(node[parentKey])
    const parentNode = nodeMap.get(parentValue)

    if (parentValue && parentNode) {
      parentNode.children = parentNode.children || []
      parentNode.children.push(node)
      return
    }

    tree.push(node)
  })

  return tree
}

export function buildQualificationTree(list: QualificationNode[]) {
  return toArrayTree(list, 'code', 'parentCode') as QualificationNode[]
}

export function flattenQualificationOptions(tree: QualificationNode[]) {
  const options: QualificationOption[] = []

  const travel = (nodes: QualificationNode[]) => {
    nodes.forEach((node) => {
      const children = node.children || []

      if (Number(node.level) === 3 || children.length === 0) {
        const codes = toStringValue(node.codes || node.code)
        const codeParts = codes.split('|').filter(Boolean)
        const namesParts = getNamesSegments(node.names || node.name)

        options.push({
          label: namesParts[namesParts.length - 1] || toStringValue(node.name || node.names || node.code),
          value: codes || toStringValue(node.code),
          personType: codeParts[0] || '',
          fullName: namesParts.join(' / ') || toStringValue(node.name || node.names || node.code),
        })
        return
      }

      travel(children)
    })
  }

  travel(tree)

  return options
}

export function normalizeInstitutionListItem(item: TrainingInstitutionItem, index: number) {
  const payload = item as Record<string, unknown>
  const institutionName = toStringValue(item.institutionName || item.name)
  const hasRecentTrainingPlan = normalizeBoolean(item.hasRecentTrainingPlan)

  return {
    id: toStringValue(item.id),
    name: toDisplayValue(institutionName),
    phone: toDisplayValue(item.phone),
    contactPerson: toDisplayValue(item.linkman || item.contactPerson),
    address: toDisplayValue(item.address || item.areaName),
    description: toDisplayValue(item.introduction || item.summary),
    score: Number(item.score || 0),
    tag: '认证机构',
    sitePhotoPaths: normalizeImageList(getInstitutionImageSource(payload), institutionName, 1 + (index % 4)),
    hasRecentTrainingPlan,
    recentTrainingPlanText: hasRecentTrainingPlan ? '近期有培训计划' : '近期暂无培训计划',
  } satisfies InstitutionListViewModel
}

export function normalizeInstitutionDetail(detail: InstitutionDetailRaw) {
  const payload = detail as Record<string, unknown>
  const institutionName = toStringValue(detail.institutionName || detail.name)
  const trainingItems = ensureArray(detail.qualificationNames || detail.trainingItems)
    .map((item) => toStringValue(item).trim())
    .filter(Boolean)

  return {
    id: toStringValue(detail.id),
    name: toDisplayValue(institutionName),
    tag: '认证机构',
    contactPerson: toDisplayValue(detail.linkman || detail.contactPerson),
    phone: toDisplayValue(detail.phone),
    businessPhone: toDisplayValue(detail.businessPhone || detail.phone),
    address: toDisplayValue(detail.address || detail.areaName),
    description: toDisplayValue(detail.introduction || detail.summary),
    trainingItems,
    sitePhotoPaths: normalizeImageList(getInstitutionImageSource(payload), institutionName),
    score: Number(detail.score || 0),
    evaluationSummary: toDisplayValue(detail.summary || detail.introduction),
  } satisfies InstitutionDetailViewModel
}

export function normalizeEvaluationSummary(summaryLike: unknown) {
  const summary = (summaryLike || {}) as Record<string, unknown>

  return (
    [
      toStringValue(summary.levelName || summary.evaluationLevelName || summary.scoreLevel),
      toStringValue(summary.summary || summary.remark),
      summary.total ? `累计评价 ${summary.total} 条` : '',
      summary.goodRate ? `好评率 ${summary.goodRate}` : '',
    ]
      .filter(Boolean)
      .join('，') || '暂无评价概况'
  )
}

export function normalizeTrainingPlanItem(
  item: TrainingPlanItem,
  options?: {
    qualificationTree?: QualificationNode[]
    projectTypeOptions?: OptionItem[]
  },
) {
  const planName = toStringValue(
    item.name || item.qualificationName || item.qualificationNames || item.projectTypeLabel,
  )
  const scheduleText = toStringValue(
    item.scheduleText ||
      item.timeRangeText ||
      formatDateRange(
        toStringValue(item.theoryStartDate || item.startDate),
        toStringValue(item.practiceEndDate || item.theoryEndDate || item.endDate),
      ),
  )
  const plannedTrainees = toStringValue(item.plannedTrainees)
  const currentTrainees = toStringValue(item.traineeCount ?? item.formalTraineeCount ?? '')
  const signupPeriodText = formatDateRange(
    toStringValue(item.signupStartDate),
    toStringValue(item.signupEndDate),
  )
  const qualificationLabels = resolveQualificationLabels(
    item.qualificationCodes,
    item.qualificationCode,
    options?.qualificationTree || [],
  )
  const trainingCountText =
    plannedTrainees && currentTrainees ? `${currentTrainees}/${plannedTrainees}` : '--'

  return {
    id: toStringValue(item.id),
    classId: toStringValue(item.classId || item.id),
    qualificationCode: toStringValue(item.qualificationCode),
    qualificationName: planName || '--',
    projectType: toStringValue(item.projectType || item.projectTypeLabel),
    projectTypeLabelText: resolveProjectTypeLabel(
      item.projectType,
      item.projectTypeLabel,
      options?.projectTypeOptions || [],
    ),
    personTypeLabelText: qualificationLabels.personTypeLabelText,
    workCategoryLabelText: qualificationLabels.workCategoryLabelText,
    operationItemLabelText: qualificationLabels.operationItemLabelText,
    scheduleText: scheduleText === '开班时间待定' ? '--' : scheduleText || '--',
    plannedTraineesText: plannedTrainees || '--',
    currentTraineesText: currentTrainees || '--',
    trainingCountText,
    signupPeriodText: signupPeriodText === '开班时间待定' ? '--' : signupPeriodText,
    trainingLocationText: toDisplayValue(item.trainingLocation),
    theoryHoursText: formatHourText(item.theoryHours),
    practiceHoursText: formatHourText(item.practiceHours),
    examDateText: toDisplayValue(item.examDate),
  } satisfies TrainingPlanViewModel
}

export function normalizeEvaluationItem(item: InstitutionEvaluationItem, index: number) {
  return {
    id: toStringValue(item.id || index),
    userName: toStringValue(item.userName || item.realName || item.nickName || '匿名学员'),
    content: toStringValue(item.content || item.evaluationContent || item.remark || '暂无评价内容'),
    createTime: toStringValue(item.createTime || item.evaluationTime || '时间待补充'),
  } satisfies InstitutionEvaluationViewModel
}

export function getErrorMessage(error: unknown) {
  if (typeof error === 'string') {
    return error
  }

  if (error && typeof error === 'object') {
    const messageLike = error as Record<string, unknown>
    return (
      toStringValue(messageLike.msg || messageLike.message || messageLike.error_description) || '请求失败，请稍后重试'
    )
  }

  return '请求失败，请稍后重试'
}
