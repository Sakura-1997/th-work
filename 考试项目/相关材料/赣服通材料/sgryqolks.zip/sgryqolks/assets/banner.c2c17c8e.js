const e=""+new URL("banner.e09659ed.jpg",import.meta.url).href;export{e as b};
