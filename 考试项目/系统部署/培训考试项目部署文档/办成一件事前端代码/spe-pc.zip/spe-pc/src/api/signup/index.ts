import request from '@/utils/request'
import type { ApiResponse } from '@/types/api'
import type { TrainingSignUpPayload } from '@/types/training'

export function submitTrainingSignup(data: TrainingSignUpPayload) {
  return request<ApiResponse<Record<string, unknown>>>({
    url: '/admin/app/trainee/signup',
    method: 'post',
    data: {
      ...data,
      source: 'zww',
    },
  })
}
