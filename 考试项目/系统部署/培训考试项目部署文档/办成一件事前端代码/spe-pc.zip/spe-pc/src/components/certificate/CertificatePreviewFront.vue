<script setup lang="ts">
import type { CertificatePreviewViewModel } from '@/types/certificate'

defineProps<{
  model: CertificatePreviewViewModel
}>()
</script>

<template>
  <div class="cert-shell">
    <img class="cert-bg" :src="model.frontBackgroundUrl" :alt="`${model.certificateName}正面`" />
  </div>
</template>

<style scoped>
.cert-shell {
  position: relative;
  width: 100%;
  aspect-ratio: 1.58;
  overflow: hidden;
  border-radius: 12px;
  background: #fff;
}

.cert-bg {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
</style>
