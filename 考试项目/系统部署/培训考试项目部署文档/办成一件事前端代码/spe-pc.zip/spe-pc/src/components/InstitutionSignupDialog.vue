<script setup lang="ts">
import { X } from '@lucide/vue'
import { computed, reactive, ref, watch } from 'vue'

import { fetchInstitutionQualifications } from '@/api/institution'
import { submitTrainingSignup } from '@/api/signup'
import ActionDialog from '@/components/ActionDialog.vue'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { hideGlobalLoading, showGlobalLoading } from '@/composables/use-global-loading'
import { showGlobalMessage } from '@/composables/use-global-message'
import { loadProjectTypeOptions } from '@/services/app-bootstrap'
import type { OptionItem } from '@/types/api'
import type { QualificationNode } from '@/types/training'
import { buildQualificationTree, getErrorMessage } from '@/utils/training'

const props = defineProps<{
  modelValue: boolean
  institutionId: string
  institutionName?: string
}>()

const emit = defineEmits<{
  'update:modelValue': [value: boolean]
  success: []
}>()
const PERSON_TYPES_WITHOUT_PROJECT = ['01', '02']

const form = reactive({
  personTypeCode: '',
  workCategoryCode: '',
  qualificationCode: '',
  projectType: '',
})

const loading = ref(false)
const submitLoading = ref(false)
const qualificationTree = ref<QualificationNode[]>([])
const projectTypeOptions = ref<OptionItem[]>([])
const successDialogVisible = ref(false)

const visible = computed({
  get: () => props.modelValue,
  set: (value: boolean) => emit('update:modelValue', value),
})

const currentPersonType = computed(() =>
  qualificationTree.value.find((item) => item.code === form.personTypeCode),
)

const currentWorkCategory = computed(() =>
  (currentPersonType.value?.children || []).find((item) => item.code === form.workCategoryCode),
)
const isOperationProjectOptional = computed(() =>
  PERSON_TYPES_WITHOUT_PROJECT.includes(form.personTypeCode),
)

const personTypeOptions = computed(() =>
  qualificationTree.value.map((item) => ({
    label: item.name || item.names?.split('|')[0] || item.code,
    value: item.code,
  })),
)

const workCategoryOptions = computed(() =>
  (currentPersonType.value?.children || []).map((item) => ({
    label: item.name || item.names?.split('|').slice(-1)[0] || item.code,
    value: item.code,
  })),
)

const qualificationOptions = computed(() =>
  (currentWorkCategory.value?.children || []).map((item) => ({
    label: item.name || item.names?.split('|').slice(-1)[0] || item.code,
    value: item.codes || item.code,
    personType: item.codes?.split('|').filter(Boolean)[0] || item.code,
    fullName: item.names || item.name || item.code,
  })),
)

const selectedQualification = computed(() =>
  qualificationOptions.value.find((item) => item.value === form.qualificationCode),
)

const qualificationPlaceholder = computed(() => {
  if (!form.personTypeCode) {
    return '请先选择人员类型'
  }

  if (!form.workCategoryCode) {
    return '请先选择作业类别'
  }

  if (isOperationProjectOptional.value) {
    return '主要负责人、安全生产管理人员无需选择操作项目'
  }

  if (qualificationOptions.value.length === 0) {
    return '当前作业类别下暂无操作项目'
  }

  return '请选择操作项目'
})

const submitQualificationCode = computed(() => {
  if (form.qualificationCode) {
    return form.qualificationCode.split('|').filter(Boolean).pop() || form.qualificationCode
  }

  const fallbackValue = String(currentWorkCategory.value?.codes || currentWorkCategory.value?.code || '').trim()
  return fallbackValue ? fallbackValue.split('|').filter(Boolean).pop() || fallbackValue : ''
})

const submitPersonType = computed(() => {
  if (selectedQualification.value?.personType) {
    return selectedQualification.value.personType
  }

  const fallbackValue = String(currentWorkCategory.value?.codes || currentPersonType.value?.codes || '').trim()
  return fallbackValue ? fallbackValue.split('|').filter(Boolean)[0] || form.personTypeCode : form.personTypeCode
})

const resetForm = () => {
  form.personTypeCode = ''
  form.workCategoryCode = ''
  form.qualificationCode = ''
  form.projectType = ''
}

const closeDialog = () => {
  if (submitLoading.value) {
    return
  }

  visible.value = false
}

const handlePersonTypeChange = () => {
  form.workCategoryCode = ''
  form.qualificationCode = ''
}

const handleWorkCategoryChange = () => {
  form.qualificationCode = ''
}

const loadInstitutionQualifications = async () => {
  if (!props.institutionId || !visible.value) {
    return
  }

  loading.value = true
  resetForm()

  try {
    const [qualificationResponse, dictOptions] = await Promise.all([
      fetchInstitutionQualifications(props.institutionId),
      loadProjectTypeOptions(),
    ])

    qualificationTree.value = buildQualificationTree(qualificationResponse.data || [])
    projectTypeOptions.value = dictOptions

    if (qualificationTree.value.length === 0) {
      showGlobalMessage('该培训机构暂无可报名资格项')
    }
  } catch (error) {
    qualificationTree.value = []
    showGlobalMessage(getErrorMessage(error))
  } finally {
    loading.value = false
  }
}

const submit = async () => {
  if (!form.personTypeCode) {
    showGlobalMessage('请选择人员类型')
    return
  }

  if (!form.workCategoryCode) {
    showGlobalMessage('请选择作业类别')
    return
  }

  if (!form.qualificationCode && !isOperationProjectOptional.value) {
    showGlobalMessage('请选择操作项目')
    return
  }

  if (!submitQualificationCode.value) {
    showGlobalMessage('当前资格项缺少提交编码，请联系管理员')
    return
  }

  if (!form.projectType) {
    showGlobalMessage('请选择培训类型')
    return
  }

  submitLoading.value = true
  showGlobalLoading('正在提交报名...')

  try {
    await submitTrainingSignup({
      institutionId: props.institutionId,
      qualificationCode: submitQualificationCode.value,
      projectType: form.projectType,
      personType: submitPersonType.value,
    })

    emit('success')
    successDialogVisible.value = true
    visible.value = false
  } catch (error) {
    showGlobalMessage(getErrorMessage(error))
  } finally {
    hideGlobalLoading()
    submitLoading.value = false
  }
}

watch(
  () => [props.modelValue, props.institutionId],
  async ([isOpen, institutionId]) => {
    if (!isOpen || !institutionId) {
      return
    }

    await loadInstitutionQualifications()
  },
)

watch(
  () => props.modelValue,
  (isOpen) => {
    if (!isOpen) {
      resetForm()
      qualificationTree.value = []
      projectTypeOptions.value = []
      loading.value = false
    }
  },
)
</script>

<template>
  <Teleport to="body">
    <div
      v-if="visible"
      class="fixed inset-0 z-[9998] flex items-center justify-center bg-slate-950/30 px-4"
      @click.self="closeDialog"
    >
      <Card class="w-full max-w-[760px] p-0 shadow-2xl">
        <div class="flex items-center justify-between border-b border-slate-200 px-6 py-5">
          <div>
            <h3 class="text-xl font-semibold text-slate-900">我要报名取证</h3>
            <p class="mt-1 text-sm text-slate-500">
              {{ institutionName ? `当前机构：${institutionName}` : '请选择当前机构的可报名资格项' }}
            </p>
          </div>
          <button
            type="button"
            class="rounded-full p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
            @click="closeDialog"
          >
            <X class="h-4 w-4" />
          </button>
        </div>

        <div class="space-y-5 px-6 py-6">
          <div v-if="loading" class="flex min-h-[220px] items-center justify-center text-sm text-slate-500">
            正在加载机构可报名资格项...
          </div>

          <div v-else class="grid grid-cols-2 gap-5">
            <div class="space-y-2">
              <label class="text-sm font-medium text-slate-700">人员类型</label>
              <select
                v-model="form.personTypeCode"
                class="h-11 w-full rounded-md border border-input bg-white px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                @change="handlePersonTypeChange"
              >
                <option value="">请选择人员类型</option>
                <option v-for="option in personTypeOptions" :key="option.value" :value="option.value">
                  {{ option.label }}
                </option>
              </select>
            </div>

            <div class="space-y-2">
              <label class="text-sm font-medium text-slate-700">作业类别</label>
              <select
                v-model="form.workCategoryCode"
                :disabled="!form.personTypeCode"
                class="h-11 w-full rounded-md border border-input bg-white px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                @change="handleWorkCategoryChange"
              >
                <option value="">{{ form.personTypeCode ? '请选择作业类别' : '请先选择人员类型' }}</option>
                <option v-for="option in workCategoryOptions" :key="option.value" :value="option.value">
                  {{ option.label }}
                </option>
              </select>
            </div>

            <div class="space-y-2">
              <label class="text-sm font-medium text-slate-700">操作项目</label>
              <select
                v-model="form.qualificationCode"
                :disabled="!form.workCategoryCode || isOperationProjectOptional"
                class="h-11 w-full rounded-md border border-input bg-white px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">{{ qualificationPlaceholder }}</option>
                <option v-for="option in qualificationOptions" :key="option.value" :value="option.value">
                  {{ option.label }}
                </option>
              </select>
            </div>

            <div class="space-y-2">
              <label class="text-sm font-medium text-slate-700">培训类型</label>
              <select
                v-model="form.projectType"
                class="h-11 w-full rounded-md border border-input bg-white px-3 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">请选择培训类型</option>
                <option v-for="option in projectTypeOptions" :key="option.value" :value="option.value">
                  {{ option.label }}
                </option>
              </select>
            </div>
          </div>
        </div>

        <div class="flex justify-end gap-3 border-t border-slate-200 px-6 py-5">
          <Button variant="outline" :disabled="submitLoading" @click="closeDialog">取消</Button>
          <Button :disabled="loading || submitLoading || qualificationTree.length === 0" @click="submit">
            {{ submitLoading ? '提交中...' : '确认报名' }}
          </Button>
        </div>
      </Card>
    </div>
  </Teleport>
  <ActionDialog
    v-model="successDialogVisible"
    title="报名成功"
    description="报名信息已提交成功，请留意后续审核结果。"
    confirm-text="我知道了"
    :show-cancel="false"
    @confirm="successDialogVisible = false"
  />
</template>
