const palettes = [
  ['#1d4ed8', '#0f172a', '#94a3b8'],
  ['#0f766e', '#164e63', '#5eead4'],
  ['#7c3aed', '#1e293b', '#c4b5fd'],
  ['#b45309', '#78350f', '#fdba74'],
] as const

function svgToDataUrl(svg: string) {
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`
}

export function createInstitutionPlaceholder(title: string, subtitle: string, index = 0) {
  const palette = palettes[index % palettes.length]

  return svgToDataUrl(`
    <svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720" viewBox="0 0 1280 720">
      <defs>
        <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="${palette[0]}" />
          <stop offset="100%" stop-color="${palette[1]}" />
        </linearGradient>
      </defs>
      <rect width="1280" height="720" fill="url(#bg)" />
      <rect x="96" y="112" width="1088" height="496" rx="26" fill="rgba(255,255,255,0.18)" />
      <rect x="146" y="176" width="988" height="240" rx="18" fill="${palette[2]}" opacity="0.75" />
      <rect x="176" y="452" width="262" height="96" rx="16" fill="rgba(255,255,255,0.82)" />
      <rect x="470" y="452" width="208" height="96" rx="16" fill="rgba(255,255,255,0.56)" />
      <rect x="710" y="452" width="424" height="96" rx="16" fill="rgba(255,255,255,0.4)" />
      <text x="160" y="262" fill="#ffffff" font-size="52" font-family="Microsoft YaHei, Arial, sans-serif" font-weight="700">${title}</text>
      <text x="160" y="332" fill="rgba(255,255,255,0.88)" font-size="28" font-family="Microsoft YaHei, Arial, sans-serif">${subtitle}</text>
    </svg>
  `)
}
