<script setup lang="ts">
import GlobalLoading from '@/components/GlobalLoading.vue'
import GlobalMessage from '@/components/GlobalMessage.vue'
</script>

<template>
  <RouterView />
  <GlobalLoading />
  <GlobalMessage />
</template>
