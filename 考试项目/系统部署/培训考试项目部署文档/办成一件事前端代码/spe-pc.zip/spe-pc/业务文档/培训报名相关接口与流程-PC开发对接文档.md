# 培训报名相关接口与流程 - PC 开发对接文档

## 文档目的
- 本文基于移动端现有实现整理，供 PC 项目开发培训报名相关功能时复用。
- 覆盖范围包括：身份证/手机号/姓名登录逻辑、自动获取学员信息、地区树获取与构造、项目资格树获取与构造、培训机构列表分页、培训机构详情、培训计划分页、培训机构评价分页、在线报名、点击培训计划报名。
- 文档内容以“当前移动端真实实现”为准，不是理想设计稿。

## 1. 当前登录与自动获取学员信息

### 1.1 身份证 + 姓名 + 手机号登录
- 登录方式：用户输入 `idCard`、`name`、`phone` 三个字段后提交。
- 请求方式：`POST /auth/oauth2/token?grant_type=gft&client_id=gft`
- 请求头：

```http
Authorization: Basic Y3VzdG9tOmN1c3RvbQ==
Content-Type: application/x-www-form-urlencoded
Enc-Flag: false
skipToken: true
```

- 请求体：

```x-www-form-urlencoded
scope=server
idCard=身份证号
name=姓名
phone=手机号
```

- 登录成功后处理：
- 写入 `token`
- 写入 `refresh_token`
- 在本地用户信息中预写入 `idNumber`、`realName`、`phone`、`username`

### 1.2 自动获取学员信息
- 当前“自动获取学员信息”主要发生在赣服通 GFT 自动登录场景。
- 自动登录流程：
1. 调用赣服通侧能力获取用户密文信息。
2. 解密得到 `idCard`、`name`、`phone`。
3. 使用这三个字段走上面的 GFT 登录接口换取业务系统 token。
4. 登录成功后，再调用 `GET /admin/app/user/profile` 获取业务侧用户资料。
5. 将返回的 `profile` 映射成本地用户对象。

- 用户资料接口：
- `GET /admin/app/user/profile`

- 当前用户资料映射结果：

```json
{
  "user": {
    "...profile": "...",
    "userId": "profile.id",
    "userName": "profile.realName || profile.username",
    "phonenumber": "profile.phone"
  },
  "userName": "profile.realName || profile.username"
}
```

### 1.3 对 PC 的建议
- 如果 PC 也需要复用“身份证 + 姓名 + 手机号”登录，可直接沿用移动端的登录接口与表单参数。
- 如果 PC 不接赣服通环境，则“自动获取学员信息”可以仅保留 `GET /admin/app/user/profile` 这一步，在用户登录成功后主动拉取。
- 当前移动端并未发现“自动把 profile 回填到培训报名表单”的完整链路，PC 若要做自动回填，需要单独补产品规则。

---

## 2. 地区树接口与构造

### 2.1 使用接口
- 主接口：`GET /admin/area/details`
- 请求参数：`parentId`

### 2.2 当前移动端构造规则
- 不是一次性拉全量树。
- 只按两步构造江西省市级数据：
1. 调 `GET /admin/area/details?parentId=0` 获取省级列表。
2. 找到江西省，固定使用 `360000`。
3. 再调 `GET /admin/area/details?parentId=360000` 获取江西省下市级列表。

### 2.3 最终树结构
- 最终前端内存树结构固定为：

```json
[
  {
    "id": "0",
    "name": "中国",
    "children": [
      {
        "id": "360000",
        "name": "江西省",
        "children": [
          {
            "id": "市级ID",
            "name": "市级名称",
            "parentId": "360000",
            "level": 2,
            "isLeaf": true
          }
        ]
      }
    ]
  }
]
```

### 2.4 缓存与默认值
- 地区树会缓存到 `sessionStorage.areaTreeCache`。
- 首页和线上报名页都会优先使用缓存。
- 若本地未设置默认地区，则默认取江西市级列表中的“南昌”或第一个城市。

### 2.5 对 PC 的建议
- PC 直接复用同样的构造方式即可，不建议请求全量区县街道。
- 如果 PC 只做筛选器，直接取“江西省下的市级列表”即可。
- 如果 PC 需要级联选择器，可把结构转换为：

```json
[
  {
    "text": "江西省",
    "value": "360000",
    "children": [
      {
        "text": "南昌市",
        "value": "360100"
      }
    ]
  }
]
```

---

## 3. 项目资格树接口与构造

### 3.1 全量资格树接口
- 接口：`GET /admin/qualification/details`
- 用途：获取“人员类型 -> 作业类别 -> 操作项目”全量树源数据。
- 返回特点：后端返回扁平结构，前端自行转树。

### 3.2 机构资格树接口
- 接口：`GET /admin/app/institution/qualifications?id=机构ID`
- 用途：查询某家培训机构可报名的资格项。
- 返回特点：同样以扁平结构为主，前端自行转树。

### 3.3 树构造规则
- 统一使用以下字段建树：
- 当前节点主键：`code`
- 父节点主键：`parentCode`
- 子节点字段：`children`

- 前端树构造规则：

```js
XEUtils.toArrayTree(list, {
  strict: true,
  key: 'code',
  parentKey: 'parentCode',
  children: 'children'
})
```

### 3.4 层级含义
- `level = 1`：人员类型
- `level = 2`：作业类别
- `level = 3`：操作项目

### 3.5 名称与编码处理规则
- 节点展示名优先使用后端返回的 `names`
- `names` 常见格式：

```text
人员类型|作业类别|操作项目
```

- 节点完整编码优先使用后端返回的 `codes`
- `codes` 常见格式：

```text
人员类型code|作业类别code|操作项目code
```

### 3.6 报名提交时的拆分规则
- 在线报名时，如果拿到的是完整链路编码，则前端会拆分：
- 第一段作为 `personType`
- 最后一段作为真正提交的 `qualificationCode`

```js
const qualificationParts = String(qualificationCode || '').split('|')

const postData = {
  institutionId,
  qualificationCode: qualificationParts.pop() || '',
  projectType,
  personType: qualificationParts.shift() || ''
}
```

### 3.7 对 PC 的建议
- PC 若做筛选器，可直接使用全量资格树接口。
- PC 若做机构报名弹窗，优先使用“机构资格树接口”，避免用户选到机构不支持的项目。
- PC 侧需要统一一条规则：页面展示可使用 `names`，接口提交必须按移动端规则拆分 `codes`。

---

## 4. 培训机构相关接口

### 4.1 培训机构列表分页
- 接口：`GET /admin/app/institution/page`
- 主要用途：培训报名首页分页查询机构列表。
- 当前常用筛选参数：
- `projectType`
- `qualificationCode`
- `areaId`
- 分页参数：
- `current`
- `size`

### 4.2 培训机构详情
- 接口：`GET /admin/app/institution/detail?id=机构ID`
- 主要用途：机构详情页顶部基础信息展示。

### 4.3 培训机构计划分页
- 接口：`GET /admin/app/institution/training-plan/page`
- 常用参数：
- `institutionId`
- `status`
- `current`
- `size`

- 当前移动端固定加参：

```json
{
  "institutionId": "机构ID",
  "status": "0"
}
```

### 4.4 培训机构评价信息
- 接口：`GET /admin/app/institution/evaluation?id=机构ID`
- 主要用途：获取机构评价等级类聚合信息。

### 4.5 培训机构评价分页
- 接口：`GET /api/app/userEvaluationLaunch/page`
- 当前页面额外带的核心参数：
- `evaluationObjectId = 机构ID`
- 分页参数：
- `current`
- `size`

### 4.6 我的报名列表与详情
- 我的报名分页：`GET /admin/app/trainee/signup/page`
- 我的报名详情：`GET /admin/app/trainee/signup/detail?signupId=报名ID`

---

## 5. 分页约定

### 5.1 当前移动端统一分页方式
- 移动端列表统一使用 `ListScroll` 组件。
- 组件会自动追加：
- `current`
- `size`

### 5.2 当前接口返回解析约定
- 前端按以下结构读取：

```json
{
  "code": 0,
  "data": {
    "records": [],
    "total": 0
  }
}
```

### 5.3 对 PC 的建议
- PC 直接按 `records + total` 处理即可。
- 若使用表格分页组件，推荐统一成：

```json
{
  "list": "data.records",
  "total": "data.total"
}
```

---

## 6. 在线报名接口与流程

### 6.1 报名提交接口
- 接口：`POST /admin/app/trainee/signup`
- 用途：
- 在线报名卡片直接报名
- 机构详情中点击培训计划报名

### 6.2 在线报名卡片提交参数
- 当前在线报名卡片实际提交最小参数如下：

```json
{
  "institutionId": "培训机构ID",
  "qualificationCode": "操作项目code",
  "projectType": "培训类型",
  "personType": "人员类型code"
}
```

### 6.3 在线报名操作流程
1. 进入培训报名列表页。
2. 分页查询培训机构列表。
3. 用户点击某个机构卡片上的“确认报名”。
4. 先调用 `GET /admin/app/institution/qualifications?id=机构ID` 查询该机构支持的资格项。
5. 若外层筛选条件中已经选中了 `projectType + qualificationCode`，则直接进入确认弹窗。
6. 若未提前选中，则先让用户选择“培训项目”，再选择“培训类型”。
7. 前端根据用户选择组装报名参数。
8. 调用 `POST /admin/app/trainee/signup` 提交报名。
9. 成功后提示“报名成功”，跳转我的报名列表。

### 6.4 在线报名流程图

```text
培训报名列表
  -> 点击确认报名
  -> 查询机构可报资质
  -> 选择培训项目
  -> 选择培训类型
  -> 确认报名
  -> 提交 /admin/app/trainee/signup
  -> 跳转我的报名
```

---

## 7. 点击相应培训计划报名接口与流程

### 7.1 培训计划报名提交参数
- 当前从培训机构详情页的“培训计划”列表点击报名时，提交参数如下：

```json
{
  "qualificationCode": "props.data.qualificationCode",
  "projectType": "props.data.projectType",
  "institutionId": "机构ID",
  "classId": "培训计划班级ID"
}
```

### 7.2 点击培训计划报名操作流程
1. 用户先进入培训机构详情页。
2. 页面加载机构详情、评价概况，并支持切换到“培训计划”分页列表。
3. 用户在某一条培训计划上点击“预约培训”。
4. 打开“预约培训计划报名”确认弹窗。
5. 用户确认后，直接调用 `POST /admin/app/trainee/signup`。
6. 其中 `classId` 由当前培训计划记录提供。
7. 成功后展示“报名资格审核成功”类提示。
8. 用户点击后续按钮，跳转“我的报名”列表页。

### 7.3 培训计划报名流程图

```text
培训机构详情
  -> 培训计划分页
  -> 点击某条计划“预约培训”
  -> 确认弹窗
  -> 提交 /admin/app/trainee/signup
  -> 成功提示
  -> 跳转我的报名
```

---

## 8. PC 开发实现建议

### 8.1 页面建议
- 机构列表页
- 机构详情页
- 我的报名列表页
- 我的报名详情页

### 8.2 建议抽成的公共能力
- 登录服务
- 用户信息服务
- 地区树服务
- 资格树服务
- 培训机构服务
- 报名服务

### 8.3 建议保留的统一字段模型

```ts
type TrainingSignUpPayload = {
  institutionId: string
  qualificationCode: string
  projectType: string
  personType?: string
  classId?: string
}
```

### 8.4 建议优先复用的规则
- 地区只取江西省市级，不拉全量区县
- 资格展示用 `names`
- 资格提交用拆分后的 `qualificationCode`
- 若从培训计划报名，额外传 `classId`
- 报名成功统一进入“我的报名”

---

## 9. 当前实现中的注意事项

### 9.1 评价分页接口前缀存在差异
- 代码里评价分页使用的是 `/api/app/userEvaluationLaunch/page`
- 如果 PC 对接网关或统一鉴权层，需确认生产实际应走 `/api` 还是 `/admin`

### 9.2 在线报名 Step1 页面当前未真正接入
- 移动端存在 `/online-train-register-step1` 页面，但当前实际在线报名主链路并不是通过该步骤表单页提交。
- 现网有效链路主要是：
- 机构列表直接报名
- 培训计划直接报名

### 9.3 用户信息自动回填规则仍需产品确认
- 当前代码中可以自动获取用户 profile。
- 但“报名表单中的姓名/身份证/手机号是否自动回填、是否允许改动、改动后是否影响实名校验”这部分没有完整产品规则。
- PC 如果要做完整报名表单，建议单独补一版产品约束。

---

## 10. 推荐的 PC 开发顺序
1. 先接登录与 `user/profile`。
2. 再接地区树与资格树服务。
3. 完成培训机构列表页与详情页。
4. 接培训计划分页与评价分页。
5. 接在线报名与培训计划报名两个提交入口。
6. 最后补我的报名列表、详情及状态流转。

## 11. 接口清单总表

| 模块 | 方法 | 接口 | 用途 |
| :--- | :--- | :--- | :--- |
| GFT 登录 | POST | `/auth/oauth2/token?grant_type=gft&client_id=gft` | 身份证 + 姓名 + 手机号登录 |
| 用户资料 | GET | `/admin/app/user/profile` | 获取当前用户资料 |
| 地区树 | GET | `/admin/area/details` | 按 `parentId` 获取地区 |
| 全量资格树 | GET | `/admin/qualification/details` | 获取人员类型/作业类别/操作项目树 |
| 机构列表 | GET | `/admin/app/institution/page` | 培训机构分页 |
| 机构详情 | GET | `/admin/app/institution/detail` | 培训机构详情 |
| 机构计划分页 | GET | `/admin/app/institution/training-plan/page` | 培训计划分页 |
| 机构资质 | GET | `/admin/app/institution/qualifications` | 查询机构可报资质 |
| 机构评价概况 | GET | `/admin/app/institution/evaluation` | 查询机构评价信息 |
| 机构评价分页 | GET | `/api/app/userEvaluationLaunch/page` | 查询评价分页 |
| 提交报名 | POST | `/admin/app/trainee/signup` | 在线报名/培训计划报名 |
| 我的报名列表 | GET | `/admin/app/trainee/signup/page` | 查询我的报名分页 |
| 我的报名详情 | GET | `/admin/app/trainee/signup/detail` | 查询报名详情 |

---

## 12. PC 页面清单建议

### 12.1 登录页
- 登录方式：身份证号 + 姓名 + 手机号
- 提交动作：调用 GFT 登录接口
- 登录成功后动作：
- 写 token
- 拉取 `user/profile`
- 初始化地区树、资格树基础数据

### 12.2 培训报名列表页
- 页面目标：查询培训机构分页列表，并支持按地区、培训类型、资格项目筛选
- 页面能力：
- 地区筛选
- 培训类型筛选
- 人员类型/作业类别/操作项目筛选
- 机构卡片列表
- 直接报名入口
- 查看机构详情入口

### 12.3 培训机构详情页
- 页面目标：展示机构基础信息、培训计划分页、机构评价分页
- 页面分区建议：
- 基本信息
- 培训计划
- 学员评价
- 页面能力：
- 培训计划分页加载
- 评价分页加载
- 点击培训计划直接报名

### 12.4 我的报名列表页
- 页面目标：展示当前用户已报名记录
- 页面能力：
- 报名记录分页
- 点击进入报名详情
- 按状态筛选（如后端支持）

### 12.5 我的报名详情页
- 页面目标：展示报名详细信息
- 页面建议字段：
- 培训机构名称
- 人员类型
- 作业类别
- 操作项目
- 培训类型
- 报名状态
- 报名时间
- 培训计划信息

---

## 13. PC 页面与接口映射表

| 页面 | 接口 | 用途 | 备注 |
| :--- | :--- | :--- | :--- |
| 登录页 | `POST /auth/oauth2/token?grant_type=gft&client_id=gft` | 身份证登录 | 登录成功后立刻拉 profile |
| 登录后初始化 | `GET /admin/app/user/profile` | 获取当前用户信息 | 可用于页面头部用户信息展示 |
| 登录后初始化 | `GET /admin/area/details` | 获取地区树 | 先拉省级，再拉江西市级 |
| 登录后初始化 | `GET /admin/qualification/details` | 获取全量资格树 | 用于筛选器和名称映射 |
| 培训报名列表页 | `GET /admin/app/institution/page` | 查询机构分页列表 | 带 `current/size/projectType/qualificationCode/areaId` |
| 培训报名列表页 | `GET /admin/app/institution/qualifications` | 查询机构可报资质 | 点击直接报名时调用 |
| 培训机构详情页 | `GET /admin/app/institution/detail` | 查询机构详情 | 根据 `id` 查询 |
| 培训机构详情页 | `GET /admin/app/institution/evaluation` | 查询机构评价概况 | 展示评分概况或标签 |
| 培训机构详情页 | `GET /admin/app/institution/training-plan/page` | 查询培训计划分页 | 通常附带 `status=0` |
| 培训机构详情页 | `GET /api/app/userEvaluationLaunch/page` | 查询机构评价分页 | 需确认网关实际前缀 |
| 直接报名/计划报名 | `POST /admin/app/trainee/signup` | 提交报名 | 两条报名链路共用 |
| 我的报名列表页 | `GET /admin/app/trainee/signup/page` | 我的报名分页 | 供结果追踪 |
| 我的报名详情页 | `GET /admin/app/trainee/signup/detail` | 我的报名详情 | 通过 `signupId` 查询 |

---

## 14. 关键接口字段表

### 14.1 GFT 登录接口字段

| 字段 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `idCard` | string | 是 | 身份证号 |
| `name` | string | 是 | 姓名 |
| `phone` | string | 是 | 手机号 |
| `scope` | string | 否 | 默认传 `server` |

### 14.2 培训机构列表分页参数

| 字段 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `current` | number | 是 | 当前页码 |
| `size` | number | 是 | 每页条数 |
| `projectType` | string | 否 | 培训类型筛选 |
| `qualificationCode` | string | 否 | 资格项编码筛选 |
| `areaId` | string | 否 | 地区筛选，通常取江西市级 ID |

### 14.3 培训计划分页参数

| 字段 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `institutionId` | string | 是 | 培训机构 ID |
| `status` | string | 否 | 当前移动端固定传 `0` |
| `current` | number | 是 | 当前页码 |
| `size` | number | 是 | 每页条数 |

### 14.4 机构评价分页参数

| 字段 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `evaluationObjectId` | string | 是 | 评价对象 ID，即机构 ID |
| `current` | number | 是 | 当前页码 |
| `size` | number | 是 | 每页条数 |

### 14.5 直接报名接口字段

| 字段 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `institutionId` | string | 是 | 培训机构 ID |
| `qualificationCode` | string | 是 | 拆分后的操作项目 code |
| `projectType` | string | 是 | 培训类型 |
| `personType` | string | 是 | 人员类型 code |
| `classId` | string | 否 | 非计划报名时可不传 |

### 14.6 培训计划报名接口字段

| 字段 | 类型 | 必填 | 说明 |
| :--- | :--- | :--- | :--- |
| `institutionId` | string | 是 | 培训机构 ID |
| `qualificationCode` | string | 是 | 计划记录上的资格编码 |
| `projectType` | string | 是 | 计划记录上的培训类型 |
| `classId` | string | 是 | 培训班级 ID |

---

## 15. 推荐 TS 类型定义

### 15.1 用户信息

```ts
export interface PcUserProfile {
  id?: string | number
  realName?: string
  username?: string
  phone?: string
  idNumber?: string
}
```

### 15.2 地区节点

```ts
export interface AreaNode {
  id: string
  name: string
  parentId?: string
  level?: number
  isLeaf?: boolean
  children?: AreaNode[]
}
```

### 15.3 资格节点

```ts
export interface QualificationNode {
  code: string
  parentCode?: string
  name?: string
  names?: string
  codes?: string
  level?: number
  children?: QualificationNode[]
}
```

### 15.4 培训机构列表项

```ts
export interface TrainingInstitutionItem {
  id: string
  institutionName?: string
  name?: string
  phone?: string
  linkman?: string
  score?: string | number
  areaId?: string
  areaName?: string
  sealPath?: string
  qualificationNames?: string[]
  sitePhotoPaths?: string[]
}
```

### 15.5 培训计划项

```ts
export interface TrainingPlanItem {
  id: string
  institutionId?: string
  qualificationCode?: string
  qualificationName?: string
  projectType?: string
  projectTypeLabel?: string
  theoryStartDate?: string
  theoryEndDate?: string
  practiceStartDate?: string
  practiceEndDate?: string
  plannedTrainees?: number
}
```

### 15.6 报名提交体

```ts
export interface TrainingSignUpPayload {
  institutionId: string
  qualificationCode: string
  projectType: string
  personType?: string
  classId?: string
}
```

### 15.7 我的报名记录

```ts
export interface MyTrainingSignUpItem {
  signupId: string
  institutionId?: string
  institutionName?: string
  qualificationCode?: string
  qualificationNames?: string
  projectType?: string
  classId?: string
  status?: string
  createTime?: string
}
```

---

## 16. PC 联调检查清单

### 16.1 登录阶段
- 确认 GFT 登录接口是否可在 PC 环境直接调用
- 确认 `Authorization` 和 `Content-Type` 是否与移动端一致
- 确认登录成功后能否正确拿到 `access_token`、`refresh_token`
- 确认登录后调用 `user/profile` 返回字段是否完整

### 16.2 初始化阶段
- 确认地区接口可返回江西省
- 确认江西省下能返回全部市级列表
- 确认资格树接口能返回 `code/parentCode/level/names/codes`
- 确认机构资质接口的返回结构与全量资格树兼容

### 16.3 机构查询阶段
- 确认列表分页接口支持 `current/size`
- 确认筛选参数 `projectType/qualificationCode/areaId` 能正确生效
- 确认机构详情、培训计划分页、评价分页能通过机构 ID 串起来

### 16.4 报名阶段
- 确认直接报名场景，`qualificationCode` 是否必须传叶子节点编码
- 确认直接报名场景，`personType` 是否必传
- 确认培训计划报名场景，`classId` 是否必传
- 确认成功后返回文案、返回码、重复报名限制

### 16.5 结果追踪阶段
- 确认我的报名分页是否支持分页
- 确认报名详情是否能完整返回培训机构、项目、状态信息
- 确认是否存在撤销报名、再次报名、去支付等后续动作

---

## 17. 仍需后端或产品确认的点
- 评价分页接口前缀最终以 `/api` 还是 `/admin` 为准
- 报名接口是否支持重复提交拦截，以及重复报名时的错误码
- `projectType`、`qualificationCode`、`personType` 的最终枚举来源和字典编码
- `user/profile` 是否允许作为 PC 报名表单的默认回填数据源
- 我的报名状态枚举、状态文案、状态流转顺序
- 培训计划分页的 `status=0` 对应的准确业务含义
