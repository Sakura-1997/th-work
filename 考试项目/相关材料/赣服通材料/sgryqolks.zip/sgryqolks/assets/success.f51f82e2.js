const e=""+new URL("success.fce4049a.png",import.meta.url).href;export{e as S};
