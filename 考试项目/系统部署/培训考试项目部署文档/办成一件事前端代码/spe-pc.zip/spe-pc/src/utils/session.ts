import { computed, readonly, ref } from 'vue'

import type { UserProfileState } from '@/types/training'

const TOKEN_KEY = 'token'
const REFRESH_TOKEN_KEY = 'refresh_token'
const TENANT_ID_KEY = 'tenantId'
const USER_PROFILE_KEY = 'user_profile'
const AREA_TREE_CACHE_KEY = 'areaTreeCache'
const QUALIFICATION_TREE_CACHE_KEY = 'qualificationTreeCache'
const PROJECT_TYPE_DICT_CACHE_KEY = 'projectTypeDictCache'

function readStorage<T>(key: string, fallback: T): T {
  const rawValue = window.sessionStorage.getItem(key)

  if (!rawValue) {
    return fallback
  }

  try {
    return JSON.parse(rawValue) as T
  } catch {
    return fallback
  }
}

function writeStorage(key: string, value: unknown) {
  window.sessionStorage.setItem(key, JSON.stringify(value))
}

const tokenState = ref(readStorage<string>(TOKEN_KEY, ''))
const refreshTokenState = ref(readStorage<string>(REFRESH_TOKEN_KEY, ''))
const tenantIdState = ref(readStorage<string>(TENANT_ID_KEY, ''))
const userProfileState = ref<UserProfileState | null>(readStorage<UserProfileState | null>(USER_PROFILE_KEY, null))

export function getToken() {
  return tokenState.value
}

export function getRefreshToken() {
  return refreshTokenState.value
}

export function setAuthSession(payload: { token: string; refreshToken?: string; tenantId?: string }) {
  const token = payload.token
  const refreshToken = payload.refreshToken || ''
  const tenantId = payload.tenantId || ''

  tokenState.value = token
  refreshTokenState.value = refreshToken
  tenantIdState.value = tenantId

  writeStorage(TOKEN_KEY, token)
  writeStorage(REFRESH_TOKEN_KEY, refreshToken)
  writeStorage(TENANT_ID_KEY, tenantId)
}

export function clearAuthSession() {
  tokenState.value = ''
  refreshTokenState.value = ''
  tenantIdState.value = ''
  userProfileState.value = null

  window.sessionStorage.removeItem(TOKEN_KEY)
  window.sessionStorage.removeItem(REFRESH_TOKEN_KEY)
  window.sessionStorage.removeItem(TENANT_ID_KEY)
  window.sessionStorage.removeItem(USER_PROFILE_KEY)
}

export function getUserProfile() {
  return userProfileState.value
}

export function setUserProfile(profile: UserProfileState) {
  userProfileState.value = profile
  writeStorage(USER_PROFILE_KEY, profile)
}

export function useSessionState() {
  return {
    token: readonly(tokenState),
    refreshToken: readonly(refreshTokenState),
    tenantId: readonly(tenantIdState),
    userProfile: readonly(userProfileState),
    hasLogin: computed(() => Boolean(tokenState.value)),
  }
}

export function setAreaTreeCache(tree: unknown) {
  writeStorage(AREA_TREE_CACHE_KEY, tree)
}

export function getAreaTreeCache<T>() {
  return readStorage<T | null>(AREA_TREE_CACHE_KEY, null)
}

export function setQualificationTreeCache(tree: unknown) {
  writeStorage(QUALIFICATION_TREE_CACHE_KEY, tree)
}

export function getQualificationTreeCache<T>() {
  return readStorage<T | null>(QUALIFICATION_TREE_CACHE_KEY, null)
}

export function setProjectTypeDictCache(dictList: unknown) {
  writeStorage(PROJECT_TYPE_DICT_CACHE_KEY, dictList)
}

export function getProjectTypeDictCache<T>() {
  return readStorage<T | null>(PROJECT_TYPE_DICT_CACHE_KEY, null)
}
