import { computed, reactive } from 'vue'

const loadingState = reactive({
  count: 0,
  text: '加载中...',
})

export function showGlobalLoading(text = '加载中...') {
  loadingState.count += 1
  loadingState.text = text
}

export function hideGlobalLoading() {
  loadingState.count = Math.max(0, loadingState.count - 1)

  if (loadingState.count === 0) {
    loadingState.text = '加载中...'
  }
}

export function useGlobalLoading() {
  return {
    visible: computed(() => loadingState.count > 0),
    text: computed(() => loadingState.text),
  }
}
