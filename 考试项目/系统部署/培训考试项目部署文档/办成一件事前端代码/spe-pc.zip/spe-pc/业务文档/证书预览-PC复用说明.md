# 证书预览-PC复用说明

## 1. 目标说明

本文档基于移动端证书管理中的“证书详情/证书预览”实现整理，用于指导 PC 端复用同一套证书预览样式与字段布局。

当前移动端预览不是独立组件，而是直接实现于：

- `src/views/certificateDetail/index.vue`

相关数据与资源来源：

- 列表接口：`POST /admin/app/certificate/queryMyCertificate`
- 详情接口：`GET /admin/app/certificate/detail`
- 证件照预览接口：`GET /admin/sys-file/oss/file`
- 背景资源目录：`src/assets/images/certificate/`

## 2. 预览页面结构

移动端证书预览页面由两张卡片组成：

- 第一张：证书反面，包含背景图、照片、证号、姓名、类别、日期、签发机关、二维码等覆盖字段
- 第二张：证书正面，仅展示正面背景模板

DOM 结构可以抽象为：

```html
<div class="certificate-preview-page">
  <div class="cert-card">
    <div class="cert-shell cert-container">
      <img class="cert-bg" />
      <div class="cert-photo"><img /></div>
      <div class="cert-info-no">...</div>
      <div class="cert-info-name">...</div>
      <div class="cert-info-type">...</div>
      <div class="cert-info-gender">...</div>
      <div class="cert-info-type-wide">...</div>
      <div class="cert-info-issue">...</div>
      <div class="cert-info-valid">...</div>
      <div class="cert-info-org-left">...</div>
      <img class="cert-qr" />
    </div>
  </div>

  <div class="cert-card">
    <div class="cert-shell">
      <img class="cert-bg" />
    </div>
  </div>
</div>
```

## 3. 证书类型与模板图

移动端当前支持两类证书模板：

### 3.1 蓝底证书

- 证书类型码：`certificateTypeCode === '1'`
- 业务名称：特种作业操作证
- 正面图：`blue-front.png`
- 反面图：`blue-back-no-text.png`
- 强调色：`#005bac`

### 3.2 绿底证书

- 证书类型码：`certificateTypeCode === '2'`
- 业务名称：安全生产知识和管理能力考核合格证
- 正面图：`green-front.png`
- 反面图：`green-back-no-text.png`
- 强调色：`#008b45`

## 4. 数据来源与渲染逻辑

### 4.1 数据流

移动端采用“先展示列表透传数据，再用详情接口覆盖刷新”的方式：

1. 列表页进入详情页时，将当前证书对象塞入路由 `query.data`
2. 详情页初始化时优先解析 `query.data`
3. 详情页拿到 `certificateId` 后调用详情接口刷新数据
4. 当 `imgPath` 发生变化时，异步转成图片预览地址

### 4.2 关键字段

公共字段：

- `certificateId`
- `certificateType` 或 `workType`
- `certNo`
- `name`
- `gender`
- `issueDate`
- `validStartDate`
- `validEndDate`
- `issuingAuthority`
- `imgPath`
- `qrCodeUrl`

蓝底证书专用展示字段：

- `jobTypeCodeDictText`
- `operItemCodeDictText`

绿底证书专用展示字段：

- `personnelType`
- `industryType`

### 4.3 图片处理规则

证件照 `imgPath` 的处理逻辑如下：

- 如果已经是完整 URL、`data:`、`blob:`，则直接使用
- 如果是系统文件路径或文件名，则调用 `/admin/sys-file/oss/file?base64=true`
- 最终将返回值拼成 `data:image/*;base64,...` 形式供 `<img>` 渲染

PC 端建议沿用相同逻辑，避免直接暴露内部文件路径。

## 5. 字段布局说明

反面卡片中的字段全部采用“绝对定位覆盖到背景图”方式实现。

### 5.1 蓝底证书字段

| 区块 | 标签文案 | 字段 |
| --- | --- | --- |
| 照片 | 无 | `imgPath` |
| 证号 | 证号 | `certNo` |
| 姓名 | 姓名 | `name` |
| 作业类别 | 作业类别 | `jobTypeCodeDictText` |
| 性别 | 性别 | `gender` 字典映射 |
| 操作项目 | 操作项目 | `operItemCodeDictText` |
| 初领日期 | 初领日期 | `issueDate` |
| 有效期限 | 有效期限 | `validStartDate` + `validEndDate` |
| 签发机关 | 签发机关 | `issuingAuthority` |
| 二维码 | 无 | `qrCodeUrl` |

### 5.2 绿底证书字段

| 区块 | 标签文案 | 字段 |
| --- | --- | --- |
| 照片 | 无 | `imgPath` |
| 证号 | 证号 | `certNo` |
| 姓名 | 姓名 | `name` |
| 人员类型 | 人员类型 | `personnelType`，缺省回退 `codes` |
| 性别 | 性别 | `gender` 字典映射 |
| 行业类别 | 行业类别 | `industryType`，缺省回退 `codes` |
| 初领日期 | 初领日期 | `issueDate` |
| 有效期限 | 有效期限 | `validStartDate` + `validEndDate` |
| 签发机关 | 签发机关 | `issuingAuthority` |
| 二维码 | 无 | `qrCodeUrl` |

## 6. 样式规则

### 6.1 基础比例

移动端使用证件比例：

```scss
aspect-ratio: 1.58;
```

该比例接近标准证卡尺寸比 `85.6 / 53.98 ≈ 1.586`。

PC 端建议也固定为该比例，避免文字定位偏移。

### 6.2 容器缩放方式

移动端的关键做法是：

```scss
.cert-container {
  container-type: inline-size;
}
```

再配合 `cqw` 容器单位控制字体与间距：

```scss
.cert-label {
  font-size: 2.06cqw;
}

.cert-value {
  font-size: 3.09cqw;
}

.cert-value-lg {
  font-size: 3.92cqw;
}
```

这意味着所有文字尺寸会随卡片宽度等比缩放。

### 6.3 字体

移动端当前使用：

```scss
font-family: 'Source Han Sans CN', 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif;
```

PC 端建议继续沿用，确保中英文和数字的视觉接近。

### 6.4 文本层级

```scss
.cert-label {
  font-size: 2.06cqw;
  font-weight: 400;
  margin-bottom: 1.17cqw;
  line-height: 1;
}

.cert-value {
  font-size: 3.09cqw;
  font-weight: 400;
  color: #000;
  line-height: 1.2;
}

.cert-value-lg {
  font-size: 3.92cqw;
  font-weight: 400;
  color: #000;
  line-height: 1.2;
}
```

颜色约定：

- 主标签色：`var(--ui-text-primary)` 或深色正文
- 蓝证强调色：`#005bac`
- 绿证强调色：`#008b45`
- 正文色：`#000`

## 7. 定位参数

以下百分比均来自当前移动端实现，可直接复用于 PC 端。

### 7.1 反面卡片定位

```scss
.cert-photo {
  left: 5.8%;
  top: 11.1%;
  width: 23.4%;
  height: 46.3%;
}

.cert-info-no {
  left: 32.7%;
  top: 11.1%;
}

.cert-info-name {
  left: 32.7%;
  top: 26%;
}

.cert-info-type {
  left: 58%;
  top: 26%;
}

.cert-info-gender {
  left: 32.7%;
  top: 41%;
}

.cert-info-type-wide {
  left: 58%;
  top: 41%;
  width: 38%;
}

.cert-info-issue {
  left: 5.8%;
  top: 66%;
}

.cert-info-valid {
  left: 32.7%;
  top: 66%;
}

.cert-info-org-left {
  left: 5.8%;
  top: 81%;
}

.cert-qr {
  right: 7%;
  bottom: 9.3%;
  width: 17.5%;
  aspect-ratio: 1;
}
```

### 7.2 样式解释

- 照片区域位于左侧上半区
- 编号、姓名、类别、性别等信息位于右侧分栏
- `cert-info-type-wide` 是右侧宽字段，蓝证为“操作项目”，绿证为“行业类别”
- `cert-qr` 放在右下角，并固定为正方形

## 8. PC 端建议实现方式

### 8.1 推荐布局策略

PC 端建议不要改成表格式详情，应继续采用“背景图 + 绝对定位”的方案，理由如下：

- 能最大程度还原实体证书视觉效果
- 可以与移动端共用同一套字段定位参数
- 后续若要支持导出截图、打印、生成 PDF，更容易扩展

### 8.2 推荐组件拆分

建议在 PC 端拆成以下结构：

- `CertificatePreview.vue`
- `CertificatePreviewBack.vue`
- `CertificatePreviewFront.vue`
- `useCertificatePreview.ts` 或等价数据处理模块

### 8.3 推荐 props

```ts
type CertificatePreviewData = {
  certificateId?: string
  certificateType?: string
  workType?: string
  certNo?: string
  name?: string
  gender?: string | number
  jobTypeCodeDictText?: string
  operItemCodeDictText?: string
  personnelType?: string
  industryType?: string
  issueDate?: string
  validStartDate?: string
  validEndDate?: string
  issuingAuthority?: string
  imgPath?: string
  qrCodeUrl?: string
}
```

### 8.4 推荐宽度

PC 端可按以下任一方案设置容器宽度：

- 常规详情页：`width: 640px`
- 弹窗预览：`width: 720px`
- 大屏展示：`width: 800px`

只要保持 `aspect-ratio: 1.58` 和百分比定位，布局就能稳定缩放。

## 9. PC 端参考样式

以下样式可直接作为 PC 端初版：

```scss
.certificate-preview-page {
  display: flex;
  flex-direction: column;
  gap: 24px;
}

.cert-card {
  width: 720px;
}

.cert-shell {
  position: relative;
  width: 100%;
  aspect-ratio: 1.58;
  overflow: hidden;
  border-radius: 16px;
  background: #fff;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
}

.cert-container {
  container-type: inline-size;
  font-family: 'Source Han Sans CN', 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif;
}

.cert-bg {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.cert-label {
  font-size: 2.06cqw;
  font-weight: 400;
  margin-bottom: 1.17cqw;
  line-height: 1;
}

.cert-label-main {
  color: #222;
}

.cert-label-blue {
  color: #005bac;
}

.cert-label-green {
  color: #008b45;
}

.cert-value {
  font-size: 3.09cqw;
  font-weight: 400;
  color: #000;
  line-height: 1.2;
}

.cert-value-lg {
  font-size: 3.92cqw;
  font-weight: 400;
  color: #000;
  line-height: 1.2;
}

.cert-photo,
.cert-info-no,
.cert-info-name,
.cert-info-type,
.cert-info-gender,
.cert-info-type-wide,
.cert-info-issue,
.cert-info-valid,
.cert-info-org-left,
.cert-qr {
  position: absolute;
}
```

定位参数沿用第 7 节即可。

## 10. 迁移注意事项

### 10.1 性别字段

移动端不是直接显示 `1/2`，而是通过 `gender` 字典映射成中文文案。PC 端也应保持一致。

### 10.2 证件照字段

后端返回的 `imgPath` 不一定是完整 URL，PC 端需要保留文件预览转换逻辑。

### 10.3 缺省值处理

当前移动端对大部分字段均使用 `|| '-'` 回退，PC 端建议保持一致，避免空白块显得像渲染异常。

### 10.4 正反面资源

PC 端请直接复用当前背景图资源，避免重新切图后导致定位参数失准。

## 11. 对应代码位置

如需对照现有实现，请参考：

- 预览主页面：`src/views/certificateDetail/index.vue`
- 证书接口：`src/api/certificate/index.ts`
- 图片预览处理：`src/api/admin/file.ts`
- 背景图目录：`src/assets/images/certificate/`

## 12. 建议的后续动作

如果后续需要在移动端和 PC 端统一维护，建议将当前页面实现再抽一层为“证书预览基础组件”，统一沉淀：

- 模板切换逻辑
- 字段映射逻辑
- 图片预览逻辑
- 正反面样式 token

这样后续两端仅维护容器尺寸和外层交互，不再重复维护证书内部定位。
