<script setup lang="ts">
import { Phone, X } from '@lucide/vue'
import { ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

import bannerImage from '@/assets/713229a80810c8359a3e2c02498d0168.jpg'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { showGlobalLoading } from '@/composables/use-global-loading'
import { showGlobalMessage } from '@/composables/use-global-message'
import { useTrustedLogin } from '@/composables/use-trusted-login'
import {
  canUseLegacyTrustedLogin,
  canUseTrustedLogin,
  getJiangxiLegacyLoginUrl,
  getJiangxiTrustedTransferUrl,
  hasTrustedAutoLoginStarted,
  markTrustedAutoLoginStarted,
} from '@/services/auth'
import { clearAuthSession, useSessionState } from '@/utils/session'

type HomeTabKey = 'conditions' | 'fees' | 'materials' | 'process'

const isDev = import.meta.env.DEV
const router = useRouter()
const route = useRoute()
const { userProfile, hasLogin } = useSessionState()
const activeTab = ref<HomeTabKey>('conditions')
const contactDialogVisible = ref(false)
const { trustedLoginLoading, getTrustedTicket, handleTrustedLogin } = useTrustedLogin(route, router)

const baseInfoRows = [
  { label: '服务对象', value: '个人' },
  { label: '牵头单位', value: '省应急管理厅' },
  { label: '办理方式', value: '网上办理，窗口办理' },
  {
    label: '办理地点',
    value: '线上：“赣服通”平台、江西政务服务网“高效办成一件事”专区；\n线下：各地市考试机构',
  },
  {
    label: '办理时间',
    value: '线上：全天候；\n线下：按各地办理窗口工作时间',
  },
  { label: '咨询方式', value: '查看联系方式' },
]

const contactList = [
  {
    title: '省应急管理宣传教育中心（省级考试机构）',
    phones: ['0791-86500080', '15270002360'],
    tag: '省级',
  },
  { title: '南昌市应急管理局', phones: ['0791-87830809'], tag: '地市' },
  { title: '九江市应急管理局', phones: ['0792-8585369'], tag: '地市' },
  { title: '景德镇市应急管理局', phones: ['0798-8330595'], tag: '地市' },
  { title: '萍乡市应急管理局', phones: ['0799-6773820'], tag: '地市' },
  { title: '新余市应急管理局', phones: ['0790-6430151'], tag: '地市' },
  { title: '鹰潭市应急管理局', phones: ['0701-6699545'], tag: '地市' },
  { title: '赣州市应急管理局', phones: ['0797-8991178'], tag: '地市' },
  { title: '宜春市应急管理局', phones: ['0795-3590929'], tag: '地市' },
  { title: '上饶市应急管理局', phones: ['0793-8214403'], tag: '地市' },
  { title: '吉安市应急管理局', phones: ['0796-8230856'], tag: '地市' },
  { title: '抚州市应急管理局', phones: ['0794-8999122'], tag: '地市' },
]

const relatedMatters = [
  '特种作业操作证（初次取证）',
  '特种作业操作证（换证）',
  '安全生产知识和管理能力考核合格证（初次取证）',
  '安全生产知识和管理能力考核合格证（换证）',
]

const conditionList = [
  '年满18周岁，且不超过国家法定退休年龄；',
  '无妨碍从事相应特种作业的器质性心脏病、癫痫病、美尼尔氏症、眩晕症、癔症、帕金森病、精神病、痴呆及影响肢体活动的神经系统疾病等疾病或生理缺陷，并提交个人健康书面承诺（无需体检证明）；',
  '申请煤矿、金属非金属矿山、石油天然气、冶金、烟花爆竹特种作业的，须具备初中及以上文化程度；申请危险化学品特种作业、首次取证的地下矿山特种作业的，须具备高中或相当于高中及以上文化程度；',
  '具备必要的安全技术知识与操作技能；',
  '免培训条件（符合之一即可直接申请考试）：取得中等职业学校（含技工学校）及以上学历，申请与其所学专业相应的特种作业操作证；持有合法有效的职业技能等级证书，申请与其职业技能相应的特种作业操作证。',
]

const tabOptions = [
  { key: 'conditions', label: '申报条件' },
  { key: 'fees', label: '是否收费' },
  { key: 'materials', label: '申报材料' },
  { key: 'process', label: '办理流程' },
] satisfies Array<{ key: HomeTabKey; label: string }>

const materials = [
  { required: '必需', name: '江西省特种作业操作证考核申请表', requirement: '电子材料/纸质材料', sample: '--' },
  { required: '必需', name: '身份证复印件', requirement: '电子材料/纸质材料', sample: '--' },
]

const processSteps = [
  '选择培训机构并确认报名信息',
  '按要求提交申报材料并完成资料核验',
  '参加培训与考试，审核通过后取得相关证书',
]

const getCurrentHomeUrl = () => {
  const currentUrl = new URL(window.location.href)

  currentUrl.searchParams.delete('ticket')
  currentUrl.searchParams.delete('gotourl')

  return currentUrl.toString()
}

const redirectToTrustedTransfer = () => {
  if (!canUseTrustedLogin()) {
    showGlobalMessage('江西可信登录配置缺失，请联系管理员')
    return false
  }

  markTrustedAutoLoginStarted()
  showGlobalLoading('正在跳转江西可信登录...')
  window.location.replace(getJiangxiTrustedTransferUrl(getCurrentHomeUrl()))
  return true
}

const redirectToLegacyLogin = () => {
  if (!canUseLegacyTrustedLogin()) {
    showGlobalMessage('江西可信单点登录配置缺失，请联系管理员')
    return false
  }

  showGlobalLoading('正在跳转江西可信登录...')
  window.location.replace(getJiangxiLegacyLoginUrl(getCurrentHomeUrl()))
  return true
}

const handleGoInstitutions = async () => {
  if (trustedLoginLoading.value) {
    return
  }

  if (hasLogin.value) {
    router.push('/institutions')
    return
  }

  if (isDev) {
    router.push('/login')
    return
  }

  if (getTrustedTicket()) {
    const loginSucceeded = await handleTrustedLogin()

    if (loginSucceeded) {
      router.push('/institutions')
      return
    }
  }

  redirectToLegacyLogin()
}

const logout = () => {
  clearAuthSession()
  router.push('/login')
}

watch(
  () => route.query.ticket,
  async (ticket) => {
    if (hasLogin.value) {
      return
    }

    if (ticket) {
      await handleTrustedLogin()
      return
    }

    if (!isDev && !hasTrustedAutoLoginStarted()) {
      redirectToTrustedTransfer()
    }
  },
  {
    immediate: true,
  },
)

</script>

<template>
  <main class="min-h-screen bg-slate-100">
    <section class="relative overflow-hidden bg-[#2f73db]">
      <div
        class="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-90"
        :style="{ backgroundImage: `url(${bannerImage})` }"
      ></div>
      <div class="absolute inset-0 bg-[linear-gradient(90deg,rgba(22,86,203,0.94),rgba(46,115,219,0.86),rgba(46,115,219,0.68))]"></div>
      <div class="absolute inset-0 bg-[radial-gradient(circle_at_55%_35%,rgba(255,255,255,0.18),transparent_28%),radial-gradient(circle_at_75%_45%,rgba(255,255,255,0.12),transparent_24%)]"></div>
      <div class="relative mx-auto flex h-[320px] max-w-[1320px] items-start justify-between px-8 pt-8">
        <div class="pt-12 text-white">
          <h1 class="text-[38px] font-semibold leading-[1.3]">特种作业人员职业资格认定一件事</h1>
          <p class="mt-4 text-[18px] text-white/92">一表申请、一次提交、一网通办</p>
          <Button
            class="mt-8 rounded-full bg-[#f6a623] px-8 text-white hover:bg-[#ef9a12]"
            :disabled="trustedLoginLoading"
            @click="handleGoInstitutions"
          >
            {{ trustedLoginLoading ? '登录中...' : '立即办理' }}
          </Button>
        </div>

        <div v-if="hasLogin" class="flex items-center gap-3 rounded-full bg-white/10 px-4 py-2 text-sm text-white backdrop-blur">
          <span>用户姓名：{{ userProfile?.userName || '--' }}</span>
          <Button variant="outline" class="border-white/50 bg-white/10 text-white hover:bg-white/20" @click="logout">
            退出登录
          </Button>
        </div>
      </div>
    </section>

    <section class="relative z-10 -mt-10 pb-12">
      <div class="mx-auto max-w-[1320px] px-8">
        <div class="space-y-4">
          <Card class="rounded-[6px] border border-slate-200 bg-white p-0">
            <div class="border-b border-slate-200 px-6 py-5">
              <div class="flex items-center gap-3 text-[28px] font-semibold text-slate-800">
                <span class="h-6 w-1 rounded-full bg-blue-600"></span>
                <span>特种作业人员职业资格认定一件事</span>
              </div>
            </div>

            <div class="grid grid-cols-[1.45fr_0.95fr] gap-5 p-6">
              <div class="overflow-hidden rounded-[4px] border border-slate-200">
                <div
                  v-for="row in baseInfoRows"
                  :key="row.label"
                  class="grid min-h-[68px] grid-cols-[120px_1fr] border-b border-slate-200 text-[15px] last:border-b-0"
                >
                  <div class="flex items-center bg-slate-50 px-4 font-medium text-slate-500">{{ row.label }}</div>
                  <div class="flex items-center whitespace-pre-line px-4 leading-7 text-slate-700">
                    <template v-if="row.label === '咨询方式'">
                      <div class="flex items-center gap-4">
                        <span class="text-slate-500">省级及地市联系方式</span>
                        <button
                          type="button"
                          class="rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-sm text-blue-600 transition hover:bg-blue-100"
                          @click="contactDialogVisible = true"
                        >
                          {{ row.value }}
                        </button>
                      </div>
                    </template>
                    <template v-else>
                      {{ row.value }}
                    </template>
                  </div>
                </div>
              </div>

              <div class="overflow-hidden rounded-[4px] bg-[#eef5ff]">
                <div class="border-b border-blue-100 bg-[linear-gradient(90deg,rgba(208,227,255,0.95),rgba(235,244,255,0.9))] px-5 py-4">
                  <div class="flex items-start justify-between gap-4">
                    <div>
                      <h3 class="text-lg font-semibold text-slate-800">联办事项</h3>
                      <p class="mt-2 inline-flex rounded-full bg-white px-3 py-1 text-xs text-blue-600 shadow-sm">
                        承诺办结时限：10个工作日
                      </p>
                    </div>
                    <!-- <div class="h-14 w-14 rounded-2xl bg-blue-500/10"></div> -->
                  </div>
                </div>

                <div class="space-y-3 p-5">
                  <div
                    v-for="item in relatedMatters"
                    :key="item"
                    class="rounded-[4px] bg-white px-4 py-3 text-sm text-slate-700 shadow-[0_0_0_1px_rgba(226,232,240,0.75)]"
                  >
                    {{ item }}
                  </div>
                </div>
              </div>
            </div>
          </Card>

          <Card class="rounded-[6px] border border-slate-200 bg-white p-4">
            <div class="grid grid-cols-4 gap-0 overflow-hidden rounded-[4px] border border-slate-200 bg-slate-50">
              <button
                v-for="tab in tabOptions"
                :key="tab.key"
                type="button"
                class="relative h-14 text-base font-medium transition"
                :class="
                  activeTab === tab.key
                    ? 'bg-blue-600 text-white'
                    : 'border-r border-slate-200 text-slate-700 last:border-r-0 hover:bg-slate-100'
                "
                @click="activeTab = tab.key"
              >
                {{ tab.label }}
                <span
                  v-if="activeTab === tab.key"
                  class="absolute left-1/2 top-full h-0 w-0 -translate-x-1/2 border-x-[10px] border-t-[10px] border-x-transparent border-t-blue-600"
                ></span>
              </button>
            </div>

            <div class="mt-6 min-h-[280px] rounded-[4px] bg-slate-50 p-5">
              <div v-if="activeTab === 'conditions'" class="space-y-4 text-[15px] leading-8 text-slate-700">
                <div v-for="(condition, index) in conditionList" :key="index" class="flex items-start gap-3">
                  <span class="shrink-0 font-medium text-slate-800">{{ index + 1 }}.</span>
                  <p>{{ condition }}</p>
                </div>
              </div>

              <div v-else-if="activeTab === 'fees'" class="space-y-3 text-[15px] leading-8 text-slate-700">
                <div>
                  <span class="font-medium text-slate-800">是否收费：</span>
                  <span>是；</span>
                </div>
                <div>
                  <span class="font-medium text-slate-800">收费标准：</span>
                  <span>
                    特种作业人员安全生产理论知识考试考务费 56元/人·科、特种作业人员特种作业安全技术实践操作考试考务费 103元/人·科&lt;工种&gt;。
                  </span>
                </div>
              </div>

              <div v-else-if="activeTab === 'materials'">
                <div class="overflow-hidden rounded-[4px] border border-slate-200 bg-white">
                  <div class="grid grid-cols-[88px_1.6fr_1fr_120px] bg-slate-50 text-sm font-medium text-slate-600">
                    <div class="px-4 py-4">类型</div>
                    <div class="border-l border-slate-200 px-4 py-4">材料名称</div>
                    <div class="border-l border-slate-200 px-4 py-4">材料要求</div>
                    <!-- <div class="border-l border-slate-200 px-4 py-4">示例样本</div> -->
                  </div>
                  <div
                    v-for="item in materials"
                    :key="item.name"
                    class="grid grid-cols-[88px_1.6fr_1fr_120px] border-t border-slate-200 text-sm text-slate-700"
                  >
                    <div class="px-4 py-4">
                      <span class="rounded bg-blue-50 px-2 py-1 text-xs text-blue-600">{{ item.required }}</span>
                    </div>
                    <div class="border-l border-slate-200 px-4 py-4">{{ item.name }}</div>
                    <div class="border-l border-slate-200 px-4 py-4">{{ item.requirement }}</div>
                    <!-- <div class="border-l border-slate-200 px-4 py-4">{{ item.sample }}</div> -->
                  </div>
                </div>
              </div>

              <div v-else class="space-y-4 text-[15px] leading-8 text-slate-700">
                <div
                  v-for="(step, index) in processSteps"
                  :key="step"
                  class="flex items-start gap-4 rounded-[4px] bg-white px-5 py-4 shadow-[0_0_0_1px_rgba(226,232,240,0.75)]"
                >
                  <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-blue-600 text-sm font-semibold text-white">
                    {{ index + 1 }}
                  </div>
                  <div>{{ step }}</div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
    <Teleport to="body">
      <div
        v-if="contactDialogVisible"
        class="fixed inset-0 z-[9998] flex items-center justify-center bg-slate-950/30 px-4"
        @click.self="contactDialogVisible = false"
      >
        <Card class="w-full max-w-[980px] p-0 shadow-2xl">
          <div class="flex items-center justify-between border-b border-slate-200 px-6 py-5">
            <div>
              <h3 class="text-xl font-semibold text-slate-900">咨询方式</h3>
              <p class="mt-1 text-sm text-slate-500">省级和各地市考试咨询电话</p>
            </div>
            <button
              type="button"
              class="rounded-full p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
              @click="contactDialogVisible = false"
            >
              <X class="h-5 w-5" />
            </button>
          </div>

          <div class="max-h-[70vh] overflow-y-auto px-6 py-6">
            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div
                v-for="item in contactList"
                :key="item.title"
                class="rounded-2xl border border-slate-200 bg-slate-50 px-5 py-4"
                :class="item.tag === '省级' ? 'md:col-span-2 border-blue-200 bg-blue-50/60' : ''"
              >
                <div class="flex items-start justify-between gap-3">
                  <div>
                    <div class="text-base font-semibold text-slate-800">{{ item.title }}</div>
                    <div class="mt-3 space-y-2">
                      <div
                        v-for="phone in item.phones"
                        :key="phone"
                        class="flex items-center gap-2 text-sm text-slate-600"
                      >
                        <Phone class="h-4 w-4 text-blue-600" />
                        <span>{{ phone }}</span>
                      </div>
                    </div>
                  </div>
                  <span
                    class="rounded-full px-3 py-1 text-xs font-medium"
                    :class="item.tag === '省级' ? 'bg-blue-100 text-blue-600' : 'bg-white text-slate-500'"
                  >
                    {{ item.tag }}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </Teleport>
  </main>
</template>
