<script setup lang="ts">
import { computed, onMounted, ref } from 'vue'
import { useRouter } from 'vue-router'
import { Eye, FileDown } from '@lucide/vue'

import { fetchMyCertificateList } from '@/api/certificate'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { hideGlobalLoading, showGlobalLoading } from '@/composables/use-global-loading'
import { showGlobalMessage } from '@/composables/use-global-message'
import { normalizeCertificatePreviewData } from '@/composables/use-certificate-preview'
import type { CertificatePreviewData, CertificateRecordRaw } from '@/types/certificate'
import { clearAuthSession, getUserProfile } from '@/utils/session'
import { getErrorMessage } from '@/utils/training'

const router = useRouter()
const userProfile = getUserProfile()
const loading = ref(false)
const certificates = ref<CertificatePreviewData[]>([])

const certificateCountText = computed(() => `共 ${certificates.value.length} 本证书`)

function resolveCertificateTypeName(item: CertificatePreviewData) {
  const candidate = [item.certificateTypeCode, item.certificateType, item.workType, item.names]
    .map((value) => String(value || '').trim())
    .find(Boolean)
    ?.toLowerCase()

  if (
    candidate === '2' ||
    candidate?.includes('安全生产') ||
    candidate?.includes('管理能力') ||
    item.personnelType
  ) {
    return '安全生产知识和管理能力考核合格证'
  }

  return '特种作业操作证'
}

function formatDateText(value: string) {
  const normalizedValue = String(value || '').trim()

  if (!normalizedValue) {
    return '-'
  }

  return normalizedValue.replace(/[T\s].*$/, '').replace(/[./]/g, '-')
}

function buildValidDateText(item: CertificatePreviewData) {
  return `${formatDateText(item.validStartDate)} 至 ${formatDateText(item.validEndDate)}`
}

function goPreview(item: CertificatePreviewData) {
  const targetId = item.certificateId || ''

  if (!targetId) {
    showGlobalMessage('未获取到证书 ID，暂无法预览')
    return
  }

  router.push({
    name: 'certificate-preview',
    params: {
      id: targetId,
    },
    query: {
      certificateId: targetId,
      data: JSON.stringify(item.raw || item),
    },
  })
}

function logout() {
  clearAuthSession()
  router.push('/login')
}

async function fetchCertificates() {
  loading.value = true
  showGlobalLoading('正在加载我的证书...')

  try {
    const response = await fetchMyCertificateList()
    const listData = Array.isArray(response.data)
      ? response.data
      : response.data.records || response.data.list || []

    certificates.value = (listData as CertificateRecordRaw[])
      .map((item) => normalizeCertificatePreviewData(item))
      .filter((item): item is CertificatePreviewData => Boolean(item))
  } catch (error) {
    certificates.value = []
    showGlobalMessage(getErrorMessage(error))
  } finally {
    hideGlobalLoading()
    loading.value = false
  }
}

onMounted(() => {
  fetchCertificates()
})
</script>

<template>
  <main class="px-8 py-8">
    <div class="mx-auto flex max-w-[1320px] flex-col gap-6">
      <div class="flex items-center justify-between rounded-lg border border-slate-200 bg-white px-6 py-4 shadow-soft">
        <div class="flex items-center gap-3">
          <Button variant="outline" @click="router.push('/')">返回首页</Button>
          <div>
            <div class="text-xl font-semibold text-slate-900">我的证书</div>
            <div class="text-sm text-slate-500">{{ certificateCountText }}</div>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <div class="text-sm text-slate-500">
            用户姓名：
            <span class="font-medium text-slate-700">{{ userProfile?.userName || '-' }}</span>
          </div>
          <Button variant="outline" @click="logout">退出登录</Button>
        </div>
      </div>

      <div v-if="certificates.length > 0" class="grid gap-4">
        <Card v-for="item in certificates" :key="`${item.certificateId}-${item.certNo}`" class="rounded-lg p-6">
          <div class="flex flex-wrap items-start justify-between gap-6">
            <div class="grid min-w-0 flex-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
              <div>
                <div class="mb-1 text-xs text-slate-400">证书类型</div>
                <div class="font-medium text-slate-900">{{ resolveCertificateTypeName(item) }}</div>
              </div>
              <div>
                <div class="mb-1 text-xs text-slate-400">证书编号</div>
                <div class="font-medium text-slate-900">{{ item.certNo || '-' }}</div>
              </div>
              <div>
                <div class="mb-1 text-xs text-slate-400">持证人</div>
                <div class="font-medium text-slate-900">{{ item.name || '-' }}</div>
              </div>
              <div>
                <div class="mb-1 text-xs text-slate-400">初领日期</div>
                <div class="font-medium text-slate-900">{{ formatDateText(item.issueDate) }}</div>
              </div>
              <div>
                <div class="mb-1 text-xs text-slate-400">有效期限</div>
                <div class="font-medium text-slate-900">{{ buildValidDateText(item) }}</div>
              </div>
              <div>
                <div class="mb-1 text-xs text-slate-400">签发机关</div>
                <div class="font-medium text-slate-900">{{ item.issuingAuthority || '-' }}</div>
              </div>
            </div>

            <div class="flex shrink-0 items-center gap-3">
              <Button variant="outline" @click="goPreview(item)">
                <Eye class="h-4 w-4" />
                证书预览
              </Button>
              <Button @click="goPreview(item)">
                <FileDown class="h-4 w-4" />
                前往下载
              </Button>
            </div>
          </div>
        </Card>
      </div>

      <Card v-else class="rounded-lg p-12 text-center">
        <div class="space-y-3">
          <p class="text-lg font-medium text-slate-900">{{ loading ? '证书加载中...' : '暂无证书数据' }}</p>
          <p class="text-sm text-slate-500">查询到证书后，可进入预览页查看证书正反面并下载 PDF。</p>
        </div>
      </Card>

      <Card class="rounded-lg border border-blue-100 bg-blue-50/60 p-5">
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div class="space-y-2">
            <div class="text-base font-medium text-slate-900">官方证书查询平台</div>
            <p class="text-sm leading-6 text-slate-600">
              如需进一步核验证书信息，您也可以前往特种作业操作证及安全生产知识和管理能力考核合格信息查询平台进行官方查询。
            </p>
          </div>
          <a
            href="https://cx.mem.gov.cn/"
            target="_blank"
            rel="noopener noreferrer"
            class="inline-flex shrink-0 items-center justify-center rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700"
          >
            前往官方平台查询
          </a>
        </div>
      </Card>
    </div>
  </main>
</template>
