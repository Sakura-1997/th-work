import request from '@/utils/request'
import type { ApiResponse } from '@/types/api'

export function fetchCurrentUserProfile() {
  return request<ApiResponse<Record<string, unknown>>>({
    url: '/admin/app/user/profile',
    method: 'get',
  })
}
