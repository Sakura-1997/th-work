import { fetchDictByType } from '@/api/dict'
import { fetchAreaDetails, fetchQualificationDetails } from '@/api/common'
import type { OptionItem } from '@/types/api'
import type { AreaNode, QualificationNode, QualificationOption } from '@/types/training'
import {
  buildAreaTree,
  buildQualificationTree,
  flattenQualificationOptions,
  mapAreaOptions,
} from '@/utils/training'
import {
  getAreaTreeCache,
  getProjectTypeDictCache,
  getQualificationTreeCache,
  setAreaTreeCache,
  setProjectTypeDictCache,
  setQualificationTreeCache,
} from '@/utils/session'

export async function loadAreaTree(force = false) {
  if (!force) {
    const cachedTree = getAreaTreeCache<AreaNode[]>()

    if (cachedTree) {
      return cachedTree
    }
  }

  const provinceList = await fetchAreaDetails('0')
  const jiangxi = provinceList.data.find((item) => item.id === '360000')
  const cityList = jiangxi ? await fetchAreaDetails(jiangxi.id) : { data: [] as AreaNode[] }

  const areaTree = buildAreaTree(
    cityList.data.map((item) => ({
      ...item,
      parentId: '360000',
      level: 2,
      isLeaf: true,
    })),
  )

  setAreaTreeCache(areaTree)
  return areaTree
}

export async function loadQualificationTree(force = false) {
  if (!force) {
    const cachedTree = getQualificationTreeCache<QualificationNode[]>()

    if (cachedTree) {
      return cachedTree
    }
  }

  const response = await fetchQualificationDetails()
  const qualificationTree = buildQualificationTree(response.data)

  setQualificationTreeCache(qualificationTree)
  return qualificationTree
}

function normalizeDictOptions(list: Array<Record<string, unknown>>) {
  return list
    .map((item) => ({
      label: String(item.dictLabel || item.label || item.name || ''),
      value: String(item.dictValue ?? item.value ?? item.code ?? ''),
    }))
    .filter((item) => item.label && item.value)
}

export async function loadProjectTypeOptions(force = false) {
  if (!force) {
    const cachedList = getProjectTypeDictCache<OptionItem[]>()

    if (cachedList && cachedList.length > 0) {
      return cachedList
    }
  }

  const response = await fetchDictByType('project_type')
  const projectTypeOptions = normalizeDictOptions((response.data || []) as Array<Record<string, unknown>>)

  setProjectTypeDictCache(projectTypeOptions)
  return projectTypeOptions
}

export async function loadLookupOptions(force = false) {
  const [areaTree, qualificationTree, projectTypeOptions] = await Promise.all([
    loadAreaTree(force),
    loadQualificationTree(force),
    loadProjectTypeOptions(force),
  ])

  const areaOptions = mapAreaOptions(areaTree)
  const qualificationOptions = flattenQualificationOptions(qualificationTree)

  return {
    areaTree,
    qualificationTree,
    areaOptions,
    qualificationOptions,
    projectTypeOptions,
  }
}

export function getDefaultArea(areaOptions: OptionItem[]) {
  return areaOptions.find((item) => item.label.includes('南昌'))?.value || areaOptions[0]?.value || ''
}

export function getQualificationByValue(
  qualificationOptions: QualificationOption[],
  value: string,
) {
  return qualificationOptions.find((item) => item.value === value)
}
