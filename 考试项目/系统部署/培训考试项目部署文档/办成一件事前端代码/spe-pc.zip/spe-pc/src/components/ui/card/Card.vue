<script setup lang="ts">
import { computed } from 'vue'

import { cn } from '@/lib/utils'

const props = withDefaults(
  defineProps<{
    class?: string
  }>(),
  {
    class: '',
  },
)

const className = computed(() => cn('rounded-3xl border border-border bg-card text-card-foreground shadow-soft', props.class))
</script>

<template>
  <div :class="className">
    <slot />
  </div>
</template>
