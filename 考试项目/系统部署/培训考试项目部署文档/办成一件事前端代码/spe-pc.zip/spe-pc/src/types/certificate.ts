export interface CertificateRecordRaw {
  certificateId?: string | number
  id?: string | number
  certificateTypeCode?: string | number
  certificateType?: string | number
  workType?: string | number
  certNo?: string
  name?: string
  gender?: string | number
  jobTypeCodeDictText?: string
  operItemCodeDictText?: string
  personnelType?: string
  industryType?: string
  issueDate?: string
  validStartDate?: string
  validEndDate?: string
  issuingAuthority?: string
  imgPath?: string
  qrcodePath?: string
  qrCodeUrl?: string
  codes?: string
  names?: string
  [key: string]: unknown
}

export interface CertificatePreviewData {
  certificateId: string
  certificateTypeCode: string
  certificateType: string
  workType: string
  certNo: string
  name: string
  gender: string
  jobTypeCodeDictText: string
  operItemCodeDictText: string
  personnelType: string
  industryType: string
  issueDate: string
  validStartDate: string
  validEndDate: string
  issuingAuthority: string
  imgPath: string
  qrcodePath: string
  codes: string
  names: string
  raw: Record<string, unknown>
}

export interface CertificatePreviewViewModel {
  certificateId: string
  certificateTypeCode: '1' | '2'
  certificateName: string
  certNo: string
  name: string
  genderText: string
  typeLabel: string
  typeValue: string
  wideTypeLabel: string
  wideTypeValue: string
  issueDateText: string
  validDateText: string
  issuingAuthorityText: string
  photoUrl: string
  qrCodeImageUrl: string
  accentColor: string
  backBackgroundUrl: string
  frontBackgroundUrl: string
}
