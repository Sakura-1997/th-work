export interface LoginPayload {
  idCard: string
  name: string
  phone: string
  scope?: string
}

export interface LoginResult {
  access_token: string
  refresh_token?: string
  token_type?: string
  expires_in?: number
  tenant_id?: string
  [key: string]: unknown
}

export interface PcUserProfile {
  id?: string | number
  realName?: string
  username?: string
  phone?: string
  idNumber?: string
  [key: string]: unknown
}

export interface UserProfileState {
  userId: string
  userName: string
  phone: string
  idNumber: string
  rawProfile: Record<string, unknown>
}

export interface AreaNode {
  id: string
  name: string
  parentId?: string
  level?: number
  isLeaf?: boolean
  children?: AreaNode[]
}

export interface QualificationNode {
  code: string
  parentCode?: string
  name?: string
  names?: string
  codes?: string
  level?: number
  children?: QualificationNode[]
  [key: string]: unknown
}

export interface QualificationOption {
  label: string
  value: string
  personType: string
  fullName: string
}

export interface TrainingInstitutionItem {
  id: string
  institutionName?: string
  name?: string
  phone?: string
  linkman?: string
  score?: string | number
  areaId?: string
  areaName?: string
  sealPath?: string
  qualificationNames?: string[] | string
  sitePhotoPaths?: string[] | string
  address?: string
  introduction?: string
  summary?: string
  hasRecentTrainingPlan?: boolean | string | number
  [key: string]: unknown
}

export interface InstitutionListViewModel {
  id: string
  name: string
  phone: string
  contactPerson: string
  address: string
  description: string
  score: number
  tag: string
  sitePhotoPaths: string[]
  hasRecentTrainingPlan: boolean
  recentTrainingPlanText: string
}

export interface InstitutionDetailRaw extends Record<string, unknown> {
  id: string
}

export interface InstitutionDetailViewModel {
  id: string
  name: string
  tag: string
  contactPerson: string
  phone: string
  businessPhone: string
  address: string
  description: string
  trainingItems: string[]
  sitePhotoPaths: string[]
  score: number
  evaluationSummary: string
}

export interface TrainingPlanItem {
  id: string
  institutionId?: string
  qualificationCode?: string
  qualificationCodes?: string
  qualificationName?: string
  projectType?: string
  projectTypeLabel?: string
  name?: string
  startDate?: string
  endDate?: string
  theoryStartDate?: string
  theoryEndDate?: string
  practiceStartDate?: string
  practiceEndDate?: string
  plannedTrainees?: number
  traineeCount?: number | string
  formalTraineeCount?: number | string
  theoryHours?: number | string
  practiceHours?: number | string
  signupStartDate?: string
  signupEndDate?: string
  trainingLocation?: string
  examDate?: string
  examLocation?: string
  classId?: string
  [key: string]: unknown
}

export interface TrainingPlanViewModel {
  id: string
  classId: string
  qualificationCode: string
  qualificationName: string
  projectType: string
  projectTypeLabelText: string
  personTypeLabelText: string
  workCategoryLabelText: string
  operationItemLabelText: string
  scheduleText: string
  plannedTraineesText: string
  currentTraineesText: string
  trainingCountText: string
  signupPeriodText: string
  trainingLocationText: string
  theoryHoursText: string
  practiceHoursText: string
  examDateText: string
}

export interface InstitutionEvaluationSummary extends Record<string, unknown> {}

export interface InstitutionEvaluationItem extends Record<string, unknown> {
  id?: string | number
}

export interface InstitutionEvaluationViewModel {
  id: string
  userName: string
  content: string
  createTime: string
}

export interface TrainingSignUpPayload {
  institutionId: string
  qualificationCode: string
  projectType: string
  personType?: string
  classId?: string
  source?: string
}
