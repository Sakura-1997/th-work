import request from '@/utils/request'
import type { ApiResponse } from '@/types/api'
import type { CertificateRecordRaw } from '@/types/certificate'

export function fetchMyCertificateList(data: Record<string, unknown> = {}) {
  return request<ApiResponse<CertificateRecordRaw[] | { records?: CertificateRecordRaw[]; list?: CertificateRecordRaw[] }>>({
    url: '/admin/app/certificate/queryMyCertificate',
    method: 'post',
    data,
  })
}

export function fetchCertificateDetail(certificateId: string) {
  return request<ApiResponse<CertificateRecordRaw>>({
    url: '/admin/app/certificate/detail',
    method: 'get',
    params: {
      id: certificateId,
      certificateId,
    },
  })
}

export function fetchCertificateFileBase64(filePath: string) {
  return request<unknown>({
    url: '/admin/sys-file/oss/file',
    method: 'get',
    params: {
      base64: true,
      fileName: filePath,
      path: filePath,
    },
  })
}
