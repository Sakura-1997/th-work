const svgToDataUrl = (svg: string) => `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`

const cover = (title: string, subtitle: string, palette: [string, string, string]) =>
  svgToDataUrl(`
    <svg xmlns="http://www.w3.org/2000/svg" width="1280" height="720" viewBox="0 0 1280 720">
      <defs>
        <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="${palette[0]}" />
          <stop offset="100%" stop-color="${palette[1]}" />
        </linearGradient>
      </defs>
      <rect width="1280" height="720" fill="url(#bg)" />
      <rect x="96" y="112" width="1088" height="496" rx="26" fill="rgba(255,255,255,0.18)" />
      <rect x="146" y="176" width="988" height="240" rx="18" fill="${palette[2]}" opacity="0.75" />
      <rect x="176" y="452" width="262" height="96" rx="16" fill="rgba(255,255,255,0.82)" />
      <rect x="470" y="452" width="208" height="96" rx="16" fill="rgba(255,255,255,0.56)" />
      <rect x="710" y="452" width="424" height="96" rx="16" fill="rgba(255,255,255,0.4)" />
      <text x="160" y="262" fill="#ffffff" font-size="52" font-family="Microsoft YaHei, Arial, sans-serif" font-weight="700">${title}</text>
      <text x="160" y="332" fill="rgba(255,255,255,0.88)" font-size="28" font-family="Microsoft YaHei, Arial, sans-serif">${subtitle}</text>
    </svg>
  `)

export type Institution = {
  id: string
  name: string
  shortName: string
  area: string
  trainingType: string
  trainingProject: string
  description: string
  phone: string
  businessPhone: string
  contactPerson: string
  address: string
  tag: string
  summary: string
  trainingItems: string[]
  plans: string[]
  gallery: string[]
  rating: number
}

export const institutions: Institution[] = [
  {
    id: 'jxaj',
    name: '江西安健注册安全工程师事务所有限公司',
    shortName: '江西安健注册安全工程师事务所有限公司',
    area: '南昌市',
    trainingType: '取证培训',
    trainingProject: '金属冶炼作业',
    description:
      '江西安健注册安全工程师事务所有限公司是江西省矿检安全科技有限公司全资子公司，具备职业培训资质，当前页面仅对照原型展示机构基础信息。',
    phone: '18770825666',
    businessPhone: '0791-85208323',
    contactPerson: '刘莉',
    address: '南昌市青云谱区昌南工业区帝豪实业有限公司办公楼二楼',
    tag: '认证机构',
    summary: '7 年专业培训经验，近期暂无培训计划。',
    trainingItems: ['金属冶炼（铁合金冶炼、锰冶炼、铝冶炼）', '熔化焊接与热切割作业', '低压电工作业'],
    plans: [],
    gallery: [
      cover('培训中心外景', '机构实景展示', ['#1d4ed8', '#0f172a', '#94a3b8']),
      cover('实训通道', '按原型保留环境展示区块', ['#0f766e', '#164e63', '#5eead4']),
      cover('机房设备', '设备展示占位图', ['#7c3aed', '#1e293b', '#c4b5fd']),
      cover('教室环境', '教室展示占位图', ['#b45309', '#78350f', '#fdba74']),
    ],
    rating: 0,
  },
  {
    id: 'jkzx',
    name: '江西矿安安全生产科学技术咨询中心有限公司',
    shortName: '江西矿安安全生产科学技术咨询中心有限公司',
    area: '南昌市',
    trainingType: '复审培训',
    trainingProject: '低压电工作业',
    description:
      '机构成立于 2004 年，主要提供安全生产相关培训服务。当前先按静态页面承接列表与详情展示，不引入额外业务流程。',
    phone: '0791-88130618',
    businessPhone: '0791-88130618',
    contactPerson: '徐老师',
    address: '南昌市青山湖区高新大道辅路 88 号',
    tag: '认证机构',
    summary: '支持复审培训，当前有 1 个培训方向说明。',
    trainingItems: ['低压电工作业', '高处安装、维护、拆除作业'],
    plans: ['低压电工作业复审班（待开班）'],
    gallery: [
      cover('机构入口', '列表页第二张机构图', ['#334155', '#0f172a', '#94a3b8']),
      cover('咨询前台', '咨询与报名接待区', ['#0f766e', '#155e75', '#67e8f9']),
      cover('理论教室', '理论课程教室', ['#dc2626', '#7f1d1d', '#fca5a5']),
    ],
    rating: 0,
  },
  {
    id: 'aqpx',
    name: '江西应急安全培训服务中心',
    shortName: '江西应急安全培训服务中心',
    area: '九江市',
    trainingType: '取证培训',
    trainingProject: '高处作业',
    description:
      '机构页面仅用于原型还原验证，字段范围与移动端原型保持一致，包括电话、地址、培训项目和培训计划状态。',
    phone: '0792-8631022',
    businessPhone: '0792-8631022',
    contactPerson: '张老师',
    address: '九江市濂溪区前进东路 166 号',
    tag: '认证机构',
    summary: '可开展高处作业培训，近期计划待更新。',
    trainingItems: ['高处安装、维护、拆除作业', '登高架设作业'],
    plans: ['高处作业取证班（近期开放报名）'],
    gallery: [
      cover('培训楼外立面', '详情页主图占位', ['#0f766e', '#134e4a', '#99f6e4']),
      cover('实训场地', '场地环境图', ['#1d4ed8', '#172554', '#93c5fd']),
      cover('课堂区域', '课堂环境图', ['#9333ea', '#4c1d95', '#d8b4fe']),
    ],
    rating: 0,
  },
]

export const areaOptions = ['全部地区', '南昌市', '九江市']
export const typeOptions = ['全部类型', '取证培训', '复审培训']
export const projectOptions = ['全部项目', '金属冶炼作业', '低压电工作业', '高处作业']

export const getInstitutionById = (id: string) => institutions.find((item) => item.id === id)
