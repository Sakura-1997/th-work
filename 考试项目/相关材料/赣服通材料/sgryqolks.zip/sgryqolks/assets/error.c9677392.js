const e=""+new URL("error.b6ee778d.png",import.meta.url).href;export{e as E};
