<script setup lang="ts">
defineProps<{
  title: string
  subtitle?: string
}>()
</script>

<template>
  <div class="flex items-end justify-between gap-6">
    <div class="space-y-2">
      <p class="text-sm font-medium uppercase tracking-[0.24em] text-blue-600">培训机构</p>
      <div class="space-y-1">
        <h1 class="text-3xl font-semibold text-slate-950">{{ title }}</h1>
        <p v-if="subtitle" class="text-sm text-slate-500">{{ subtitle }}</p>
      </div>
    </div>

    <slot />
  </div>
</template>
