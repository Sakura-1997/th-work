import request from '@/utils/request'
import type { ApiResponse } from '@/types/api'
import type { AreaNode, QualificationNode } from '@/types/training'

export function fetchAreaDetails(parentId: string) {
  return request<ApiResponse<AreaNode[]>>({
    url: '/admin/area/details',
    method: 'get',
    params: {
      parentId,
    },
  })
}

export function fetchQualificationDetails() {
  return request<ApiResponse<QualificationNode[]>>({
    url: '/admin/qualification/details',
    method: 'get',
  })
}
