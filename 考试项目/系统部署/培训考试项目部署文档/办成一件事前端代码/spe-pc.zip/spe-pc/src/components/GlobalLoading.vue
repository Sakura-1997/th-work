<script setup lang="ts">
import { useGlobalLoading } from '@/composables/use-global-loading'

const { visible, text } = useGlobalLoading()
</script>

<template>
  <Teleport to="body">
    <Transition name="global-loading-fade">
      <div
        v-if="visible"
        class="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-950/20 backdrop-blur-[2px]"
      >
        <div class="flex min-w-[180px] items-center gap-3 rounded-2xl bg-white/96 px-5 py-4 shadow-2xl">
          <div class="h-5 w-5 animate-spin rounded-full border-2 border-blue-200 border-t-blue-600"></div>
          <span class="text-sm font-medium text-slate-700">{{ text }}</span>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>
