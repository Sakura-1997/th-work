<script setup lang="ts">
import { CalendarDays, MapPin, Phone, Star, UserRound } from '@lucide/vue'

import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import type { InstitutionListViewModel } from '@/types/training'

const props = defineProps<{
  institution: InstitutionListViewModel
}>()

const emit = defineEmits<{
  'view-detail': [id: string]
  signup: [id: string]
}>()

const openDetail = () => emit('view-detail', props.institution.id)
const signup = () => emit('signup', props.institution.id)
</script>

<template>
  <Card
    class="cursor-pointer overflow-hidden rounded-lg transition hover:shadow-md"
    role="button"
    tabindex="0"
    @click="openDetail"
    @keyup.enter="openDetail"
    @keyup.space.prevent="openDetail"
  >
    <div class="flex flex-col">
      <div class="grid grid-cols-[420px_1fr] items-start gap-0">
        <div class="bg-slate-100 p-0">
          <div class="aspect-video w-full overflow-hidden rounded-md">
            <img
              :src="institution.sitePhotoPaths[0]"
              :alt="institution.name"
              class="h-full w-full object-cover"
            />
          </div>
        </div>

        <div class="flex min-h-[236px] flex-col p-7 pb-5">
          <div class="flex items-start justify-between gap-4">
            <div class="space-y-1">
              <div class="flex items-center gap-3">
                <h3 class="text-2xl font-semibold text-slate-900">{{ institution.name }}</h3>
                <Badge>{{ institution.tag }}</Badge>
              </div>
            </div>

            <div class="flex items-center gap-1 text-slate-300">
              <Star
                v-for="index in 5"
                :key="index"
                class="h-4 w-4"
                :class="index <= Math.round(institution.score) ? 'fill-amber-400 text-amber-400' : ''"
              />
            </div>
          </div>

          <div class="mt-6 grid gap-3 text-sm text-slate-600">
            <div class="flex items-center gap-3">
              <Phone class="h-4 w-4 text-slate-400" />
              <span class="text-base text-blue-600">{{ institution.phone }}</span>
            </div>
            <div class="flex items-center gap-3">
              <UserRound class="h-4 w-4 text-slate-400" />
              <span>{{ institution.contactPerson }}</span>
            </div>
            <div class="flex items-center gap-3">
              <MapPin class="h-4 w-4 shrink-0 text-slate-400" />
              <span class="line-clamp-2">{{ institution.address }}</span>
            </div>
            <p class="line-clamp-2 leading-6 text-slate-500">
              <span class="font-medium text-slate-600">机构简介：</span>{{ institution.description }}
            </p>
          </div>

          <div class="mt-auto flex justify-end gap-3 pt-6">
            <Button variant="outline" class="min-w-28" @click.stop="openDetail">查看详情</Button>
            <Button class="min-w-28" @click.stop="signup">我要报名取证</Button>
          </div>
        </div>
      </div>

      <div class="mt-4 px-7 pb-7">
        <div class="flex items-center gap-3 rounded-md bg-slate-50 px-4 py-3 text-sm text-slate-500">
          <CalendarDays class="h-4 w-4 shrink-0 text-slate-400" />
          <span :class="institution.hasRecentTrainingPlan ? 'text-blue-600' : 'text-slate-500'">
            {{ institution.recentTrainingPlanText }}
          </span>
        </div>
      </div>
    </div>
  </Card>
</template>
