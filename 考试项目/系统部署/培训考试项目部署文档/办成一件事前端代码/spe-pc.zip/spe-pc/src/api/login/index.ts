import qs from 'qs'

import request from '@/utils/request'
import type { LoginPayload, LoginResult } from '@/types/training'

export function loginByIdCardName(data: LoginPayload) {
  return request<LoginResult>({
    url: '/admin/oauth2/token?grant_type=gft&client_id=gft',
    method: 'post',
    data: qs.stringify({
      scope: data.scope || 'server',
      idCard: data.idCard,
      name: data.name,
      phone: data.phone,
    }),
    headers: {
      skipToken: true,
      Authorization: 'Basic Y3VzdG9tOmN1c3RvbQ==',
      'Content-Type': 'application/x-www-form-urlencoded',
      'Enc-Flag': 'false',
    },
  })
}

export function loginByJiangxiTrusted(ticket: string) {
  return request<LoginResult>({
    url: '/admin/oauth2/token?grant_type=gft&client_id=gft',
    method: 'post',
    data: qs.stringify({
      scope: 'server',
      trustedLogin: '1',
      ticket,
    }),
    headers: {
      skipToken: true,
      Authorization: 'Basic Y3VzdG9tOmN1c3RvbQ==',
      'Content-Type': 'application/x-www-form-urlencoded',
      'Enc-Flag': 'false',
    },
  })
}
