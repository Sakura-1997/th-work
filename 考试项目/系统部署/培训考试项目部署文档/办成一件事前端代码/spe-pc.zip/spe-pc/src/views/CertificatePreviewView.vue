<script setup lang="ts">
import { computed, nextTick, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

import { fetchCertificateDetail, fetchCertificateFileBase64 } from '@/api/certificate'
import CertificatePreview from '@/components/certificate/CertificatePreview.vue'
import { showGlobalLoading, hideGlobalLoading } from '@/composables/use-global-loading'
import { showGlobalMessage } from '@/composables/use-global-message'
import {
  parseCertificateRouteData,
  normalizeCertificatePreviewData,
  useCertificatePreview,
} from '@/composables/use-certificate-preview'
import { loadQualificationTree } from '@/services/app-bootstrap'
import { getQualificationTreeCache } from '@/utils/session'
import Button from '@/components/ui/button/Button.vue'
import Card from '@/components/ui/card/Card.vue'
import type { CertificatePreviewData } from '@/types/certificate'
import type { QualificationNode } from '@/types/training'

const route = useRoute()
const router = useRouter()

const qualificationTree = ref<QualificationNode[]>(getQualificationTreeCache<QualificationNode[]>() || [])
const certificateData = ref<CertificatePreviewData | null>(null)
const isInitializing = ref(false)
const isDownloading = ref(false)
const errorMessage = ref('')
const previewRef = ref<{ getPageElements: () => HTMLElement[] } | null>(null)

const { previewModel } = useCertificatePreview(certificateData, qualificationTree)

const certificateId = computed(() => {
  const routeId = Array.isArray(route.params.id) ? route.params.id[0] : route.params.id
  const queryId = Array.isArray(route.query.certificateId) ? route.query.certificateId[0] : route.query.certificateId

  return String(routeId || queryId || certificateData.value?.certificateId || '').trim()
})

async function ensureQualificationTreeLoaded() {
  if (qualificationTree.value.length > 0) {
    return
  }

  qualificationTree.value = await loadQualificationTree()
}

async function fetchLatestCertificateDetail() {
  if (!certificateId.value) {
    return
  }

  const response = await fetchCertificateDetail(certificateId.value)
  const normalizedData = normalizeCertificatePreviewData(response.data)

  if (normalizedData) {
    certificateData.value = normalizedData
  }
}

async function initializePreview() {
  isInitializing.value = true
  errorMessage.value = ''

  const parsedData = parseCertificateRouteData(route.query.data)
  certificateData.value = parsedData

  try {
    await ensureQualificationTreeLoaded()

    if (!parsedData && !certificateId.value) {
      errorMessage.value = '未获取到证书信息，请返回后重试。'
      return
    }

    if (certificateId.value) {
      showGlobalLoading('加载证书详情...')

      try {
        await fetchLatestCertificateDetail()
      } catch (error) {
        if (!certificateData.value) {
          errorMessage.value = '证书详情加载失败，请稍后重试。'
        }

        const message = error instanceof Error ? error.message : '证书详情加载失败，请稍后重试。'
        showGlobalMessage(message)
      } finally {
        hideGlobalLoading()
      }
    }
  } catch (error) {
    errorMessage.value = '证书预览初始化失败，请稍后重试。'
    const message = error instanceof Error ? error.message : '证书预览初始化失败，请稍后重试。'
    showGlobalMessage(message)
  } finally {
    isInitializing.value = false
  }
}

function buildDownloadFileName() {
  const name = previewModel.value?.name || '持证人'
  const certNo = previewModel.value?.certNo || 'certificate'
  return `${name}-${certNo}-证书预览`.replace(/[\\/:*?"<>|]/g, '-')
}

function toStringValue(value: unknown) {
  if (value === null || value === undefined) {
    return ''
  }

  return String(value).trim()
}

function isDirectPreviewUrl(value: string) {
  return /^(https?:)?\/\//i.test(value) || value.startsWith('data:') || value.startsWith('blob:')
}

function resolveApiProxyUrl(value: unknown) {
  const url = toStringValue(value)
  const apiBase = toStringValue(import.meta.env.VITE_API_URL).replace(/\/$/, '')

  if (!url) {
    return ''
  }

  if (isDirectPreviewUrl(url)) {
    return url
  }

  if (!apiBase) {
    return url
  }

  if (url.startsWith('/')) {
    return `${apiBase}${url}`
  }

  return `${apiBase}/${url}`
}

function getImageMimeType(filePath = '') {
  const normalizedPath = toStringValue(filePath).toLowerCase()

  if (normalizedPath.endsWith('.jpg') || normalizedPath.endsWith('.jpeg')) {
    return 'image/jpeg'
  }

  if (normalizedPath.endsWith('.webp')) {
    return 'image/webp'
  }

  if (normalizedPath.endsWith('.gif')) {
    return 'image/gif'
  }

  return 'image/png'
}

function normalizeBase64Image(value: unknown, filePath = '') {
  const rawValue = toStringValue(value)

  if (!rawValue) {
    return ''
  }

  if (rawValue.startsWith('data:image')) {
    return rawValue
  }

  return `data:${getImageMimeType(filePath)};base64,${rawValue}`
}

async function resolvePdfPhotoUrl() {
  const filePath = toStringValue(certificateData.value?.imgPath)

  if (!filePath) {
    return ''
  }

  if (filePath.startsWith('data:image')) {
    return filePath
  }

  try {
    const response = await fetchCertificateFileBase64(filePath)

    if (typeof response === 'string') {
      return normalizeBase64Image(response, filePath)
    }

    if (response && typeof response === 'object') {
      const payload = response as Record<string, unknown>
      const rawValue = payload.data || payload.url || payload.previewUrl
      const normalizedValue = toStringValue(rawValue)

      if (!normalizedValue) {
        return ''
      }

      return isDirectPreviewUrl(normalizedValue) ? normalizedValue : normalizeBase64Image(normalizedValue, filePath)
    }
  } catch {
    return resolveApiProxyUrl(filePath) || previewModel.value?.photoUrl || ''
  }

  return resolveApiProxyUrl(filePath) || previewModel.value?.photoUrl || ''
}

async function setPdfPhotoSource(pageElements: HTMLElement[], pdfPhotoUrl: string) {
  if (!pdfPhotoUrl) {
    return () => {}
  }

  const photoImages = pageElements
    .flatMap((element) => Array.from(element.querySelectorAll('.cert-photo-image')))
    .filter((node): node is HTMLImageElement => node instanceof HTMLImageElement)

  if (photoImages.length === 0) {
    return () => {}
  }

  const restoreList = photoImages.map((imageElement) => ({
    imageElement,
    src: imageElement.src,
  }))

  await Promise.all(
    photoImages.map(
      (imageElement) =>
        new Promise<void>((resolve) => {
          const finalize = () => {
            imageElement.removeEventListener('load', finalize)
            imageElement.removeEventListener('error', finalize)
            resolve()
          }

          imageElement.addEventListener('load', finalize, { once: true })
          imageElement.addEventListener('error', finalize, { once: true })
          imageElement.src = pdfPhotoUrl

          if (imageElement.complete) {
            finalize()
          }
        }),
    ),
  )

  return () => {
    restoreList.forEach(({ imageElement, src }) => {
      imageElement.src = src
    })
  }
}

async function waitForPreviewImages(pageElements: HTMLElement[]) {
  await nextTick()

  const imageElements = pageElements.flatMap((element) => Array.from(element.querySelectorAll('img')))

  await Promise.all(
    imageElements.map(
      (imageElement) =>
        new Promise<void>((resolve) => {
          if (imageElement.complete && imageElement.naturalWidth > 0) {
            resolve()
            return
          }

          const finalize = () => {
            imageElement.removeEventListener('load', finalize)
            imageElement.removeEventListener('error', finalize)
            resolve()
          }

          imageElement.addEventListener('load', finalize, { once: true })
          imageElement.addEventListener('error', finalize, { once: true })
        }),
    ),
  )
}

async function downloadPreviewPdf() {
  const pageElements = previewRef.value?.getPageElements() || []

  if (!previewModel.value || pageElements.length === 0) {
    showGlobalMessage('暂无可下载的证书预览内容')
    return
  }

  isDownloading.value = true
  showGlobalLoading('正在生成 PDF...')
  let restorePhotoSource = () => {}

  try {
    await waitForPreviewImages(pageElements)

    const pdfPhotoUrl = await resolvePdfPhotoUrl()
    restorePhotoSource = await setPdfPhotoSource(pageElements, pdfPhotoUrl)
    const [{ default: html2canvas }, { jsPDF }] = await Promise.all([import('html2canvas'), import('jspdf')])
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'pt',
      format: 'a4',
      compress: true,
    })
    const pageWidth = pdf.internal.pageSize.getWidth()
    const pageHeight = pdf.internal.pageSize.getHeight()
    const maxWidth = pageWidth - 48
    const maxHeight = pageHeight - 48

    for (const [index, element] of pageElements.entries()) {
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
      })
      const imageData = canvas.toDataURL('image/png')
      const scale = Math.min(maxWidth / canvas.width, maxHeight / canvas.height)
      const renderWidth = canvas.width * scale
      const renderHeight = canvas.height * scale
      const offsetX = (pageWidth - renderWidth) / 2
      const offsetY = (pageHeight - renderHeight) / 2

      if (index > 0) {
        pdf.addPage()
      }

      pdf.addImage(imageData, 'PNG', offsetX, offsetY, renderWidth, renderHeight, undefined, 'FAST')
    }

    pdf.save(`${buildDownloadFileName()}.pdf`)
    showGlobalMessage('PDF 已开始下载', 'success')
  } catch (error) {
    const message = error instanceof Error ? error.message : 'PDF 生成失败，请稍后重试。'
    showGlobalMessage(message)
  } finally {
    restorePhotoSource()
    hideGlobalLoading()
    isDownloading.value = false
  }
}

watch(
  () => route.fullPath,
  () => {
    initializePreview()
  },
  {
    immediate: true,
  },
)
</script>

<template>
  <div class="min-h-screen bg-slate-50 px-6 py-8">
    <div class="mx-auto max-w-[1160px] space-y-6">
      <div class="flex flex-wrap items-start justify-between gap-4">
        <div class="space-y-2">
          <p class="text-sm font-medium tracking-[0.18em] text-blue-600">证书中心</p>
          <div class="space-y-1">
            <h1 class="text-3xl font-semibold text-slate-950">证书预览</h1>
            <p class="text-sm text-slate-500">支持直接预览证书正反面，并由前端生成 PDF 自动下载。</p>
          </div>
        </div>

        <div class="flex flex-wrap gap-3">
          <Button variant="outline" @click="router.back()">返回上页</Button>
          <Button :disabled="!previewModel || isDownloading" @click="downloadPreviewPdf">
            {{ isDownloading ? '生成中...' : '下载 PDF' }}
          </Button>
        </div>
      </div>

      <Card v-if="previewModel" class="rounded-lg p-5">
        <div class="grid gap-4 text-sm text-slate-600 md:grid-cols-4">
          <div>
            <div class="mb-1 text-xs text-slate-400">证书类型</div>
            <div class="font-medium text-slate-900">{{ previewModel.certificateName }}</div>
          </div>
          <div>
            <div class="mb-1 text-xs text-slate-400">证书编号</div>
            <div class="font-medium text-slate-900">{{ previewModel.certNo }}</div>
          </div>
          <div>
            <div class="mb-1 text-xs text-slate-400">持证人</div>
            <div class="font-medium text-slate-900">{{ previewModel.name }}</div>
          </div>
          <div>
            <div class="mb-1 text-xs text-slate-400">证书 ID</div>
            <div class="font-medium text-slate-900">{{ previewModel.certificateId || '-' }}</div>
          </div>
        </div>
      </Card>

      <Card v-if="errorMessage" class="rounded-lg p-10 text-center">
        <div class="space-y-3">
          <p class="text-lg font-medium text-slate-900">{{ errorMessage }}</p>
          <p class="text-sm text-slate-500">可通过 `/certificates/:id` 或从“我的证书”列表进入当前预览页。</p>
          <div class="flex justify-center">
            <Button variant="outline" @click="router.push('/')">返回首页</Button>
          </div>
        </div>
      </Card>

      <div v-else-if="previewModel">
        <CertificatePreview ref="previewRef" :model="previewModel" />
      </div>

      <Card v-else class="rounded-lg p-10 text-center text-slate-500">
        {{ isInitializing ? '证书预览加载中...' : '暂无证书预览数据' }}
      </Card>
    </div>
  </div>
</template>
