<script setup lang="ts">
import { ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

import { loginByIdCardName } from '@/api/login'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { hideGlobalLoading, showGlobalLoading } from '@/composables/use-global-loading'
import { showGlobalMessage } from '@/composables/use-global-message'
import { getQueryValue, useTrustedLogin } from '@/composables/use-trusted-login'
import { initializeLoginSession } from '@/services/auth'
import { getErrorMessage } from '@/utils/training'

const route = useRoute()
const router = useRouter()

const isDev = import.meta.env.DEV
const loading = ref(false)
const idCard = ref('')
const devName = ref('')
const phone = ref('')
const {
  trustedLoginLoading,
  getTrustedTicket,
  handleTrustedLogin: handleTrustedTicketLogin,
} = useTrustedLogin(route, router)

const getRedirectPath = () => getQueryValue(route.query.redirect) || '/'
const backToHome = () => {
  const redirectPath = getRedirectPath()

  router.replace(
    redirectPath === '/'
      ? '/'
      : {
          path: '/',
          query: {
            redirect: redirectPath,
          },
        },
  )
}

const handleDevLogin = async () => {
  if (!idCard.value || !devName.value || !phone.value) {
    showGlobalMessage('请填写完整的登录信息')
    return
  }

  loading.value = true
  showGlobalLoading('正在登录...')

  try {
    const loginResult = await loginByIdCardName({
      idCard: idCard.value,
      name: devName.value,
      phone: phone.value,
    })

    await initializeLoginSession(loginResult)
    await router.replace(getRedirectPath())
  } catch (error) {
    showGlobalMessage(getErrorMessage(error))
  } finally {
    hideGlobalLoading()
    loading.value = false
  }
}

watch(
  () => route.query.ticket,
  (ticket) => {
    if (ticket) {
      handleTrustedTicketLogin()
      return
    }

    if (!isDev) {
      backToHome()
    }
  },
  {
    immediate: true,
  },
)
</script>

<template>
  <main class="min-h-screen bg-white">
    <template v-if="isDev && !getTrustedTicket()">
      <div class="flex min-h-screen items-center justify-center px-4">
        <Card class="w-full max-w-md p-8">
          <h1 class="mb-8 text-center text-2xl font-bold">登录</h1>
          <form class="space-y-5" @submit.prevent="handleDevLogin">
            <div class="space-y-1.5">
              <label class="text-sm font-medium">身份证号</label>
              <Input v-model="idCard" placeholder="请输入身份证号" />
            </div>
            <div class="space-y-1.5">
              <label class="text-sm font-medium">姓名</label>
              <Input v-model="devName" placeholder="请输入姓名" />
            </div>
            <div class="space-y-1.5">
              <label class="text-sm font-medium">手机号</label>
              <Input v-model="phone" placeholder="请输入手机号" />
            </div>
            <Button type="submit" class="w-full" :disabled="loading || trustedLoginLoading">登录</Button>
          </form>
        </Card>
      </div>
    </template>

    <template v-else></template>
  </main>
</template>
