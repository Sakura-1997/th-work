export interface ApiResponse<T = unknown> {
  code: number
  msg?: string
  data: T
  [key: string]: unknown
}

export interface PageData<T> {
  records: T[]
  total: number
}

export interface PageQuery {
  current: number
  size: number
}

export interface OptionItem {
  label: string
  value: string
}
