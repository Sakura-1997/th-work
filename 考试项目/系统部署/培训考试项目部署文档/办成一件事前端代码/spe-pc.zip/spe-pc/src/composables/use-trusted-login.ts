import { ref } from 'vue'
import type { RouteLocationNormalizedLoaded, Router } from 'vue-router'

import { loginByJiangxiTrusted } from '@/api/login'
import { hideGlobalLoading, showGlobalLoading } from '@/composables/use-global-loading'
import { showGlobalMessage } from '@/composables/use-global-message'
import { getTrustedLoginErrorMessage, initializeLoginSession } from '@/services/auth'

export const getQueryValue = (value: unknown) => {
  if (typeof value === 'string') {
    return value.trim()
  }

  if (Array.isArray(value)) {
    return String(value[0] || '').trim()
  }

  return ''
}

const clearTrustedLoginQuery = () => {
  const currentUrl = new URL(window.location.href)

  currentUrl.searchParams.delete('ticket')
  currentUrl.searchParams.delete('gotourl')

  window.history.replaceState(null, '', `${currentUrl.pathname}${currentUrl.search}`)
}

export function useTrustedLogin(route: RouteLocationNormalizedLoaded, router: Router) {
  const trustedLoginLoading = ref(false)
  const getTrustedTicket = () => getQueryValue(route.query.ticket)
  const getRedirectPath = () => getQueryValue(route.query.redirect)
  const getCurrentPathWithoutTrustedQuery = () => {
    const sanitizedQuery = { ...route.query }

    delete sanitizedQuery.ticket
    delete sanitizedQuery.gotourl
    delete sanitizedQuery.redirect

    return {
      path: route.path,
      query: sanitizedQuery,
      hash: route.hash,
    }
  }

  const handleTrustedLogin = async () => {
    const ticket = getTrustedTicket()

    if (!ticket || trustedLoginLoading.value) {
      return false
    }

    trustedLoginLoading.value = true
    clearTrustedLoginQuery()
    showGlobalLoading('正在处理江西可信登录...')

    try {
      const loginResult = await loginByJiangxiTrusted(ticket)
      const redirectPath = getRedirectPath()

      await initializeLoginSession(loginResult)
      await router.replace(redirectPath || getCurrentPathWithoutTrustedQuery())
      return true
    } catch (error) {
      showGlobalMessage(getTrustedLoginErrorMessage(error))
      return false
    } finally {
      hideGlobalLoading()
      trustedLoginLoading.value = false
    }
  }

  return {
    trustedLoginLoading,
    getTrustedTicket,
    handleTrustedLogin,
  }
}
