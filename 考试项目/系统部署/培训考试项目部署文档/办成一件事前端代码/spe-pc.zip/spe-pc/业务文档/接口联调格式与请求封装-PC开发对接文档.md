# 接口联调格式与请求封装 - PC 开发对接文档

## 文档目的
- 本文基于当前移动端项目的真实实现整理，供 PC 项目在 `run dev` 模式下联调接口时参考。
- 重点覆盖：
- 本地开发联调方式
- axios 封装方式
- API 模块编写规范
- token 注入规则
- 请求/响应拦截规则
- API 请求错误处理方式
- 本文明确 **不包含赣服通 GFT 网关接入设计**，仅说明普通开发模式下的联调方式。

## 1. 当前开发模式联调方式

### 1.1 核心结论
- 当前项目在 `run dev` 模式下，前端请求并不是直接打到后端域名。
- 实际链路如下：

```text
src/api/** -> src/utils/request.ts -> baseURL=/api -> Vite devServer proxy -> 后端联调地址
```

### 1.2 当前开发环境关键配置
- `VITE_API_URL = /api`
- `VITE_ADMIN_PROXY_PATH = http://172.16.157.70:27998`
- `VITE_USE_GANFUTONG = false`

### 1.3 Vite 代理规则
- 当前 `vite.config.ts` 中本地开发代理配置如下：

```ts
proxy: {
  '/api': {
    target: env.VITE_ADMIN_PROXY_PATH,
    ws: true,
    changeOrigin: true,
    rewrite: (path) => path.replace(/^\/api/, ''),
  }
}
```

### 1.4 这意味着什么
- 前端代码里统一请求 `/api/...`
- 本地开发服务器会把 `/api` 前缀去掉，再转发到真实后端
- 例如：

```text
前端写：/api/app/exam/outProvinceApply/page
代理后：http://172.16.157.70:27998/app/exam/outProvinceApply/page
```

### 1.5 对 PC 的建议
- PC 项目开发环境建议保持同样模式：
- `baseURL` 固定为 `/api`
- 由本地 devServer 或前端代理统一转发到后端地址
- 不建议在业务代码中直接写死后端 IP

---

## 2. axios 总封装说明

### 2.1 axios 实例创建方式
- 项目统一只使用一个 axios 实例，定义在 `src/utils/request.ts`
- 核心配置如下：

```ts
const service = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  timeout: 50000,
  paramsSerializer: {
    serialize: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
  },
})
```

### 2.2 当前默认规则
- `baseURL`：取环境变量 `VITE_API_URL`
- `timeout`：50 秒
- GET 参数序列化规则：数组参数按 `repeat` 模式展开

### 2.3 数组参数示例
- 若前端传：

```ts
params: {
  ids: [1, 2, 3]
}
```

- 最终序列化结果为：

```text
ids=1&ids=2&ids=3
```

### 2.4 对 PC 的建议
- PC 项目建议也统一封装一个 `request.ts`
- 所有 API 模块只依赖这个 `request`
- 不要在每个页面里直接使用原始 axios

---

## 3. API 模块编写规范

### 3.1 当前项目的目录组织方式
- 所有 API 都按业务域拆分在 `src/api/<domain>/`
- 示例：
- `src/api/login/index.ts`
- `src/api/institution/index.ts`
- `src/api/exam/index.ts`
- `src/api/evaluation/index.ts`

### 3.2 API 函数编写风格
- 每个函数只做一件事：描述一个接口
- API 层只保留：
- `url`
- `method`
- `params`
- `data`
- 少量特殊 `headers`
- 不在 API 层写页面逻辑、状态处理、弹窗逻辑

### 3.3 GET 接口示例

```ts
export function fetchInstitutionList(query: any) {
  return request({
    url: '/admin/app/institution/page',
    method: 'get',
    params: query,
  })
}
```

### 3.4 POST JSON 接口示例

```ts
export function fetchPostTraineeSignUp(data: any) {
  return request({
    url: '/admin/app/trainee/signup',
    method: 'post',
    data,
  })
}
```

### 3.5 文件上传接口示例

```ts
export function uploadOutProvincePhoto(file: File) {
  const formData = new FormData()
  formData.append('file', file)
  return request({
    url: '/api/app/exam/outProvinceApply/photo/upload',
    method: 'post',
    data: formData,
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  })
}
```

### 3.6 OAuth/表单接口示例

```ts
export const loginByIdCardName = (data) => {
  return request({
    url: '/auth/oauth2/token?grant_type=gft&client_id=gft',
    method: 'post',
    data: qs.stringify({
      scope: data.scope || 'server',
      idCard: data.idCard,
      name: data.name,
      phone: data.phone,
    }),
    headers: {
      skipToken: true,
      Authorization: 'Basic Y3VzdG9tOmN1c3RvbQ==',
      'Content-Type': 'application/x-www-form-urlencoded',
      'Enc-Flag': 'false',
    },
  })
}
```

### 3.7 对 PC 的建议
- 查询类接口统一用 `params`
- 新增/编辑/提交类接口统一用 `data`
- 上传统一用 `FormData`
- 登录/OAuth 接口单独处理 `headers`

---

## 4. URL 适配规则

### 4.1 当前项目存在 URL 自动适配
- 请求发送前会执行 `other.adaptationUrl(config.url)`
- 规则是：
- 如果 `VITE_IS_MICRO` 为空或为 `true`，URL 保持不变
- 否则把路径转成 `/admin/...`

### 4.2 适配逻辑

```ts
const adaptationUrl = (originUrl?: string) => {
  const isMicro = import.meta.env.VITE_IS_MICRO
  if (validateNull(isMicro) || isMicro === 'true') {
    return originUrl
  }
  return `/admin/${originUrl?.split('/').splice(2).join('/')}`
}
```

### 4.3 对 PC 的建议
- 如果 PC 项目后端路径体系固定，不一定要照搬这套 URL 适配逻辑
- 但如果 PC 和移动端共用一套后端、且也有单体/微服务切换需求，可以保留这层适配

---

## 5. 请求拦截器规则

### 5.1 当前请求拦截器主要做的事
- 增加统一请求头 `VERSION`
- 自动注入 `Authorization: Bearer token`
- 请求参数加密
- GET 参数加密
- 自动 URL 适配

### 5.2 VERSION 请求头
- 默认会写入：

```ts
config.headers['VERSION'] = 'A'
```

- 如果环境变量中存在 `VITE_GRAY_VERSION`，则覆盖为灰度版本值

### 5.3 token 自动注入
- token 取值来源：`Session.getToken()`
- 注入规则：

```ts
if (token && !config.headers?.skipToken) {
  config.headers.Authorization = `Bearer ${token}`
}
```

### 5.4 skipToken 规则
- 登录、刷新 token、验证码发送等不需要 Bearer token 的接口，统一在请求头加：

```ts
headers: {
  skipToken: true
}
```

### 5.5 请求加密规则
- 在普通开发模式下，如果满足以下条件，会自动加密：
- `config.data` 存在
- 请求头里没有显式设置 `Enc-Flag: false`
- `VITE_USE_GANFUTONG !== 'true'`

### 5.6 POST 请求体加密规则

```ts
if (config.data && !config.headers['Enc-Flag'] && import.meta.env.VITE_USE_GANFUTONG !== 'true') {
  config.data = wrapEncryption(config.data)
}
```

### 5.7 GET 参数加密规则

```ts
if (config.method === 'get' && config.params && import.meta.env.VITE_USE_GANFUTONG !== 'true') {
  config.params = encryptRequestParams(config.params)
}
```

### 5.8 对 PC 的建议
- 如果 PC 项目后端也要求同样的参数加密，就直接复用这套逻辑
- 如果 PC 项目不需要加密，可删除：
- `wrapEncryption`
- `encryptRequestParams`
- `decrypt`
- 以及与 `Enc-Flag` 相关的逻辑

---

## 6. token 存储规则

### 6.1 当前 token 存储位置
- `token`
- `refresh_token`
- `tenantId`

### 6.2 存储策略
- 这三个值会同时写入：
- `Cookies`
- `sessionStorage`

### 6.3 存储实现

```ts
if (key === 'token' || key === 'refresh_token' || key === 'tenantId') {
  Cookies.set(key, val)
}
window.sessionStorage.setItem(key, JSON.stringify(val))
```

### 6.4 读取策略
- `token`、`refresh_token`、`tenantId` 优先从 `Cookies` 取
- 其他值从 `sessionStorage` 取

### 6.5 对 PC 的建议
- PC 项目如果要保持和移动端一致，可以继续采用：
- token 放 `Cookies`
- 业务状态放 `sessionStorage`
- 如果 PC 项目更偏后台管理系统，也可以简化成只放 `localStorage/sessionStorage`

---

## 7. 响应拦截器与统一错误处理

### 7.1 成功返回的统一处理
- 响应拦截器默认返回 `response.data`
- 即业务层拿到的一般不是完整 axios response，而是后端业务返回体

### 7.2 业务码 `code = 1`
- 当前项目约定：
- `code === 0`：成功
- `code === 1`：业务失败，直接抛错

```ts
if (response.data.code === 1) {
  throw response.data
}
```

### 7.3 密文响应自动解密
- 如果响应体包含 `encryption` 字段，会自动解密后再返回

```ts
if (response.data.encryption) {
  response.data = decrypt(response.data.encryption)
  return response.data
}
```

### 7.4 HTTP 异常统一提示
- HTTP 状态码不是 `200` 且不是 `424` 时，会统一弹错误框：

```ts
useMessageBox().error(error.response?.data?.msg || `请求失败（状态码：${status}）`)
```

### 7.5 特殊状态码处理

#### 423
- 直接返回固定错误：

```ts
{ msg: '"演示环境，仅供预览"' }
```

#### 424
- 视为登录态过期
- 普通模式下：
- 清理会话
- 倒计时后跳到 `/login`

#### 426
- 提示“租户状态已过期，请联系管理员”
- 然后清理会话

### 7.6 普通模式下 token 过期恢复
- 当前实现会：
1. 弹出倒计时消息
2. 清除 `Session`
3. 3 秒后跳转登录页

### 7.7 对 PC 的建议
- PC 项目可以保留统一错误处理入口
- 但建议把 `ElMessage` / `MessageBox` 替换成 PC 项目自己的 UI 封装
- 建议保留以下约定：
- `code === 0` 视为成功
- `code !== 0` 统一在响应层判断
- `401/424` 统一做登录态恢复

---

## 8. 登录类接口的特殊处理

### 8.1 为什么登录接口不能走默认 token 逻辑
- 登录接口调用时还没有 token
- 同时它需要走 `Basic Authorization`
- 而不是 `Bearer token`

### 8.2 当前项目登录类接口共同特点
- `headers.skipToken = true`
- 显式设置 `Authorization: Basic ...`
- `Content-Type = application/x-www-form-urlencoded`
- 某些接口显式设置 `Enc-Flag: false`

### 8.3 当前已使用这种模式的接口
- 用户名密码登录
- 手机验证码登录
- 身份证 + 姓名 + 手机号登录
- 刷新 token
- 校验 token

### 8.4 对 PC 的建议
- 登录、刷新 token、短信验证码等认证接口建议单独封装在 `src/api/login/`
- 并统一在 API 层处理特殊 headers，不要放到页面里写

---

## 9. 分页接口联调格式

### 9.1 当前项目统一分页入参
- `current`
- `size`

### 9.2 当前项目统一分页返回

```json
{
  "code": 0,
  "data": {
    "records": [],
    "total": 0
  }
}
```

### 9.3 前端分页解析约定
- 优先读取：
- `data.records`
- `data.total`

### 9.4 对 PC 的建议
- 如果 PC 和移动端共用后端，建议统一保持：
- 分页入参：`current`、`size`
- 分页出参：`records`、`total`

---

## 10. 下载与上传接口联调格式

### 10.1 上传接口
- 统一使用 `FormData`
- 请求头写：

```ts
headers: {
  'Content-Type': 'multipart/form-data'
}
```

### 10.2 下载接口
- 需要显式加：

```ts
responseType: 'blob'
```

### 10.3 对 PC 的建议
- 上传、下载都建议作为 API 层中的特殊函数，不要混在普通 JSON 请求里
- 下载完成后由页面层决定是预览还是触发浏览器下载

---

## 11. 推荐给 PC 的 request 封装模板

```ts
import axios from 'axios'
import qs from 'qs'

const request = axios.create({
  baseURL: '/api',
  timeout: 50000,
  paramsSerializer: {
    serialize: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
  },
})

request.interceptors.request.use((config) => {
  const token = sessionStorage.getItem('token')

  config.headers = config.headers || {}
  config.headers.VERSION = 'A'

  if (token && !config.headers.skipToken) {
    config.headers.Authorization = `Bearer ${token}`
  }

  return config
})

request.interceptors.response.use(
  (response) => {
    const data = response.data

    if (data?.code === 1) {
      return Promise.reject(data)
    }

    return data
  },
  (error) => {
    const status = Number(error.response?.status)

    if (status === 424 || status === 401) {
      sessionStorage.clear()
      window.location.href = '/login'
      return Promise.reject({ msg: '登录态已失效，请重新登录' })
    }

    return Promise.reject(error.response?.data || error)
  }
)

export default request
```

---

## 12. 推荐给 PC 的 API 编写模板

### 12.1 普通 GET

```ts
import request from '@/utils/request'

export function fetchUserList(params: any) {
  return request({
    url: '/admin/user/page',
    method: 'get',
    params,
  })
}
```

### 12.2 普通 POST

```ts
import request from '@/utils/request'

export function saveUser(data: any) {
  return request({
    url: '/admin/user/save',
    method: 'post',
    data,
  })
}
```

### 12.3 登录 POST

```ts
import request from '@/utils/request'
import qs from 'qs'

export function loginByIdCardName(data: any) {
  return request({
    url: '/auth/oauth2/token?grant_type=gft&client_id=gft',
    method: 'post',
    data: qs.stringify(data),
    headers: {
      skipToken: true,
      Authorization: 'Basic xxxxx',
      'Content-Type': 'application/x-www-form-urlencoded',
      'Enc-Flag': 'false',
    },
  })
}
```

---

## 13. PC 联调检查清单

### 13.1 环境配置
- 是否配置了 `VITE_API_URL=/api`
- 是否配置了开发代理 `proxy['/api']`
- 是否确认了真实后端联调地址

### 13.2 request 封装
- 是否统一通过 `request.ts` 发请求
- 是否统一注入 Bearer token
- 是否为登录接口设置了 `skipToken`
- 是否处理了超时和统一错误提示

### 13.3 分页接口
- 是否统一使用 `current`、`size`
- 是否统一读取 `records`、`total`

### 13.4 上传下载
- 上传是否使用 `FormData`
- 下载是否设置 `responseType: 'blob'`

### 13.5 错误处理
- 是否处理 `code === 1`
- 是否处理 `424/401` 登录态失效
- 是否处理普通 HTTP 错误提示

---

## 14. 仍需按 PC 项目实际情况确认的点
- PC 项目是否也需要保留参数加密/解密逻辑
- PC 项目是否沿用 `Cookies + sessionStorage` 双写 token
- PC 项目是否继续使用 `VERSION=A` 请求头
- PC 项目 UI 层统一错误提示组件使用什么方案
- 后端是否完全沿用移动端当前的 `code=0 成功 / code=1 失败` 约定

## 15. 总结
- 当前项目在 `run dev` 模式下的核心联调方式很清晰：**`/api` 前缀 + Vite 代理 + 统一 request 封装**。
- 适合 PC 项目直接复用的部分主要有：
- axios 实例初始化
- 请求/响应拦截器
- token 注入
- 登录接口特殊头处理
- 分页接口格式
- 上传下载接口写法
- 不建议 PC 复用的部分是 **GFT 网关 adapter 接管逻辑**，因为你当前已经明确不需要设计这一块。
