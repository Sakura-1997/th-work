<script setup lang="ts">
import { ChevronLeft, MapPin, Phone, Star } from '@lucide/vue'
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'

import {
  fetchInstitutionDetail,
  fetchInstitutionEvaluationPage,
  fetchInstitutionTrainingPlans,
} from '@/api/institution'
import { submitTrainingSignup } from '@/api/signup'
import ActionDialog from '@/components/ActionDialog.vue'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import InstitutionSignupDialog from '@/components/InstitutionSignupDialog.vue'
import { hideGlobalLoading, showGlobalLoading } from '@/composables/use-global-loading'
import { showGlobalMessage } from '@/composables/use-global-message'
import { loadLookupOptions } from '@/services/app-bootstrap'
import type { OptionItem } from '@/types/api'
import type {
  InstitutionDetailViewModel,
  InstitutionEvaluationViewModel,
  QualificationNode,
  TrainingPlanViewModel,
} from '@/types/training'
import { clearAuthSession, getUserProfile } from '@/utils/session'
import {
  getErrorMessage,
  normalizeEvaluationItem,
  normalizeInstitutionDetail,
  normalizeTrainingPlanItem,
} from '@/utils/training'

const route = useRoute()
const router = useRouter()
const userProfile = getUserProfile()

const activeTab = ref<'info' | 'plans' | 'reviews'>('info')
const activeImageIndex = ref(0)
const institution = ref<InstitutionDetailViewModel | null>(null)
const plans = ref<TrainingPlanViewModel[]>([])
const reviews = ref<InstitutionEvaluationViewModel[]>([])
const qualificationTree = ref<QualificationNode[]>([])
const projectTypeOptions = ref<OptionItem[]>([])
const loading = ref(false)
const tabLoading = ref(false)
const signupLoadingId = ref('')
const reviewTotal = ref(0)
const planTotal = ref(0)
const planPage = ref(1)
const reviewPage = ref(1)
const planPageSize = 10
const reviewPageSize = 10
const planPageJump = ref('1')
const reviewPageJump = ref('1')
const plansLoaded = ref(false)
const reviewsLoaded = ref(false)
const signupDialogVisible = ref(false)
const pendingPlan = ref<TrainingPlanViewModel | null>(null)
const actionDialogVisible = ref(false)
const actionDialogTitle = ref('')
const actionDialogDescription = ref('')
const actionDialogConfirmText = ref('确定')
const actionDialogShowCancel = ref(true)
const actionDialogMode = ref<'plan-confirm' | 'message'>('plan-confirm')
let imageCarouselTimer: number | null = null

const institutionId = computed(() => String(route.params.id || ''))

const activeImage = computed(() => institution.value?.sitePhotoPaths[activeImageIndex.value] ?? '')
const imageList = computed(() => institution.value?.sitePhotoPaths || [])
const currentReviewTitle = computed(() => `学员评价（${reviewTotal.value}条）`)
const planTotalPages = computed(() => Math.max(1, Math.ceil(planTotal.value / planPageSize)))
const reviewTotalPages = computed(() => Math.max(1, Math.ceil(reviewTotal.value / reviewPageSize)))
const planVisiblePages = computed(() => createVisiblePages(planPage.value, planTotalPages.value))
const reviewVisiblePages = computed(() => createVisiblePages(reviewPage.value, reviewTotalPages.value))

const tabList = computed(
  () =>
    [
      { label: '机构信息', value: 'info' as const },
      { label: '培训班级', value: 'plans' as const },
      { label: currentReviewTitle.value, value: 'reviews' as const },
    ] as const,
)

const fetchInstitutionBase = async (withMask = true) => {
  loading.value = true

  if (withMask) {
    showGlobalLoading('正在加载机构详情...')
  }

  try {
    const detailResponse = await fetchInstitutionDetail(institutionId.value)

    institution.value = normalizeInstitutionDetail(detailResponse.data)
    activeImageIndex.value = 0
  } catch (error) {
    institution.value = null
    showGlobalMessage(getErrorMessage(error))
  } finally {
    if (withMask) {
      hideGlobalLoading()
    }

    loading.value = false
  }
}

const stopImageCarousel = () => {
  if (imageCarouselTimer) {
    window.clearInterval(imageCarouselTimer)
    imageCarouselTimer = null
  }
}

const startImageCarousel = () => {
  stopImageCarousel()

  if (imageList.value.length <= 1) {
    return
  }

  imageCarouselTimer = window.setInterval(() => {
    if (imageList.value.length <= 1) {
      return
    }

    activeImageIndex.value = (activeImageIndex.value + 1) % imageList.value.length
  }, 3500)
}

const fetchPlans = async (withMask = true) => {
  if (!institutionId.value) {
    return
  }

  tabLoading.value = true

  if (withMask) {
    showGlobalLoading('正在加载培训班级...')
  }

  try {
    const response = await fetchInstitutionTrainingPlans({
      institutionId: institutionId.value,
      status: '0',
      current: planPage.value,
      size: planPageSize,
    })

    plans.value = (response.data.records || []).map((item) =>
      normalizeTrainingPlanItem(item, {
        qualificationTree: qualificationTree.value,
        projectTypeOptions: projectTypeOptions.value,
      }),
    )
    planTotal.value = Number(response.data.total || 0)
  } catch (error) {
    plans.value = []
    planTotal.value = 0
    showGlobalMessage(getErrorMessage(error))
  } finally {
    plansLoaded.value = true

    if (withMask) {
      hideGlobalLoading()
    }

    tabLoading.value = false
  }
}

const fetchReviews = async (withMask = true) => {
  if (!institutionId.value) {
    return
  }

  tabLoading.value = true

  if (withMask) {
    showGlobalLoading('正在加载学员评价...')
  }

  try {
    const response = await fetchInstitutionEvaluationPage({
      evaluationObjectId: institutionId.value,
      current: reviewPage.value,
      size: reviewPageSize,
    })

    reviews.value = (response.data.records || []).map((item, index) => normalizeEvaluationItem(item, index))
    reviewTotal.value = Number(response.data.total || 0)
  } catch (error) {
    reviews.value = []
    reviewTotal.value = 0
    showGlobalMessage(getErrorMessage(error))
  } finally {
    reviewsLoaded.value = true

    if (withMask) {
      hideGlobalLoading()
    }

    tabLoading.value = false
  }
}

const loadCurrentTab = async () => {
  if (activeTab.value === 'plans') {
    await fetchPlans()
    return
  }

  if (activeTab.value === 'reviews') {
    await fetchReviews()
  }
}

function createVisiblePages(currentPage: number, totalPages: number) {
  const pages: number[] = []
  const maxVisible = 5
  const start = Math.max(1, currentPage - 2)
  const end = Math.min(totalPages, start + maxVisible - 1)
  const normalizedStart = Math.max(1, end - maxVisible + 1)

  for (let page = normalizedStart; page <= end; page += 1) {
    pages.push(page)
  }

  return pages
}

watch(
  institutionId,
  (value) => {
    if (!value) {
      router.replace('/institutions')
    }
  },
)

watch(activeTab, async () => {
  await loadCurrentTab()
})

watch(
  imageList,
  (list) => {
    if (activeImageIndex.value >= list.length) {
      activeImageIndex.value = 0
    }

    startImageCarousel()
  },
  { deep: true },
)

watch(planTotalPages, (value) => {
  if (planPage.value > value) {
    planPage.value = value
  }
  planPageJump.value = String(planPage.value)
})

watch(reviewTotalPages, (value) => {
  if (reviewPage.value > value) {
    reviewPage.value = value
  }
  reviewPageJump.value = String(reviewPage.value)
})

watch(planPage, (value) => {
  planPageJump.value = String(value)
})

watch(reviewPage, (value) => {
  reviewPageJump.value = String(value)
})

const backToList = () => {
  router.push('/institutions')
}

const logout = () => {
  clearAuthSession()
  router.push('/login')
}

const handleDirectSignup = () => {
  signupDialogVisible.value = true
}

const openActionDialog = (options: {
  title: string
  description: string
  confirmText?: string
  showCancel?: boolean
  mode: 'plan-confirm' | 'message'
}) => {
  actionDialogTitle.value = options.title
  actionDialogDescription.value = options.description
  actionDialogConfirmText.value = options.confirmText || '确定'
  actionDialogShowCancel.value = options.showCancel ?? true
  actionDialogMode.value = options.mode
  actionDialogVisible.value = true
}

const closeActionDialog = () => {
  actionDialogVisible.value = false

  if (actionDialogMode.value === 'plan-confirm') {
    pendingPlan.value = null
  }

  if (actionDialogMode.value === 'message') {
    actionDialogTitle.value = ''
    actionDialogDescription.value = ''
    actionDialogConfirmText.value = '确定'
    actionDialogShowCancel.value = true
  }
}

const handlePlanSignup = (plan: TrainingPlanViewModel) => {
  pendingPlan.value = plan
  openActionDialog({
    title: '确认预约培训',
    description: `确认报名培训班级“${plan.qualificationName}”吗？`,
    mode: 'plan-confirm',
  })
}

const submitPlanSignup = async () => {
  const plan = pendingPlan.value

  if (!institution.value || !plan) {
    closeActionDialog()
    return
  }

  actionDialogVisible.value = false

  signupLoadingId.value = plan.id

  try {
    await submitTrainingSignup({
      institutionId: institution.value.id,
      qualificationCode: plan.qualificationCode,
      projectType: plan.projectType,
      classId: plan.classId,
    })

    openActionDialog({
      title: '提交成功',
      description: '报名资格审核成功',
      confirmText: '我知道了',
      showCancel: false,
      mode: 'message',
    })
  } catch (error) {
    openActionDialog({
      title: '提交失败',
      description: getErrorMessage(error),
      confirmText: '我知道了',
      showCancel: false,
      mode: 'message',
    })
  } finally {
    signupLoadingId.value = ''
    pendingPlan.value = null
  }
}

const handleActionDialogConfirm = async () => {
  if (actionDialogMode.value === 'message') {
    closeActionDialog()
    return
  }

  await submitPlanSignup()
}

const goToPlanPage = async (page: number) => {
  const nextPage = Math.min(Math.max(1, page), planTotalPages.value)

  if (nextPage === planPage.value) {
    return
  }

  planPage.value = nextPage
  await fetchPlans()
}

const goToReviewPage = async (page: number) => {
  const nextPage = Math.min(Math.max(1, page), reviewTotalPages.value)

  if (nextPage === reviewPage.value) {
    return
  }

  reviewPage.value = nextPage
  await fetchReviews()
}

const jumpToPlanPage = async () => {
  const page = Number(planPageJump.value)

  if (!Number.isFinite(page) || page <= 0) {
    planPageJump.value = String(planPage.value)
    return
  }

  await goToPlanPage(page)
}

const jumpToReviewPage = async () => {
  const page = Number(reviewPageJump.value)

  if (!Number.isFinite(page) || page <= 0) {
    reviewPageJump.value = String(reviewPage.value)
    return
  }

  await goToReviewPage(page)
}

onMounted(async () => {
  try {
    const lookup = await loadLookupOptions()
    qualificationTree.value = lookup.qualificationTree
    projectTypeOptions.value = lookup.projectTypeOptions
  } catch (error) {
    showGlobalMessage(getErrorMessage(error))
  }

  await fetchInstitutionBase()
})

onUnmounted(() => {
  stopImageCarousel()
})
</script>

<template>
  <main class="px-8 py-8">
    <div class="mx-auto flex max-w-[1320px] flex-col gap-6">
      <div class="flex items-center justify-between rounded-[28px] border border-white/70 bg-white/75 px-8 py-5 shadow-soft backdrop-blur">
        <div class="flex items-center gap-4">
          <Button variant="outline" size="sm" @click="backToList">
            <ChevronLeft class="h-4 w-4" />
            返回列表
          </Button>
        </div>
        <div class="flex items-center gap-3">
          <div class="text-sm text-slate-500">
            用户姓名：
            <span class="font-medium text-slate-700">{{ userProfile?.userName || '-' }}</span>
          </div>
          <Button variant="outline" @click="router.push('/certificates')">我的证书</Button>
          <Button variant="outline" @click="logout">退出登录</Button>
        </div>
      </div>

      <Card v-if="institution" class="overflow-hidden rounded-lg p-6">
        <div class="grid grid-cols-[1.08fr_0.92fr] gap-6">
          <div class="space-y-4">
            <div class="overflow-hidden rounded-md bg-slate-100">
              <img :src="activeImage" :alt="institution.name" class="h-[420px] w-full object-cover" />
            </div>
            <div class="grid grid-cols-4 gap-3">
              <button
                v-for="(image, index) in institution.sitePhotoPaths"
                :key="image"
                type="button"
                class="overflow-hidden rounded-md border-2 transition"
                :class="index === activeImageIndex ? 'border-blue-600' : 'border-transparent'"
                @click="activeImageIndex = index"
              >
                <img :src="image" :alt="`${institution.name}-${index + 1}`" class="h-24 w-full object-cover" />
              </button>
            </div>
          </div>

          <div class="flex flex-col rounded-md bg-slate-50 p-8">
            <div class="flex items-start justify-between gap-4">
              <div class="space-y-3">
                <h2 class="text-3xl font-semibold leading-tight text-slate-900">{{ institution.name }}</h2>
                <Badge>{{ institution.tag }}</Badge>
              </div>
              <div class="flex items-center gap-1 text-slate-300">
                <Star
                  v-for="index in 5"
                  :key="index"
                  class="h-5 w-5"
                  :class="index <= Math.round(institution.score) ? 'fill-amber-400 text-amber-400' : ''"
                />
              </div>
            </div>

            <div class="mt-8 grid gap-4 text-sm text-slate-600">
              <div class="flex items-center gap-3">
                <Phone class="h-4 w-4 text-slate-400" />
                <span class="text-base text-blue-600">{{ institution.phone }}</span>
              </div>
              <div class="flex items-center gap-3">
                <MapPin class="h-4 w-4 shrink-0 text-slate-400" />
                <span>{{ institution.address }}</span>
              </div>
            </div>

            <div class="mt-auto flex justify-end pt-10">
              <Button size="lg" @click="handleDirectSignup">我要报名取证</Button>
            </div>
          </div>
        </div>
      </Card>

      <Card v-if="institution" class="p-6">
        <div class="flex gap-8 border-b border-slate-200">
          <button
            v-for="tab in tabList"
            :key="tab.value"
            type="button"
            class="border-b-2 px-1 pb-4 text-lg transition"
            :class="
              activeTab === tab.value
                ? 'border-blue-600 font-semibold text-blue-600'
                : 'border-transparent text-slate-400 hover:text-slate-700'
            "
            @click="activeTab = tab.value"
          >
            {{ tab.label }}
          </button>
        </div>

        <div v-if="activeTab === 'info'" class="grid gap-5 py-8 text-[15px] leading-8 text-slate-600">
          <div class="grid grid-cols-[108px_1fr] gap-3">
            <span class="text-slate-400">机构简介：</span>
            <div>
              {{ institution.description }}
            </div>
          </div>
          <div class="grid grid-cols-[108px_1fr] gap-3">
            <span class="text-slate-400">联系人：</span>
            <div>{{ institution.contactPerson }}</div>
          </div>
          <div class="grid grid-cols-[108px_1fr] gap-3">
            <span class="text-slate-400">联系电话：</span>
            <div class="text-blue-600">{{ institution.phone }}</div>
          </div>
          <div class="grid grid-cols-[108px_1fr] gap-3">
            <span class="text-slate-400">业务咨询：</span>
            <div class="text-blue-600">{{ institution.businessPhone }}</div>
          </div>
          <div class="grid grid-cols-[108px_1fr] gap-3">
            <span class="text-slate-400">机构地址：</span>
            <div>{{ institution.address }}</div>
          </div>
          <div class="grid grid-cols-[108px_1fr] gap-3">
            <span class="text-slate-400">培训项目：</span>
            <div>{{ institution.trainingItems.length > 0 ? institution.trainingItems.join('、') : '--' }}</div>
          </div>
        </div>

        <div
          v-else-if="activeTab === 'plans'"
          class="flex min-h-[260px] items-center justify-center py-10 text-slate-500"
        >
          <div v-if="plansLoaded && plans.length === 0" class="text-center">
            <p class="text-lg">暂无数据</p>
          </div>
          <div v-else class="w-full space-y-4">
            <div
              v-for="plan in plans"
              :key="plan.id"
              class="flex items-stretch justify-between gap-4 rounded-2xl border border-slate-200 bg-slate-50 px-5 py-4 text-base text-slate-700"
            >
              <div class="grid flex-1 grid-cols-2 gap-x-8 gap-y-2">
                <div class="col-span-2 text-base font-semibold leading-8 text-slate-900">
                  {{ plan.qualificationName }}
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">项目类型</span>
                  <div class="text-slate-500">{{ plan.projectTypeLabelText }}</div>
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">人员类型</span>
                  <div class="text-slate-500">{{ plan.personTypeLabelText }}</div>
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">作业类别</span>
                  <div class="text-slate-500">{{ plan.workCategoryLabelText }}</div>
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">操作项目</span>
                  <div class="text-slate-500">{{ plan.operationItemLabelText }}</div>
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">培训时间</span>
                  <div class="text-slate-500">{{ plan.scheduleText }}</div>
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">计划培训人数</span>
                  <div class="text-slate-500">{{ plan.plannedTraineesText }}</div>
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">培训人数</span>
                  <div class="text-slate-500">{{ plan.trainingCountText }}</div>
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">报名时间</span>
                  <div class="text-slate-500">{{ plan.signupPeriodText }}</div>
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">培训地点</span>
                  <div class="text-slate-500">{{ plan.trainingLocationText }}</div>
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">理论学时</span>
                  <div class="text-slate-500">{{ plan.theoryHoursText }}</div>
                </div>
                <div class="grid grid-cols-[112px_1fr] gap-3 text-sm">
                  <span class="text-slate-400">实操学时</span>
                  <div class="text-slate-500">{{ plan.practiceHoursText }}</div>
                </div>
              </div>
              <div class="flex shrink-0 items-end">
                <Button :disabled="signupLoadingId === plan.id" @click="handlePlanSignup(plan)">
                  {{ signupLoadingId === plan.id ? '提交中...' : '预约培训' }}
                </Button>
              </div>
            </div>
            <div class="flex items-center justify-between border-t border-slate-200 pt-4 text-sm text-slate-500">
              <span>共 {{ planTotal }} 条，当前第 {{ planPage }} / {{ planTotalPages }} 页</span>
              <div class="flex items-center gap-2">
                <Button variant="outline" size="sm" :disabled="planPage === 1 || tabLoading" @click="goToPlanPage(planPage - 1)">
                  上一页
                </Button>
                <Button
                  v-for="page in planVisiblePages"
                  :key="`plan-${page}`"
                  :variant="page === planPage ? 'default' : 'outline'"
                  size="sm"
                  :disabled="tabLoading"
                  @click="goToPlanPage(page)"
                >
                  {{ page }}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  :disabled="planPage === planTotalPages || tabLoading"
                  @click="goToPlanPage(planPage + 1)"
                >
                  下一页
                </Button>
                <input
                  v-model="planPageJump"
                  type="number"
                  min="1"
                  :max="planTotalPages"
                  class="h-9 w-20 rounded-md border border-input px-3 text-center text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  @keyup.enter="jumpToPlanPage"
                />
                <Button variant="outline" size="sm" :disabled="tabLoading" @click="jumpToPlanPage">跳转</Button>
              </div>
            </div>
          </div>
        </div>

        <div v-else class="flex min-h-[260px] items-center justify-center py-10 text-center text-slate-500">
          <div v-if="reviewsLoaded && reviews.length === 0">
            <p class="text-lg">暂无数据</p>
          </div>
          <div v-else class="w-full space-y-4 text-left">
            <div
              v-for="review in reviews"
              :key="review.id"
              class="rounded-2xl border border-slate-200 bg-slate-50 px-5 py-4"
            >
              <div class="flex items-center justify-between gap-4">
                <div class="font-medium text-slate-900">{{ review.userName }}</div>
                <div class="text-sm text-slate-400">{{ review.createTime }}</div>
              </div>
              <p class="mt-3 text-sm leading-7 text-slate-600">{{ review.content }}</p>
            </div>
            <div class="flex items-center justify-between border-t border-slate-200 pt-4 text-sm text-slate-500">
              <span>共 {{ reviewTotal }} 条，当前第 {{ reviewPage }} / {{ reviewTotalPages }} 页</span>
              <div class="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  :disabled="reviewPage === 1 || tabLoading"
                  @click="goToReviewPage(reviewPage - 1)"
                >
                  上一页
                </Button>
                <Button
                  v-for="page in reviewVisiblePages"
                  :key="`review-${page}`"
                  :variant="page === reviewPage ? 'default' : 'outline'"
                  size="sm"
                  :disabled="tabLoading"
                  @click="goToReviewPage(page)"
                >
                  {{ page }}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  :disabled="reviewPage === reviewTotalPages || tabLoading"
                  @click="goToReviewPage(reviewPage + 1)"
                >
                  下一页
                </Button>
                <input
                  v-model="reviewPageJump"
                  type="number"
                  min="1"
                  :max="reviewTotalPages"
                  class="h-9 w-20 rounded-md border border-input px-3 text-center text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  @keyup.enter="jumpToReviewPage"
                />
                <Button variant="outline" size="sm" :disabled="tabLoading" @click="jumpToReviewPage">跳转</Button>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <Card
        v-if="!loading && !institution"
        class="flex min-h-[220px] items-center justify-center p-8 text-base text-slate-500"
      >
        未获取到机构详情，请返回列表后重试。
      </Card>
    </div>
    <InstitutionSignupDialog
      v-model="signupDialogVisible"
      :institution-id="institution?.id || ''"
      :institution-name="institution?.name || ''"
    />
    <ActionDialog
      v-model="actionDialogVisible"
      :title="actionDialogTitle"
      :description="actionDialogDescription"
      :confirm-text="actionDialogConfirmText"
      :show-cancel="actionDialogShowCancel"
      @confirm="handleActionDialogConfirm"
      @cancel="closeActionDialog"
    />
  </main>
</template>
