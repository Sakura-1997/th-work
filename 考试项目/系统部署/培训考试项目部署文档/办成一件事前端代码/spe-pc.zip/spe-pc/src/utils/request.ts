import axios, { type AxiosRequestConfig, type InternalAxiosRequestConfig } from 'axios'
import qs from 'qs'

import { clearAuthSession, getToken } from '@/utils/session'
import { getErrorMessage } from '@/utils/training'

type CustomHeaders = InternalAxiosRequestConfig['headers'] & {
  skipToken?: boolean
}

const service = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  timeout: 50000,
  paramsSerializer: {
    serialize: (params) => qs.stringify(params, { arrayFormat: 'repeat' }),
  },
})

service.interceptors.request.use((config) => {
  const token = getToken()
  const headers = (config.headers || {}) as CustomHeaders

  headers.VERSION = import.meta.env.VITE_VERSION || 'A'

  if (token && !headers.skipToken) {
    headers.Authorization = `Bearer ${token}`
  }

  config.headers = headers
  return config
})

service.interceptors.response.use(
  (response) => {
    if (response.config.responseType === 'blob') {
      return response.data
    }

    const data = response.data

    if (data?.access_token) {
      return data
    }

    if (typeof data?.code === 'undefined') {
      return data
    }

    if (Number(data.code) !== 0) {
      return Promise.reject(data)
    }

    return data
  },
  (error) => {
    const status = Number(error.response?.status)

    if (status === 401 || status === 424) {
      clearAuthSession()

      if (window.location.pathname !== '/login') {
        window.alert('登录态已失效，请重新登录')
        window.location.href = '/login'
      }

      return Promise.reject({ msg: '登录态已失效，请重新登录' })
    }

    return Promise.reject({
      msg: getErrorMessage(error.response?.data || error),
      status,
      raw: error,
    })
  },
)

function request<T = unknown>(config: AxiosRequestConfig) {
  return service.request<unknown, T>(config)
}

export default request
