import { computed, reactive } from 'vue'

type MessageType = 'error' | 'success' | 'info'

const messageState = reactive({
  visible: false,
  text: '',
  type: 'error' as MessageType,
})

let messageTimer = 0

export function showGlobalMessage(text: string, type: MessageType = 'error', duration = 2600) {
  messageState.text = text
  messageState.type = type
  messageState.visible = true

  if (messageTimer) {
    window.clearTimeout(messageTimer)
  }

  messageTimer = window.setTimeout(() => {
    hideGlobalMessage()
  }, duration)
}

export function hideGlobalMessage() {
  messageState.visible = false
  messageState.text = ''

  if (messageTimer) {
    window.clearTimeout(messageTimer)
    messageTimer = 0
  }
}

export function useGlobalMessage() {
  return {
    visible: computed(() => messageState.visible),
    text: computed(() => messageState.text),
    type: computed(() => messageState.type),
  }
}
