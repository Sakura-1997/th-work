<script setup lang="ts">
import type { CertificatePreviewViewModel } from '@/types/certificate'

defineProps<{
  model: CertificatePreviewViewModel
}>()
</script>

<template>
  <div class="cert-shell cert-container">
    <img class="cert-bg" :src="model.backBackgroundUrl" :alt="`${model.certificateName}反面`" />

    <div class="cert-photo">
      <img v-if="model.photoUrl" :src="model.photoUrl" :alt="`${model.name}证件照`" class="cert-photo-image" />
      <div v-else class="cert-photo-empty">暂无照片</div>
    </div>

    <div class="cert-info-no">
      <div class="cert-label cert-label-main">证号</div>
      <div class="cert-value cert-value-lg cert-value-no-wrap">{{ model.certNo }}</div>
    </div>

    <div class="cert-info-name">
      <div class="cert-label cert-label-main">姓名</div>
      <div class="cert-value">{{ model.name }}</div>
    </div>

    <div class="cert-info-type">
      <div class="cert-label" :style="{ color: model.accentColor }">{{ model.typeLabel }}</div>
      <div class="cert-value">{{ model.typeValue }}</div>
    </div>

    <div class="cert-info-gender">
      <div class="cert-label cert-label-main">性别</div>
      <div class="cert-value">{{ model.genderText }}</div>
    </div>

    <div class="cert-info-type-wide">
      <div class="cert-label" :style="{ color: model.accentColor }">{{ model.wideTypeLabel }}</div>
      <div class="cert-value">{{ model.wideTypeValue }}</div>
    </div>

    <div class="cert-info-issue">
      <div class="cert-label cert-label-main">初领日期</div>
      <div class="cert-value">{{ model.issueDateText }}</div>
    </div>

    <div class="cert-info-valid">
      <div class="cert-label cert-label-main">有效期限</div>
      <div class="cert-value cert-value-no-wrap">{{ model.validDateText }}</div>
    </div>

    <div class="cert-info-org-left">
      <div class="cert-label cert-label-main">签发机关</div>
      <div class="cert-value">{{ model.issuingAuthorityText }}</div>
    </div>

    <div class="cert-qr">
      <img v-if="model.qrCodeImageUrl" :src="model.qrCodeImageUrl" alt="证书二维码" class="cert-qr-image" />
      <div v-else class="cert-qr-empty">暂无二维码</div>
    </div>
  </div>
</template>

<style scoped>
.cert-shell {
  position: relative;
  width: 100%;
  aspect-ratio: 1.58;
  overflow: hidden;
  border-radius: 12px;
  background: #fff;
}

.cert-container {
  container-type: inline-size;
  font-family: 'Source Han Sans CN', 'Noto Sans CJK SC', 'Microsoft YaHei', sans-serif;
}

.cert-bg,
.cert-photo-image,
.cert-qr-image {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.cert-photo,
.cert-info-no,
.cert-info-name,
.cert-info-type,
.cert-info-gender,
.cert-info-type-wide,
.cert-info-issue,
.cert-info-valid,
.cert-info-org-left,
.cert-qr {
  position: absolute;
}

.cert-photo {
  left: 5.8%;
  top: 11.1%;
  width: 23.4%;
  height: 46.3%;
  overflow: hidden;
  border-radius: 1.4cqw;
  background: rgba(255, 255, 255, 0.92);
}

.cert-photo-empty,
.cert-qr-empty {
  display: flex;
  width: 100%;
  height: 100%;
  align-items: center;
  justify-content: center;
  background: rgba(255, 255, 255, 0.9);
  color: #64748b;
  font-size: 2.2cqw;
}

.cert-info-no {
  left: 32.7%;
  top: 11.1%;
  width: 50%;
}

.cert-info-name {
  left: 32.7%;
  top: 26%;
}

.cert-info-type {
  left: 58%;
  top: 26%;
}

.cert-info-gender {
  left: 32.7%;
  top: 41%;
}

.cert-info-type-wide {
  left: 58%;
  top: 41%;
  width: 38%;
}

.cert-info-issue {
  left: 5.8%;
  top: 66%;
}

.cert-info-valid {
  left: 32.7%;
  top: 66%;
  width: 44%;
}

.cert-info-org-left {
  left: 5.8%;
  top: 81%;
  width: 58%;
}

.cert-qr {
  right: 7%;
  bottom: 9.3%;
  width: 17.5%;
  aspect-ratio: 1;
  overflow: hidden;
  border-radius: 1.2cqw;
}

.cert-label {
  margin-bottom: 1.17cqw;
  color: #222;
  font-size: 2.06cqw;
  font-weight: 400;
  line-height: 1;
}

.cert-value {
  max-width: 38cqw;
  color: #000;
  font-size: 3.09cqw;
  font-weight: 400;
  line-height: 1.2;
  word-break: break-all;
}

.cert-value-lg {
  font-size: 3.92cqw;
}

.cert-value-no-wrap {
  max-width: none;
  white-space: nowrap;
  word-break: normal;
}
</style>
