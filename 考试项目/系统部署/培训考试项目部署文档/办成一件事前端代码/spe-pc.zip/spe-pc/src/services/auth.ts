import md5 from 'blueimp-md5'

import type { LoginResult, UserProfileState } from '@/types/training'
import { fetchCurrentUserProfile } from '@/api/user'
import { loadLookupOptions } from '@/services/app-bootstrap'
import { setAuthSession, setUserProfile } from '@/utils/session'
import { normalizeUserProfile } from '@/utils/training'

const JIANGXI_TRUSTED_APP_URL = import.meta.env.VITE_JIANGXI_TRUSTED_APP_URL
const JIANGXI_TRUSTED_APPMARK = import.meta.env.VITE_JIANGXI_TRUSTED_APPMARK
const JIANGXI_TRUSTED_APPWORD = import.meta.env.VITE_JIANGXI_TRUSTED_APPWORD
const JIANGXI_TRUSTED_LOGIN_UUID = import.meta.env.VITE_JIANGXI_TRUSTED_LOGIN_UUID || 'bzduqvGhZpu2'
const JIANGXI_TRUSTED_LOGIN_TYPE = import.meta.env.VITE_JIANGXI_TRUSTED_LOGIN_TYPE || '1'
const JIANGXI_TRUSTED_USER_TYPE = '2'
const TRUSTED_AUTO_LOGIN_KEY = 'jiangxi_trusted_auto_login_started'

function padTimeSegment(value: number) {
  return String(value).padStart(2, '0')
}

function getTrustedLoginTime() {
  const now = new Date()

  return [
    now.getFullYear(),
    padTimeSegment(now.getMonth() + 1),
    padTimeSegment(now.getDate()),
    padTimeSegment(now.getHours()),
    padTimeSegment(now.getMinutes()),
    padTimeSegment(now.getSeconds()),
  ].join('')
}

function getTrustedLoginBaseUrl() {
  return `${JIANGXI_TRUSTED_APP_URL.replace(/\/+$/, '')}/sso/trust.do`
}

function getLegacyLoginBaseUrl() {
  return `${JIANGXI_TRUSTED_APP_URL.replace(/\/+$/, '')}/front/login.do`
}

export function hasTrustedAutoLoginStarted() {
  return window.sessionStorage.getItem(TRUSTED_AUTO_LOGIN_KEY) === '1'
}

export function markTrustedAutoLoginStarted() {
  window.sessionStorage.setItem(TRUSTED_AUTO_LOGIN_KEY, '1')
}

export function canUseTrustedLogin() {
  return Boolean(JIANGXI_TRUSTED_APP_URL && JIANGXI_TRUSTED_APPMARK && JIANGXI_TRUSTED_APPWORD)
}

export function canUseLegacyTrustedLogin() {
  return Boolean(JIANGXI_TRUSTED_APP_URL && JIANGXI_TRUSTED_LOGIN_UUID)
}

export function getJiangxiTrustedTransferUrl(callbackUrl: string) {
  const time = getTrustedLoginTime()
  const sign = md5(`${JIANGXI_TRUSTED_APPMARK}${JIANGXI_TRUSTED_APPWORD}${time}`)
  const loginUrl = new URL(getTrustedLoginBaseUrl())

  loginUrl.searchParams.set('appmark', JIANGXI_TRUSTED_APPMARK)
  loginUrl.searchParams.set('sign', sign)
  loginUrl.searchParams.set('time', time)
  loginUrl.searchParams.set('type', JIANGXI_TRUSTED_USER_TYPE)
  loginUrl.searchParams.set('gotourl', callbackUrl)

  return loginUrl.toString()
}

export function getJiangxiLegacyLoginUrl(callbackUrl: string) {
  const loginUrl = new URL(getLegacyLoginBaseUrl())

  loginUrl.searchParams.set('uuid', JIANGXI_TRUSTED_LOGIN_UUID)
  loginUrl.searchParams.set('gotourl', window.btoa(callbackUrl))
  loginUrl.searchParams.set('type', JIANGXI_TRUSTED_LOGIN_TYPE)

  return loginUrl.toString()
}

export async function initializeLoginSession(loginResult: LoginResult) {
  setAuthSession({
    token: String(loginResult.access_token || ''),
    refreshToken: String(loginResult.refresh_token || ''),
    tenantId: String(loginResult.tenant_id || ''),
  })

  const [profileResponse] = await Promise.all([fetchCurrentUserProfile(), loadLookupOptions(true)])
  const normalizedProfile = normalizeUserProfile(profileResponse.data)

  setUserProfile(normalizedProfile)
  return normalizedProfile
}

export function getTrustedLoginErrorMessage(error: unknown) {
  const message = String(
    (error as Record<string, unknown> | null)?.msg ||
      (error as Record<string, unknown> | null)?.message ||
      '',
  )

  if (message.includes('ticket')) {
    return '可信登录已失效，请重新登录'
  }

  return '可信登录失败，请重新登录'
}

export type { UserProfileState }
