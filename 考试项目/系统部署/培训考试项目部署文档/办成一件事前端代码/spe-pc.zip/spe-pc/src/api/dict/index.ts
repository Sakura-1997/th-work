import request from '@/utils/request'
import type { ApiResponse } from '@/types/api'

export interface DictItemRaw extends Record<string, unknown> {
  dictLabel?: string
  label?: string
  name?: string
  dictValue?: string | number
  value?: string | number
  code?: string | number
}

export function fetchDictByType(type: string) {
  return request<ApiResponse<DictItemRaw[]>>({
    url: '/admin/dict/type',
    method: 'get',
    params: {
      type,
    },
  })
}
