import { createRouter, createWebHistory } from 'vue-router'
import { getToken } from '@/utils/session'

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      name: 'home',
      component: () => import('@/views/HomeView.vue'),
      meta: {
        title: '首页',
      },
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('@/views/LoginView.vue'),
      meta: {
        title: '登录',
      },
    },
    {
      path: '/institutions',
      name: 'institutions',
      component: () => import('@/views/InstitutionListView.vue'),
      meta: {
        title: '培训机构列表',
      },
    },
    {
      path: '/institutions/:id',
      name: 'institution-detail',
      component: () => import('@/views/InstitutionDetailView.vue'),
      meta: {
        title: '培训机构详情',
      },
    },
    {
      path: '/certificates',
      name: 'certificate-list',
      component: () => import('@/views/CertificateListView.vue'),
      meta: {
        title: '我的证书',
      },
    },
    {
      path: '/certificates/:id',
      name: 'certificate-preview',
      component: () => import('@/views/CertificatePreviewView.vue'),
      meta: {
        title: '证书预览',
      },
    },
  ],
})

router.beforeEach((to) => {
  const token = getToken()
  const trustedTicket = Array.isArray(to.query.ticket)
    ? String(to.query.ticket[0] || '').trim()
    : String(to.query.ticket || '').trim()

  if (to.path === '/login' && trustedTicket) {
    return true
  }

  if (!token && to.path !== '/' && to.path !== '/login') {
    return {
      path: '/',
      query: {
        redirect: to.fullPath,
      },
    }
  }

  if (to.path === '/login' && token) {
    return '/'
  }

  return true
})

router.afterEach((to) => {
  const pageTitle = typeof to.meta.title === 'string' ? `${to.meta.title} - 培训机构系统` : '培训机构系统'
  document.title = pageTitle
})

export default router
