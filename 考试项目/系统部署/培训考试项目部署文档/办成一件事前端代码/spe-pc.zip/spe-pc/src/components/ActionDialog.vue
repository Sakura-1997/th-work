<script setup lang="ts">
import { X } from '@lucide/vue'

import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'

withDefaults(
  defineProps<{
    modelValue: boolean
    title: string
    description?: string
    confirmText?: string
    cancelText?: string
    showCancel?: boolean
  }>(),
  {
    description: '',
    confirmText: '确定',
    cancelText: '取消',
    showCancel: true,
  },
)

const emit = defineEmits<{
  'update:modelValue': [value: boolean]
  confirm: []
  cancel: []
}>()

const closeDialog = () => {
  emit('cancel')
  emit('update:modelValue', false)
}

const handleConfirm = () => {
  emit('confirm')
}
</script>

<template>
  <Teleport to="body">
    <div
      v-if="modelValue"
      class="fixed inset-0 z-[9998] flex items-center justify-center bg-slate-950/30 px-4"
      @click.self="closeDialog"
    >
      <Card class="w-full max-w-[520px] p-0 shadow-2xl">
        <div class="flex items-center justify-between border-b border-slate-200 px-6 py-5">
          <h3 class="text-xl font-semibold text-slate-900">{{ title }}</h3>
          <button
            type="button"
            class="rounded-full p-2 text-slate-400 transition hover:bg-slate-100 hover:text-slate-600"
            @click="closeDialog"
          >
            <X class="h-4 w-4" />
          </button>
        </div>

        <div class="px-6 py-6 text-sm leading-7 text-slate-600">
          {{ description || '--' }}
        </div>

        <div class="flex justify-end gap-3 border-t border-slate-200 px-6 py-5">
          <Button v-if="showCancel" variant="outline" @click="closeDialog">{{ cancelText }}</Button>
          <Button @click="handleConfirm">{{ confirmText }}</Button>
        </div>
      </Card>
    </div>
  </Teleport>
</template>
