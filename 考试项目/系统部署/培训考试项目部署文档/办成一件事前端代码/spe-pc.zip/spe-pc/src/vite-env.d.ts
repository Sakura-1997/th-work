/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_URL: string
  readonly VITE_ADMIN_PROXY_PATH: string
  readonly VITE_JIANGXI_TRUSTED_APP_URL: string
  readonly VITE_JIANGXI_TRUSTED_APPMARK: string
  readonly VITE_JIANGXI_TRUSTED_APPWORD: string
  readonly VITE_JIANGXI_TRUSTED_LOGIN_UUID: string
  readonly VITE_JIANGXI_TRUSTED_LOGIN_TYPE: string
  readonly VITE_USE_GANFUTONG: string
  readonly VITE_VERSION: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
