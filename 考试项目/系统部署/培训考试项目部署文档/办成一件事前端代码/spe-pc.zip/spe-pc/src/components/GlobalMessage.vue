<script setup lang="ts">
import { X } from '@lucide/vue'
import { computed } from 'vue'

import { hideGlobalMessage, useGlobalMessage } from '@/composables/use-global-message'

const { visible, text, type } = useGlobalMessage()

const messageClass = computed(() => {
  if (type.value === 'success') {
    return 'border-emerald-200 bg-emerald-50 text-emerald-700'
  }

  if (type.value === 'info') {
    return 'border-blue-200 bg-blue-50 text-blue-700'
  }

  return 'border-red-200 bg-red-50 text-red-600'
})
</script>

<template>
  <Teleport to="body">
    <Transition name="global-message-fade">
      <div v-if="visible" class="pointer-events-none fixed inset-x-0 top-5 z-[10000] flex justify-center px-4">
        <div
          class="pointer-events-auto flex max-w-[520px] items-center gap-3 rounded-2xl border px-4 py-3 text-sm shadow-xl"
          :class="messageClass"
        >
          <span class="flex-1 leading-6">{{ text }}</span>
          <button
            type="button"
            class="rounded-full p-1 text-current/70 transition hover:bg-black/5 hover:text-current"
            @click="hideGlobalMessage"
          >
            <X class="h-4 w-4" />
          </button>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>
