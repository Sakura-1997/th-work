import { computed, ref, watch, type Ref } from 'vue'

import { fetchCertificateFileBase64 } from '@/api/certificate'
import type { QualificationNode } from '@/types/training'
import type {
  CertificatePreviewData,
  CertificatePreviewViewModel,
  CertificateRecordRaw,
} from '@/types/certificate'

import blueBackBackgroundUrl from '@/assets/certificate/blue-back-no-text.png'
import blueFrontBackgroundUrl from '@/assets/certificate/blue-front.png'
import greenBackBackgroundUrl from '@/assets/certificate/green-back-no-text.png'
import greenFrontBackgroundUrl from '@/assets/certificate/green-front.png'

const backendAssetBase = (() => {
  const base = toStringValue(import.meta.env.VITE_ADMIN_PROXY_PATH).replace(/\/$/, '')

  if (base && !base.endsWith('/api')) {
    return `${base}/api`
  }

  return base
})()

const sameOriginApiBase = toStringValue(import.meta.env.VITE_API_URL).replace(/\/$/, '')

function toStringValue(value: unknown) {
  if (value === null || value === undefined) {
    return ''
  }

  return String(value).trim()
}

function toDisplayValue(value: unknown, fallback = '-') {
  const normalizedValue = toStringValue(value)
  return normalizedValue || fallback
}

function splitPipeValue(value: unknown) {
  return toStringValue(value)
    .split('|')
    .map((item) => item.trim())
    .filter(Boolean)
}

function normalizeDateText(value: unknown) {
  const rawValue = toStringValue(value)

  if (!rawValue) {
    return '-'
  }

  const normalizedValue = rawValue.replace(/[T\s].*$/, '').replace(/[./]/g, '-')
  return normalizedValue || rawValue
}

function normalizeGenderText(value: unknown) {
  const normalizedValue = toStringValue(value).toLowerCase()

  if (['1', 'm', 'male', '男'].includes(normalizedValue)) {
    return '男'
  }

  if (['2', 'f', 'female', '女'].includes(normalizedValue)) {
    return '女'
  }

  return toDisplayValue(value)
}

function isDirectPreviewUrl(value: string) {
  return /^(https?:)?\/\//i.test(value) || value.startsWith('data:') || value.startsWith('blob:')
}

function resolveAssetUrl(value: unknown) {
  const url = toStringValue(value)

  if (!url) {
    return ''
  }

  if (isDirectPreviewUrl(url)) {
    return url
  }

  if (!backendAssetBase) {
    return url
  }

  if (url.startsWith('/')) {
    return `${backendAssetBase}${url}`
  }

  return `${backendAssetBase}/${url}`
}

function resolveApiProxyUrl(value: unknown) {
  const url = toStringValue(value)

  if (!url) {
    return ''
  }

  if (isDirectPreviewUrl(url)) {
    return url
  }

  if (!sameOriginApiBase) {
    return url
  }

  if (url.startsWith('/')) {
    return `${sameOriginApiBase}${url}`
  }

  return `${sameOriginApiBase}/${url}`
}

function shouldResolveByAssetUrl(value: string) {
  return value.startsWith('/') || value.startsWith('admin/') || value.startsWith('api/')
}

function getImageMimeType(filePath = '') {
  const normalizedPath = toStringValue(filePath).toLowerCase()

  if (normalizedPath.endsWith('.jpg') || normalizedPath.endsWith('.jpeg')) {
    return 'image/jpeg'
  }

  if (normalizedPath.endsWith('.webp')) {
    return 'image/webp'
  }

  if (normalizedPath.endsWith('.gif')) {
    return 'image/gif'
  }

  return 'image/png'
}

function normalizeBase64Image(value: unknown, filePath = '') {
  const rawValue = toStringValue(value)

  if (!rawValue) {
    return ''
  }

  if (rawValue.startsWith('data:image')) {
    return rawValue
  }

  return `data:${getImageMimeType(filePath)};base64,${rawValue}`
}

function buildQualificationLabelMap(tree: QualificationNode[]) {
  const labelMap = new Map<string, string>()

  const travel = (nodes: QualificationNode[]) => {
    nodes.forEach((node) => {
      const code = toStringValue(node.code)
      const codes = splitPipeValue(node.codes || node.code)
      const names = splitPipeValue(node.names || node.name)
      const label = names[names.length - 1] || toStringValue(node.name || node.names)

      if (code && label) {
        labelMap.set(code, label)
      }

      codes.forEach((item, index) => {
        const matchedLabel = names[index] || label

        if (item && matchedLabel) {
          labelMap.set(item, matchedLabel)
        }
      })

      if (node.children?.length) {
        travel(node.children)
      }
    })
  }

  travel(tree)
  return labelMap
}

function resolveCertificateTypeCode(data: CertificatePreviewData) {
  const typeCandidate = (
    [
    data.certificateTypeCode,
    data.certificateType,
    data.workType,
    data.names,
    data.jobTypeCodeDictText,
    data.personnelType,
  ]
    .map((item) => toStringValue(item))
    .find(Boolean) || ''
  ).toLowerCase()

  if (
    typeCandidate === '2' ||
    typeCandidate.includes('安全生产') ||
    typeCandidate.includes('管理能力') ||
    typeCandidate.includes('负责人') ||
    typeCandidate.includes('管理人员')
  ) {
    return '2' as const
  }

  return '1' as const
}

function normalizeCertificateText(raw: CertificateRecordRaw | Record<string, unknown>) {
  return {
    certificateId: toStringValue(raw.certificateId || raw.id),
    certificateTypeCode: toStringValue(raw.certificateTypeCode),
    certificateType: toStringValue(raw.certificateType),
    workType: toStringValue(raw.workType),
    certNo: toStringValue(raw.certNo),
    name: toStringValue(raw.name),
    gender: toStringValue(raw.gender),
    jobTypeCodeDictText: toStringValue(raw.jobTypeCodeDictText),
    operItemCodeDictText: toStringValue(raw.operItemCodeDictText),
    personnelType: toStringValue(raw.personnelType),
    industryType: toStringValue(raw.industryType),
    issueDate: toStringValue(raw.issueDate),
    validStartDate: toStringValue(raw.validStartDate),
    validEndDate: toStringValue(raw.validEndDate),
    issuingAuthority: toStringValue(raw.issuingAuthority),
    imgPath: toStringValue(raw.imgPath),
    qrcodePath: toStringValue(raw.qrcodePath || raw.qrCodeUrl),
    codes: toStringValue(raw.codes),
    names: toStringValue(raw.names),
    raw: raw as Record<string, unknown>,
  } satisfies CertificatePreviewData
}

export function normalizeCertificatePreviewData(raw: unknown) {
  if (!raw || typeof raw !== 'object') {
    return null
  }

  return normalizeCertificateText(raw as CertificateRecordRaw)
}

export function parseCertificateRouteData(rawValue: unknown) {
  const queryValue = Array.isArray(rawValue) ? rawValue[0] : rawValue
  const normalizedValue = toStringValue(queryValue)

  if (!normalizedValue) {
    return null
  }

  try {
    return normalizeCertificatePreviewData(JSON.parse(normalizedValue))
  } catch {
    try {
      return normalizeCertificatePreviewData(JSON.parse(decodeURIComponent(normalizedValue)))
    } catch {
      return null
    }
  }
}

async function resolveRemoteImageUrl(filePath: string) {
  const response = await fetchCertificateFileBase64(filePath)

  if (typeof response === 'string') {
    return normalizeBase64Image(response, filePath)
  }

  if (response && typeof response === 'object') {
    const payload = response as Record<string, unknown>
    const directUrl = toStringValue(payload.url || payload.previewUrl || payload.data)

    if (directUrl) {
      return isDirectPreviewUrl(directUrl) ? directUrl : normalizeBase64Image(directUrl, filePath)
    }
  }

  return ''
}

async function resolveCertificatePhotoUrl(filePath: string) {
  if (!filePath) {
    return ''
  }

  if (isDirectPreviewUrl(filePath)) {
    return filePath
  }

  if (shouldResolveByAssetUrl(filePath)) {
    const base64Url = await resolveRemoteImageUrl(filePath)
    return base64Url || resolveApiProxyUrl(filePath) || resolveAssetUrl(filePath)
  }

  return await resolveRemoteImageUrl(filePath)
}

export function useCertificatePreview(source: Ref<CertificatePreviewData | null>, qualificationTree: Ref<QualificationNode[]>) {
  const photoUrl = ref('')
  const qrCodeImageUrl = ref('')
  const qualificationLabelMap = computed(() => buildQualificationLabelMap(qualificationTree.value))

  const previewModel = computed<CertificatePreviewViewModel | null>(() => {
    if (!source.value) {
      return null
    }

    const data = source.value
    const codeParts = splitPipeValue(data.codes)
    const nameParts = splitPipeValue(data.names)
    const labelMap = qualificationLabelMap.value
    const certificateTypeCode = resolveCertificateTypeCode(data)
    const isGreenCertificate = certificateTypeCode === '2'
    const typeValue = isGreenCertificate
      ? toDisplayValue(data.personnelType || nameParts[0] || labelMap.get(codeParts[0]) || data.raw.personTypeName)
      : toDisplayValue(data.jobTypeCodeDictText || nameParts[1] || labelMap.get(codeParts[1]) || data.raw.jobTypeName)
    const wideTypeValue = isGreenCertificate
      ? toDisplayValue(
          data.industryType || nameParts[1] || nameParts[2] || labelMap.get(codeParts[1]) || labelMap.get(codeParts[2]),
        )
      : toDisplayValue(
          data.operItemCodeDictText || nameParts[2] || labelMap.get(codeParts[2]) || data.raw.operationItemName,
        )

    return {
      certificateId: data.certificateId,
      certificateTypeCode,
      certificateName: isGreenCertificate ? '安全生产知识和管理能力考核合格证' : '特种作业操作证',
      certNo: toDisplayValue(data.certNo),
      name: toDisplayValue(data.name),
      genderText: normalizeGenderText(data.gender),
      typeLabel: isGreenCertificate ? '人员类型' : '作业类别',
      typeValue,
      wideTypeLabel: isGreenCertificate ? '行业类别' : '操作项目',
      wideTypeValue,
      issueDateText: normalizeDateText(data.issueDate),
      validDateText: `${normalizeDateText(data.validStartDate)} 至 ${normalizeDateText(data.validEndDate)}`,
      issuingAuthorityText: toDisplayValue(data.issuingAuthority),
      photoUrl: photoUrl.value,
      qrCodeImageUrl: qrCodeImageUrl.value,
      accentColor: isGreenCertificate ? '#008b45' : '#005bac',
      backBackgroundUrl: isGreenCertificate ? greenBackBackgroundUrl : blueBackBackgroundUrl,
      frontBackgroundUrl: isGreenCertificate ? greenFrontBackgroundUrl : blueFrontBackgroundUrl,
    }
  })

  watch(
    source,
    async (value) => {
      photoUrl.value = ''
      qrCodeImageUrl.value = ''

      if (!value) {
        return
      }

      if (value.imgPath) {
        photoUrl.value = await resolveCertificatePhotoUrl(value.imgPath)
      }

      if (value.qrcodePath) {
        qrCodeImageUrl.value = value.qrcodePath
      }
    },
    {
      immediate: true,
    },
  )

  return {
    previewModel,
    photoUrl: computed(() => photoUrl.value),
    qrCodeImageUrl: computed(() => qrCodeImageUrl.value),
  }
}
