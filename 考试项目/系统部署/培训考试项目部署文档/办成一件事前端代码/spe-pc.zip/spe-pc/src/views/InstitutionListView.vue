<script setup lang="ts">
import { ChevronDown } from '@lucide/vue'
import { computed, onMounted, reactive, ref, watch } from 'vue'
import { useRouter } from 'vue-router'

import {
  fetchInstitutionList,
  type InstitutionListQuery,
} from '@/api/institution'
import InstitutionCard from '@/components/InstitutionCard.vue'
import InstitutionSignupDialog from '@/components/InstitutionSignupDialog.vue'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { hideGlobalLoading, showGlobalLoading } from '@/composables/use-global-loading'
import { showGlobalMessage } from '@/composables/use-global-message'
import { getDefaultArea, loadLookupOptions } from '@/services/app-bootstrap'
import type { OptionItem } from '@/types/api'
import type { InstitutionListViewModel, QualificationNode } from '@/types/training'
import { clearAuthSession, getUserProfile } from '@/utils/session'
import { getErrorMessage, normalizeInstitutionListItem } from '@/utils/training'

const router = useRouter()
const userProfile = getUserProfile()
type MatterTabKey =
  | 'special-operation-initial'
  | 'special-operation-renewal'
  | 'safety-certificate-initial'
  | 'safety-certificate-renewal'

const DEFAULT_MATTER_TAB: MatterTabKey = 'special-operation-initial'
const matterTabOptions: Array<{
  key: MatterTabKey
  label: string
  businessType: 'special-operation' | 'safety-certificate'
  trainingPhase: 'initial' | 'renewal'
}> = [
  {
    key: 'special-operation-initial',
    label: '特种作业操作证（初次取证）',
    businessType: 'special-operation',
    trainingPhase: 'initial',
  },
  {
    key: 'special-operation-renewal',
    label: '特种作业操作证（换证）',
    businessType: 'special-operation',
    trainingPhase: 'renewal',
  },
  {
    key: 'safety-certificate-initial',
    label: '安全生产知识和管理能力考核合格证（初次取证）',
    businessType: 'safety-certificate',
    trainingPhase: 'initial',
  },
  {
    key: 'safety-certificate-renewal',
    label: '安全生产知识和管理能力考核合格证（换证）',
    businessType: 'safety-certificate',
    trainingPhase: 'renewal',
  },
]

const filters = reactive({
  areaId: '',
  trainingType: '',
  personTypeCode: '',
  workCategoryCode: '',
  trainingProjectCode: '',
  currentPage: 1,
  pageSize: 10,
})

const areaOptions = ref<OptionItem[]>([])
const projectTypeOptions = ref<OptionItem[]>([])
const qualificationTree = ref<QualificationNode[]>([])
const institutions = ref<InstitutionListViewModel[]>([])
const total = ref(0)
const loading = ref(false)
const lookupLoading = ref(false)
const pageJump = ref('1')
const signupDialogVisible = ref(false)
const signupInstitutionId = ref('')
const signupInstitutionName = ref('')
const activeMatterTab = ref<MatterTabKey>(DEFAULT_MATTER_TAB)

const totalPages = computed(() => Math.max(1, Math.ceil(total.value / filters.pageSize)))
const currentPersonType = computed(() =>
  qualificationTree.value.find((item) => item.code === filters.personTypeCode),
)
const currentWorkCategory = computed(() =>
  (currentPersonType.value?.children || []).find((item) => item.code === filters.workCategoryCode),
)
const currentMatterTab = computed(
  () => matterTabOptions.find((item) => item.key === activeMatterTab.value) || matterTabOptions[0],
)
const isSpecialOperationTab = computed(() => currentMatterTab.value.businessType === 'special-operation')
const isSafetyCertificateTab = computed(() => currentMatterTab.value.businessType === 'safety-certificate')
const visiblePages = computed(() => {
  const pages: number[] = []
  const maxVisible = 7
  const start = Math.max(1, filters.currentPage - 3)
  const end = Math.min(totalPages.value, start + maxVisible - 1)
  const normalizedStart = Math.max(1, end - maxVisible + 1)

  for (let page = normalizedStart; page <= end; page += 1) {
    pages.push(page)
  }

  return pages
})

const listQuery = computed(
  () =>
    ({
      current: filters.currentPage,
      size: filters.pageSize,
      areaId: filters.areaId || undefined,
      projectType: filters.trainingType || undefined,
      qualificationCode: getQualificationFilterCode(),
    }) satisfies InstitutionListQuery,
)

const allPersonTypeOptions = computed(() =>
  qualificationTree.value.map((item) => ({
    label: item.name || item.names?.split('|')[0] || item.code,
    value: item.code,
  })),
)

const getNodeSearchText = (node: QualificationNode) =>
  [node.name, node.names, node.code]
    .filter(Boolean)
    .join('|')
    .trim()

const matchByKeywordGroups = (sourceText: string, keywordGroups: string[][]) =>
  keywordGroups.some((group) => group.every((keyword) => sourceText.includes(keyword)))

const getPreferredPersonTypeOption = (keywordGroups: string[][]) => {
  const matchedNodes = qualificationTree.value.filter((node) =>
    matchByKeywordGroups(getNodeSearchText(node), keywordGroups),
  )

  const preferredNode = matchedNodes.sort((left, right) => {
    const childCountDiff = (right.children?.length || 0) - (left.children?.length || 0)

    if (childCountDiff !== 0) {
      return childCountDiff
    }

    return String(left.code).localeCompare(String(right.code))
  })[0]

  if (!preferredNode) {
    return undefined
  }

  return {
    label: preferredNode.name || preferredNode.names?.split('|')[0] || preferredNode.code,
    value: preferredNode.code,
  }
}

const specialOperationPersonTypeOption = computed(() =>
  getPreferredPersonTypeOption([['特种作业人员'], ['特种作业', '人员']]),
)

const principalPersonTypeOption = computed(() =>
  getPreferredPersonTypeOption([['主要负责人']]),
)

const safetyManagerPersonTypeOption = computed(() =>
  getPreferredPersonTypeOption([['安全生产管理人员'], ['安全管理人员'], ['安全生产', '管理人员']]),
)

const safetyCertificatePersonTypeOptions = computed(() =>
  [principalPersonTypeOption.value, safetyManagerPersonTypeOption.value].filter(
    (item): item is NonNullable<typeof item> => Boolean(item),
  ),
)

const personTypeOptions = computed(() => {
  if (isSpecialOperationTab.value) {
    return specialOperationPersonTypeOption.value ? [specialOperationPersonTypeOption.value] : []
  }

  if (isSafetyCertificateTab.value) {
    return safetyCertificatePersonTypeOptions.value
  }

  return allPersonTypeOptions.value
})

const workCategoryOptions = computed(() => {
  return (currentPersonType.value?.children || []).map((item) => ({
    label: item.name || item.names?.split('|').slice(-1)[0] || item.code,
    value: item.code,
  }))
})

const trainingProjectOptions = computed(() => {
  return (currentWorkCategory.value?.children || []).map((item) => ({
    label: item.name || item.names?.split('|').slice(-1)[0] || item.code,
    value: item.codes || item.code,
    fullName: item.names || item.name || item.code,
  }))
})

const initialTrainingTypeOption = computed(() =>
  projectTypeOptions.value.find((item) =>
    matchByKeywordGroups(item.label, [['初训'], ['初次取证'], ['取证']]),
  ),
)

const renewalTrainingTypeOption = computed(() =>
  projectTypeOptions.value.find((item) =>
    matchByKeywordGroups(item.label, [['复训'], ['换证'], ['复审']]),
  ),
)

const isPersonTypeLocked = computed(() => isSpecialOperationTab.value)
const isTrainingTypeLocked = computed(() => Boolean(currentMatterTab.value))

const workCategoryPlaceholder = computed(() => {
  if (!filters.personTypeCode) {
    return '请先选择人员类型'
  }

  if (workCategoryOptions.value.length === 0) {
    return '当前人员类型下暂无作业类别'
  }

  return '全部作业类别'
})

const trainingProjectPlaceholder = computed(() => {
  if (!filters.personTypeCode) {
    return '请先选择人员类型'
  }

  if (!filters.workCategoryCode) {
    return '请先选择作业类别'
  }

  if (trainingProjectOptions.value.length === 0) {
    return '当前作业类别下暂无操作项目'
  }

  return '全部操作项目'
})

const selectedPersonTypeTitle = computed(() => {
  return personTypeOptions.value.find((item) => item.value === filters.personTypeCode)?.label || '全部人员类型'
})

const selectedWorkCategoryTitle = computed(() => {
  return (
    workCategoryOptions.value.find((item) => item.value === filters.workCategoryCode)?.label ||
    workCategoryPlaceholder.value
  )
})

const selectedTrainingProjectTitle = computed(() => {
  return (
    trainingProjectOptions.value.find((item) => item.value === filters.trainingProjectCode)?.label ||
    trainingProjectPlaceholder.value
  )
})

const selectedTrainingTypeTitle = computed(() => {
  return projectTypeOptions.value.find((item) => item.value === filters.trainingType)?.label || '全部类型'
})

const selectedAreaTitle = computed(() => {
  return areaOptions.value.find((item) => item.value === filters.areaId)?.label || '全部地区'
})

const updatePersonType = (nextCode: string) => {
  const normalizedCode = nextCode || ''

  if (filters.personTypeCode === normalizedCode) {
    return
  }

  filters.personTypeCode = normalizedCode
  filters.workCategoryCode = ''
  filters.trainingProjectCode = ''
}

const syncMatterTabFilters = () => {
  const trainingTypeOption =
    currentMatterTab.value.trainingPhase === 'initial'
      ? initialTrainingTypeOption.value
      : renewalTrainingTypeOption.value

  filters.trainingType = trainingTypeOption?.value || ''

  if (isSpecialOperationTab.value) {
    updatePersonType(specialOperationPersonTypeOption.value?.value || '')
    return
  }

  const allowedSafetyPersonTypes = safetyCertificatePersonTypeOptions.value
  const nextSafetyPersonType =
    allowedSafetyPersonTypes.find((item) => item.value === filters.personTypeCode)?.value ||
    principalPersonTypeOption.value?.value ||
    allowedSafetyPersonTypes[0]?.value ||
    ''

  updatePersonType(nextSafetyPersonType)
}

const resetFilters = () => {
  activeMatterTab.value = DEFAULT_MATTER_TAB
  filters.areaId = getDefaultArea(areaOptions.value)
  filters.trainingType = ''
  filters.personTypeCode = ''
  filters.workCategoryCode = ''
  filters.trainingProjectCode = ''
  filters.currentPage = 1
  syncMatterTabFilters()
  fetchList()
}

const applyFilters = () => {
  filters.currentPage = 1
  fetchList()
}

const logout = () => {
  clearAuthSession()
  router.push('/login')
}

const openDetail = (id: string) => {
  router.push(`/institutions/${id}`)
}

const goPrevPage = () => {
  filters.currentPage = Math.max(1, filters.currentPage - 1)
  fetchList()
}

const goNextPage = () => {
  filters.currentPage = Math.min(totalPages.value, filters.currentPage + 1)
  fetchList()
}

const goToPage = (page: number) => {
  const nextPage = Math.min(Math.max(1, page), totalPages.value)

  if (nextPage === filters.currentPage) {
    return
  }

  filters.currentPage = nextPage
  fetchList()
}

const jumpToPage = () => {
  const page = Number(pageJump.value)

  if (!Number.isFinite(page) || page <= 0) {
    pageJump.value = String(filters.currentPage)
    return
  }

  goToPage(page)
}

const fetchList = async (withMask = true) => {
  loading.value = true

  if (withMask) {
    showGlobalLoading('正在加载培训机构列表...')
  }

  try {
    const response = await fetchInstitutionList(listQuery.value)
    institutions.value = (response.data.records || []).map((item, index) =>
      normalizeInstitutionListItem(item, index),
    )
    total.value = Number(response.data.total || 0)
  } catch (error) {
    institutions.value = []
    total.value = 0
    showGlobalMessage(getErrorMessage(error))
  } finally {
    if (withMask) {
      hideGlobalLoading()
    }

    loading.value = false
  }
}

const extractLeafCode = (value: string) => value.split('|').filter(Boolean).pop() || value

const getQualificationFilterCode = () => {
  if (filters.trainingProjectCode) {
    return extractLeafCode(filters.trainingProjectCode)
  }

  const personTypeNeedsWorkCategoryFallback =
    filters.personTypeCode &&
    [
      specialOperationPersonTypeOption.value?.value,
      principalPersonTypeOption.value?.value,
      safetyManagerPersonTypeOption.value?.value,
    ]
      .filter(Boolean)
      .includes(filters.personTypeCode)

  if (personTypeNeedsWorkCategoryFallback && filters.workCategoryCode) {
    const fallbackValue = String(currentWorkCategory.value?.codes || currentWorkCategory.value?.code || '').trim()

    return fallbackValue ? extractLeafCode(fallbackValue) : undefined
  }

  return undefined
}

const handleMatterTabChange = (tabKey: MatterTabKey) => {
  if (activeMatterTab.value === tabKey) {
    return
  }

  activeMatterTab.value = tabKey
  filters.areaId = getDefaultArea(areaOptions.value)
  filters.trainingType = ''
  filters.personTypeCode = ''
  filters.workCategoryCode = ''
  filters.trainingProjectCode = ''
  filters.currentPage = 1
  syncMatterTabFilters()
  fetchList()
}

const handlePersonTypeChange = () => {
  filters.workCategoryCode = ''
  filters.trainingProjectCode = ''
}

const handleWorkCategoryChange = () => {
  filters.trainingProjectCode = ''
}

const handleSignup = (institutionId: string) => {
  const currentInstitution = institutions.value.find((item) => item.id === institutionId)
  signupInstitutionId.value = institutionId
  signupInstitutionName.value = currentInstitution?.name || ''
  signupDialogVisible.value = true
}

watch(totalPages, (value) => {
  if (filters.currentPage > value) {
    filters.currentPage = value
  }

  pageJump.value = String(filters.currentPage)
})

watch(
  () => filters.currentPage,
  (value) => {
    pageJump.value = String(value)
  },
)

watch(
  () => filters.pageSize,
  () => {
    pageJump.value = String(filters.currentPage)
  },
)

onMounted(async () => {
  lookupLoading.value = true
  showGlobalLoading('正在加载页面数据...')

  try {
    const lookup = await loadLookupOptions()
    areaOptions.value = lookup.areaOptions
    projectTypeOptions.value = lookup.projectTypeOptions
    qualificationTree.value = lookup.qualificationTree
    filters.areaId = getDefaultArea(lookup.areaOptions)
    syncMatterTabFilters()
  } catch (error) {
    showGlobalMessage(getErrorMessage(error))
  } finally {
    lookupLoading.value = false
  }

  await fetchList(false)
  hideGlobalLoading()
})
</script>

<template>
  <main class="px-8 py-8">
    <div class="mx-auto flex max-w-[1320px] flex-col gap-6">
      <div class="flex items-center justify-between px-2 py-1">
        <Button variant="outline" @click="router.push('/')">返回首页</Button>
        <div class="flex items-center gap-3 pt-2">
          <div class="text-sm text-slate-500">
            用户姓名：
            <span class="font-medium text-slate-700">{{ userProfile?.userName || '-' }}</span>
          </div>
          <Button variant="outline" @click="router.push('/certificates')">我的证书</Button>
          <Button variant="outline" @click="logout">退出登录</Button>
        </div>
      </div>

      <Card class="p-6">
        <div class="mb-5 flex flex-wrap gap-2 border-b border-slate-200 pb-4">
          <button
            v-for="tab in matterTabOptions"
            :key="tab.key"
            type="button"
            class="rounded-md border px-4 py-2 text-sm transition"
            :class="
              activeMatterTab === tab.key
                ? 'border-blue-600 bg-blue-50 text-blue-600'
                : 'border-slate-200 bg-white text-slate-600 hover:border-blue-200 hover:text-blue-600'
            "
            @click="handleMatterTabChange(tab.key)"
          >
            {{ tab.label }}
          </button>
        </div>
        <div class="grid grid-cols-[minmax(0,1fr)_minmax(0,1.2fr)_minmax(0,1.45fr)_minmax(0,0.9fr)_minmax(0,0.9fr)_140px_140px] items-end gap-4">
          <div class="space-y-2">
            <label class="text-sm font-medium text-slate-700">人员类型</label>
            <div class="relative">
              <select
                v-model="filters.personTypeCode"
                :disabled="lookupLoading || isPersonTypeLocked"
                :title="selectedPersonTypeTitle"
                class="h-11 w-full appearance-none rounded-md border border-input bg-white px-3 pr-10 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 whitespace-nowrap overflow-hidden text-ellipsis"
                @change="handlePersonTypeChange"
              >
                <option v-for="option in personTypeOptions" :key="option.value" :value="option.value">
                  {{ option.label }}
                </option>
              </select>
              <ChevronDown class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            </div>
          </div>
          <div class="space-y-2">
            <label class="text-sm font-medium text-slate-700">作业类别</label>
            <div class="relative">
              <select
                v-model="filters.workCategoryCode"
                :disabled="lookupLoading || !filters.personTypeCode"
                :title="selectedWorkCategoryTitle"
                class="h-11 w-full appearance-none rounded-md border border-input bg-white px-3 pr-10 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 whitespace-nowrap overflow-hidden text-ellipsis"
                @change="handleWorkCategoryChange"
              >
                <option value="">{{ workCategoryPlaceholder }}</option>
                <option v-for="option in workCategoryOptions" :key="option.value" :value="option.value">
                  {{ option.label }}
                </option>
              </select>
              <ChevronDown class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            </div>
          </div>
          <div class="space-y-2">
            <label class="text-sm font-medium text-slate-700">操作项目</label>
            <div class="relative">
              <select
                v-model="filters.trainingProjectCode"
                :disabled="lookupLoading || !filters.workCategoryCode"
                :title="selectedTrainingProjectTitle"
                class="h-11 w-full appearance-none rounded-md border border-input bg-white px-3 pr-10 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 whitespace-nowrap overflow-hidden text-ellipsis"
              >
                <option value="">{{ trainingProjectPlaceholder }}</option>
                <option v-for="option in trainingProjectOptions" :key="option.value" :value="option.value">
                  {{ option.label }}
                </option>
              </select>
              <ChevronDown class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            </div>
          </div>
          <div class="space-y-2">
            <label class="text-sm font-medium text-slate-700">培训类型</label>
            <div class="relative">
              <select
                v-model="filters.trainingType"
                :disabled="lookupLoading || isTrainingTypeLocked"
                :title="selectedTrainingTypeTitle"
                class="h-11 w-full appearance-none rounded-md border border-input bg-white px-3 pr-10 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 whitespace-nowrap overflow-hidden text-ellipsis"
              >
                <option v-for="option in projectTypeOptions" :key="option.value" :value="option.value">
                  {{ option.label }}
                </option>
              </select>
              <ChevronDown class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            </div>
          </div>
          <div class="space-y-2">
            <label class="text-sm font-medium text-slate-700">地区</label>
            <div class="relative">
              <select
                v-model="filters.areaId"
                :disabled="lookupLoading"
                :title="selectedAreaTitle"
                class="h-11 w-full appearance-none rounded-md border border-input bg-white px-3 pr-10 text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 whitespace-nowrap overflow-hidden text-ellipsis"
              >
                <option value="">全部地区</option>
                <option v-for="option in areaOptions" :key="option.value" :value="option.value">
                  {{ option.label }}
                </option>
              </select>
              <ChevronDown class="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            </div>
          </div>

          <Button variant="outline" class="w-full" :disabled="loading" @click="resetFilters">重置</Button>
          <Button class="w-full" :disabled="loading || lookupLoading" @click="applyFilters">
            {{ loading ? '查询中...' : '确定' }}
          </Button>
        </div>
      </Card>

      <div class="space-y-5">
        <InstitutionCard
          v-for="institution in institutions"
          :key="institution.id"
          :institution="institution"
          @view-detail="openDetail"
          @signup="handleSignup"
        />

        <Card
          v-if="!loading && institutions.length === 0"
          class="flex min-h-[240px] items-center justify-center p-8 text-base text-slate-500"
        >
          暂无符合筛选条件的培训机构
        </Card>
      </div>

      <Card class="p-5">
        <div class="flex items-center justify-between">
          <p class="text-sm text-slate-500">
            共 {{ total }} 条，当前第 {{ filters.currentPage }} / {{ totalPages }} 页
          </p>
          <div class="flex items-center gap-3">
            <Button
              variant="outline"
              :disabled="filters.currentPage === 1 || loading"
              @click="goPrevPage"
            >
              上一页
            </Button>
            <div class="flex items-center gap-2">
              <Button
                v-for="page in visiblePages"
                :key="page"
                :variant="page === filters.currentPage ? 'default' : 'outline'"
                size="sm"
                :disabled="loading"
                @click="goToPage(page)"
              >
                {{ page }}
              </Button>
            </div>
            <Button
              variant="outline"
              :disabled="filters.currentPage === totalPages || loading"
              @click="goNextPage"
            >
              下一页
            </Button>
            <div class="flex items-center gap-2 text-sm text-slate-500">
              <span>跳至</span>
              <input
                v-model="pageJump"
                type="number"
                min="1"
                :max="totalPages"
                class="h-9 w-20 rounded-md border border-input px-3 text-center text-sm text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                @keyup.enter="jumpToPage"
              />
              <span>页</span>
              <Button variant="outline" size="sm" :disabled="loading" @click="jumpToPage">跳转</Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
    <InstitutionSignupDialog
      v-model="signupDialogVisible"
      :institution-id="signupInstitutionId"
      :institution-name="signupInstitutionName"
    />
  </main>
</template>
